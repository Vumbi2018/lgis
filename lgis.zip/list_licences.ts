
import { db } from "./server/db";
import { licences } from "./shared/schema";

async function listLicenses() {
    console.log("Listing all licenses:");
    const allLicences = await db.select().from(licences);
    console.log(`Total licenses: ${allLicences.length}`);
    allLicences.forEach(l => {
        console.log(`Licence No: ${l.licenceNo}, RequestID: ${l.requestId}`);
    });
}

listLicenses().catch(console.error);
