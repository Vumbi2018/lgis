async function main() {
    console.log("Testing API locally...");

    // Test GET
    try {
        const getRes = await fetch("http://localhost:5000/api/v1/license-type-fees");
        console.log("GET status:", getRes.status);
        const getData = await getRes.json();
        console.log("GET Response Count:", getData.length);
    } catch (error: any) {
        console.error("GET error:", error.message);
    }

    // Test POST
    try {
        console.log("\nTesting POST...");
        const postRes = await fetch("http://localhost:5000/api/v1/license-type-fees", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
                licenseTypeId: "test-license-id-" + Date.now(),
                amount: "250.00",
                currency: "PGK"
            })
        });
        console.log("POST status:", postRes.status);
        const postData = await postRes.json();
        console.log("POST Response:", JSON.stringify(postData, null, 2));
    } catch (error: any) {
        console.error("POST error:", error.message);
    }
}

main();
