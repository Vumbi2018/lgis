
import { db } from "../server/db";
import { serviceRequests } from "../shared/schema";
import { eq } from "drizzle-orm";

async function main() {
    try {
        const requestId = "8a6e1251-4755-44f4-8d67-503250f7e063";
        const generalBusinessId = "f948d0d4-f28b-4163-b3c6-f907a6c5d840";

        // 1. Get Request
        const requestResults = await db.select().from(serviceRequests).where(eq(serviceRequests.requestId, requestId));
        const request = requestResults[0];

        if (!request) {
            console.error("Request not found!");
            return;
        }

        const currentData = (request.processingData as any) || {};
        console.log("Current Data:", currentData);

        // 2. Update Data
        const newData = {
            ...currentData,
            licenseTypeId: generalBusinessId,
            // Also add string for backup
            licenseType: "GENERAL BUSINESS"
        };

        console.log("Updating request processingData...");
        await db.update(serviceRequests)
            .set({ processingData: newData })
            .where(eq(serviceRequests.requestId, requestId));

        console.log("Update complete. Linked to General Business.");

    } catch (e) {
        console.error("Error:", e);
    }
    process.exit(0);
}
main();
