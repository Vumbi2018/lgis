
import fetch from 'node-fetch';

async function testPaymentPost() {
    const councilId = '3c4d4a9f-92a7-4dd2-82fb-ceff90c57094';
    const requestId = 'f4496f8c-8d67-5032-b032-50f7e063df44'; // Using a requestId from previous check

    const paymentData = {
        councilId: councilId,
        accountId: "citizen-account-id",
        paymentRef: requestId,
        amount: "100.00",
        currency: "PGK",
        method: "cash",
        paymentDetails: {}
    };

    console.log("Testing POST to http://localhost:5000/api/v1/payments");
    try {
        const res = await fetch('http://localhost:5000/api/v1/payments', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'x-council-id': councilId
            },
            body: JSON.stringify(paymentData)
        });

        const status = res.status;
        const body = await res.json();
        console.log(`Status: ${status}`);
        console.log("Response Body:", body);
    } catch (e) {
        console.error("POST Failed:", e);
    }
}

testPaymentPost();
