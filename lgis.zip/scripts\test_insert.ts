import { db } from "../server/db";
import { licenseTypeFees } from "@shared/schema";

async function main() {
    console.log("Testing manual insertion...");
    try {
        const [inserted] = await db.insert(licenseTypeFees).values({
            licenseTypeId: "test-license-id",
            amount: "150.50",
            currency: "PGK"
        }).returning();
        console.log("Inserted successfully:", inserted);
    } catch (error) {
        console.error("Insertion error:", error);
    } finally {
        process.exit(0);
    }
}

main();
