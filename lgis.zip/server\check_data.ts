
import { storage } from "./storage";

async function checkData() {
    console.log("Checking businesses...");
    try {
        const businesses = await storage.getBusinesses();
        console.log(`Found ${businesses.length} businesses.`);
        businesses.forEach(b => {
            console.log(`- ${b.legalName} (ID: ${b.businessId}, Council: ${b.councilId})`);
        });
    } catch (error) {
        console.error("Error fetching businesses:", error);
    }
    process.exit(0);
}

checkData();
