import { db } from "./server/db";
import { businesses } from "./shared/schema";
import { eq } from "drizzle-orm";

async function check() {
    const businessId = "3f8febd7-1aae-45b1-a512-2013c5d697f2";
    const [business] = await db.select().from(businesses).where(eq(businesses.businessId, businessId));
    console.log("BUSINESS:", JSON.stringify(business, null, 2));
    process.exit(0);
}

check().catch(err => {
    console.error(err);
    process.exit(1);
});
