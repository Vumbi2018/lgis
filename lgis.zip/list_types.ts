
process.env.DATABASE_URL = "postgresql://postgres:S%40mund3ng0@localhost:5432/lgis";
import { storage } from './server/storage';

async function main() {
    const { storage } = await import('./server/storage');
    try {
        const types = await storage.getLicenseTypes();
        console.log('License Names:');
        types.forEach(t => console.log(`- ${t.licenseName}`));
    } catch (err) {
        console.error(err);
    }
    process.exit(0);
}
main();
