import { drizzle } from "drizzle-orm/node-postgres";
import pg from "pg";
import * as schema from "@shared/schema";

const { Pool } = pg;

if (!process.env.DATABASE_URL) {
  throw new Error(
    "DATABASE_URL must be set. Did you forget to provision a database?",
  );
}

export const pool = new Pool({ connectionString: process.env.DATABASE_URL });
pool.on('error', (err) => console.error('Unexpected error on idle client', err));
export const db = drizzle(pool, { schema });

// Connection check
(async () => {
  try {
    const res = await pool.query('SELECT NOW()');
    console.log(`[DB] Connection successful. Database time: ${res.rows[0].now}`);
  } catch (err) {
    console.error('[DB] Connection failed on startup!');
    console.error(err);
  }
})();
