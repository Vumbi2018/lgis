import { db } from "./server/db";
import {
    serviceRequests,
    payments,
    licences,
    businesses,
} from "./shared/schema";
import { inArray } from "drizzle-orm";

async function run() {
    const oldCouncilIds = [
        "3c4d4a9f-92a7-4dd2-82fb-ceff90c57094",
        "90c57094-13e2-42f1-be1f-1a1b50595f70",
        "f2739382-95a8-4197-ace0-bd1bcc5c1a11",
        "ncdc-001"
    ];

    const activeCouncilId = "3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3";

    console.log(`Migrating remaining data from legacy councils...`);

    // 4. Businesses
    const migratedBusinesses = await db.update(businesses)
        .set({ councilId: activeCouncilId })
        .where(inArray(businesses.councilId, oldCouncilIds))
        .returning();
    console.log(`Updated ${migratedBusinesses.length} businesses.`);

    console.log("Migration complete.");
    process.exit(0);
}

run().catch(err => {
    console.error(err);
    process.exit(1);
});
