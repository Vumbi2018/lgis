
import { db } from "../server/db";
import { sql } from "drizzle-orm";

async function main() {
    try {
        console.log("Adding missing columns to citizens table...");
        await db.execute(sql`ALTER TABLE citizens ADD COLUMN IF NOT EXISTS section text`);
        await db.execute(sql`ALTER TABLE citizens ADD COLUMN IF NOT EXISTS lot text`);
        await db.execute(sql`ALTER TABLE citizens ADD COLUMN IF NOT EXISTS block text`);
        await db.execute(sql`ALTER TABLE citizens ADD COLUMN IF NOT EXISTS suburb text`);
        console.log("Schema updated successfully");
    } catch (err: any) {
        console.error("Error updating schema:", err.message);
    }
}

main();
