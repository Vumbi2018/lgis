import { db } from "../server/db";
import { sql } from "drizzle-orm";

async function main() {
    console.log("Checking license_type_fees table...");
    try {
        const tableExists = await db.execute(sql`
      SELECT EXISTS (
        SELECT FROM information_schema.tables 
        WHERE table_name = 'license_type_fees'
      );
    `);
        console.log("Table exists:", tableExists.rows[0].exists);

        if (tableExists.rows[0].exists) {
            const columns = await db.execute(sql`
        SELECT column_name, data_type, is_nullable
        FROM information_schema.columns
        WHERE table_name = 'license_type_fees';
      `);
            console.log("Columns:", JSON.stringify(columns.rows, null, 2));
        }
    } catch (error) {
        console.error("Error checking table:", error);
    } finally {
        process.exit(0);
    }
}

main();
