import { db } from "./server/db";
import {
    serviceRequests,
    workflowInstances,
    payments,
    licences,
    inspections,
    documents,
    businesses
} from "./shared/schema";
import * as fs from "fs";

async function run() {
    const tables = {
        serviceRequests,
        workflowInstances,
        payments,
        licences,
        inspections,
        documents,
        businesses
    };

    let output = "COUNCIL ID USAGE ANALYSIS:\n";
    const oldCouncil = "3c4d4a9f-92a7-4dd2-82fb-ceff90c57094";
    const activeCouncil = "3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3";

    for (const [name, table] of Object.entries(tables)) {
        const all = await db.select().from(table as any);
        const oldCount = all.filter((r: any) => r.councilId === oldCouncil).length;
        const activeCount = all.filter((r: any) => r.councilId === activeCouncil).length;
        output += `TABLE ${name}: OLD(${oldCount}) | ACTIVE(${activeCount}) | TOTAL(${all.length})\n`;
    }

    fs.writeFileSync("council_usage_analysis.txt", output);
    console.log("Written to council_usage_analysis.txt");
    process.exit(0);
}

run().catch(err => {
    console.error(err);
    process.exit(1);
});
