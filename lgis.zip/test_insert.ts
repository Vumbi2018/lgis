
import { db } from "./server/db";
import { licences } from "@shared/schema";

async function test() {
    const dummyNo = `TEST-${Date.now()}`;
    console.log(`Inserting dummy licence ${dummyNo} with hashes...`);

    const inserted = await db.insert(licences).values({
        councilId: "3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3", // NCDC
        requestId: "dummy-request",
        licenceNo: dummyNo,
        issueDate: new Date(),
        expiryDate: new Date(),
        status: "active",
        licencePayloadHash: "HASH_PAYLOAD",
        pdfHash: "HASH_PDF",
        signedPdfHash: "HASH_SIGNED",
        signatureMetadata: { algo: "test" }
    }).returning();

    console.log("Inserted:", inserted[0]);

    if (inserted[0].pdfHash === "HASH_PDF") {
        console.log("SUCCESS: Hash was preserved.");
    } else {
        console.log("FAILURE: Hash is " + inserted[0].pdfHash);
    }
    process.exit();
}
test();
