
import { db } from "../server/db";
import { sql } from "drizzle-orm";
import * as fs from "fs";

async function main() {
    try {
        const result = await db.execute(sql`
      SELECT column_name
      FROM information_schema.columns 
      WHERE table_name = 'citizens'
    `);
        const columns = result.rows.map(r => r.column_name).sort().join("\n");
        fs.writeFileSync("columns.txt", columns);
        console.log("Done writing columns.txt");
    } catch (err: any) {
        console.error("Error:", err.message);
    }
}

main();
