
import { db } from "../server/db";
import { serviceRequests } from "../shared/schema";
import { eq } from "drizzle-orm";

async function main() {
    try {
        const requestRef = "LIC-2026-8594";
        const generalBusinessId = "f948d0d4-f28b-4163-b3c6-f907a6c5d840"; // The ID I prepared earlier

        // 1. Get Request by Ref
        const requestResults = await db.select().from(serviceRequests).where(eq(serviceRequests.requestRef, requestRef));
        const request = requestResults[0];

        if (!request) {
            console.error(`Request ${requestRef} not found!`);
            return;
        }

        console.log(`Found Request: ${request.requestId}`);
        const currentData = (request.processingData as any) || {};

        // 2. Update Data
        // Merge existing with new license type link
        const newData = {
            ...currentData,
            licenseTypeId: generalBusinessId,
            licenseType: "GENERAL BUSINESS"
        };

        console.log("Updating request processingData...");
        await db.update(serviceRequests)
            .set({ processingData: newData })
            .where(eq(serviceRequests.requestId, request.requestId));

        console.log(`Update complete for ${requestRef}. Linked to General Business ID: ${generalBusinessId}`);

    } catch (e) {
        console.error("Error:", e);
    }
    process.exit(0);
}
main();
