process.env.DATABASE_URL = "postgresql://postgres:S%40mund3ng0@localhost:5432/lgis";

async function main() {
    const { storage } = await import('./server/storage');
    console.log('Checking all requests...');
    try {
        const requests = await storage.getServiceRequests();
        console.log(`Found ${requests.length} requests.`);

        for (const req of requests) {
            const hasData = !!req.formData;
            const keyCount = hasData && typeof req.formData === 'object' ? Object.keys(req.formData).length : 0;
            console.log(`ID: ${req.requestId} | Ref: ${req.requestRef} | Status: ${req.status} | HasFormData: ${hasData} | Keys: ${keyCount}`);
            if (hasData && keyCount > 0 && keyCount < 5) {
                console.log('  -> Data:', JSON.stringify(req.formData));
            }
        }
    } catch (err) {
        console.error('Error:', err);
    }
    process.exit(0);
}
main();
