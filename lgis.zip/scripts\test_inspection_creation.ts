
import { db } from "../server/db";
import { councils, serviceRequests } from "../shared/schema";
import { eq } from "drizzle-orm";

async function main() {
    try {
        // 1. Get a Council
        const council = await db.query.councils.findFirst();
        if (!council) {
            console.error("No councils found! Cannot test.");
            process.exit(1);
        }
        console.log("Using Council:", council.councilId);

        // 2. Get a Service Request
        const request = await db.query.serviceRequests.findFirst({
            where: eq(serviceRequests.councilId, council.councilId)
        });

        // If no request, maybe we skip request ID or create one?
        // The schema allows nullable requestId now, so we can test without it too.
        const requestId = request ? request.requestId : null;
        console.log("Using Request ID:", requestId);

        // 3. Construct Payload
        const payload = {
            councilId: council.councilId,
            requestId: requestId, // can be null/undefined per my new permissive schema
            scheduledAt: new Date().toISOString(),
            // missing performedAt, which should be fine now
            // missing status, which caused issues before but now handled
        };

        console.log("Sending Payload:", JSON.stringify(payload, null, 2));

        // 4. Hit API
        const response = await fetch("http://localhost:5000/api/v1/inspections", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                "x-council-id": council.councilId
            },
            body: JSON.stringify(payload)
        });

        const status = response.status;
        const text = await response.text();

        console.log(`Response Status: ${status}`);
        console.log(`Response Body: ${text}`);

        if (status === 201) {
            console.log("SUCCESS: Inspection created!");
        } else {
            console.error("FAILURE: Could not create inspection.");
        }

    } catch (error) {
        console.error("Test failed with error:", error);
    } finally {
        process.exit(0);
    }
}

main();
