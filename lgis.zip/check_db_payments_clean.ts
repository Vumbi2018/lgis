
import { db } from "./server/db";
import { payments, serviceRequests } from "./shared/schema";
import { eq, desc } from "drizzle-orm";

async function checkPayments() {
    const recentPayments = await db.select().from(payments).orderBy(desc(payments.createdAt)).limit(3);
    console.log("RECENT PAYMENTS:");
    recentPayments.forEach(p => {
        console.log(`ID: ${p.paymentId}, Ref: ${p.paymentRef}, Status: ${p.status}, Council: ${p.councilId}`);
    });

    const recentRequests = await db.select().from(serviceRequests).orderBy(desc(serviceRequests.createdAt)).limit(3);
    console.log("\nRECENT REQUESTS:");
    recentRequests.forEach(r => {
        console.log(`ID: ${r.requestId}, Ref: ${r.requestRef}, Status: ${r.status}, Council: ${r.councilId}`);
    });
}

checkPayments().catch(console.error);
