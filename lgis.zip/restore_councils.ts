import { db } from "./server/db";
import { councils, tenantConfig } from "./shared/schema";
import { eq } from "drizzle-orm";

async function restore() {
    console.log("🩹 Restoring essential councils...");

    const ids = [
        "3c4d4a9f-92a7-4dd2-82fb-ceff90c57094", // Main ID used in data
        "3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3"  // ID currently being sent by user browser
    ];

    try {
        for (const id of ids) {
            const existing = await db.select().from(councils).where(eq(councils.councilId, id));
            if (existing.length === 0) {
                console.log(`Inserting council: ${id}`);
                await db.insert(councils).values({
                    councilId: id,
                    name: "National Capital District Commission",
                    level: "city",
                    status: "active",
                    themeColor: "#EAB308",
                    fontFamily: "Inter"
                });

                // Also create a default tenant config for it
                await db.insert(tenantConfig).values({
                    councilId: id,
                    councilName: "National Capital District Commission",
                    shortName: "NCDC",
                    primaryColor: "#1e40af",
                    secondaryColor: "#7c3aed",
                    accentColor: "#f59e0b",
                    enabledModules: ["registry", "licensing", "services", "payments", "portal"]
                });
            }
        }
        console.log("✅ Restoration complete.");
        process.exit(0);
    } catch (error) {
        console.error("❌ Restoration failed:", error);
        process.exit(1);
    }
}

restore();
