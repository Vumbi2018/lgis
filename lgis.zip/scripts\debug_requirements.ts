
import { db } from "../server/db";
import { licenseTypes } from "../shared/schema";

async function main() {
    try {
        console.log("Fetching license types...");
        const allTypes = await db.select().from(licenseTypes);
        console.log(`Found ${allTypes.length} license types.`);
        allTypes.forEach(t => console.log(`- ${t.name} (ID: ${t.id})`));
    } catch (e) {
        console.error("Error:", e);
    }
    process.exit(0);
}
main();
