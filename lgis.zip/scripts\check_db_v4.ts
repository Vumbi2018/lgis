
import { db } from "../server/db";
import { sql } from "drizzle-orm";

async function checkDb() {
    const tables = ["permissions", "license_types", "license_type_fees", "accounts", "inspection_evidence"];
    for (const t of tables) {
        try {
            const res = await db.execute(sql`SELECT count(*) FROM information_schema.tables WHERE table_name = ${t}`);
            process.stdout.write(`${t}:${res.rows[0].count > 0 ? "YES" : "NO"} `);
        } catch (e) {
            process.stdout.write(`${t}:ERR `);
        }
    }
    process.exit();
}
checkDb();
