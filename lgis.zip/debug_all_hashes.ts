
import { db } from "./server/db";
import { licences } from "@shared/schema";

async function check() {
    const all = await db.select().from(licences);
    console.log("Licences:");
    all.forEach(l => {
        console.log(`${l.licenceNo}: Hash=${l.pdfHash}`);
    });
    process.exit();
}
check();
