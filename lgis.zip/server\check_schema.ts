
import pg from "pg";
const { Pool } = pg;

async function checkSchema() {
    const pool = new Pool({ connectionString: process.env.DATABASE_URL });
    try {
        const res = await pool.query("SELECT column_name, data_type FROM information_schema.columns WHERE table_name = 'businesses';");
        console.log(JSON.stringify(res.rows, null, 2));
    } catch (err) {
        console.error("Error querying schema:", err);
    } finally {
        await pool.end();
    }
}

checkSchema();
