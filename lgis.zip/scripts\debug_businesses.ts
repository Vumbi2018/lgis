
import { db } from "../server/db";
import { businesses } from "../shared/schema";

async function main() {
    try {
        const result = await db.select({
            id: businesses.businessId,
            legalName: businesses.legalName,
            tradingName: businesses.tradingName
        }).from(businesses).limit(5);
        console.log("Found businesses:", JSON.stringify(result, null, 2));
    } catch (error) {
        console.error("Error fetching businesses:", error);
    }
}

main();
