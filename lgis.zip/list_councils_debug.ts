import { db } from "./server/db";
import { councils } from "./shared/schema";

async function list() {
    const all = await db.select().from(councils);
    console.log("COUNCILS:", JSON.stringify(all, null, 2));
    process.exit(0);
}

list().catch(err => {
    console.error(err);
    process.exit(1);
});
