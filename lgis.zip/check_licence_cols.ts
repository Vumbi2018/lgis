
import { db } from "./server/db";
import { sql } from "drizzle-orm";

async function checkCols() {
    try {
        const res = await db.execute(sql`
        SELECT column_name, data_type 
        FROM information_schema.columns 
        WHERE table_name = 'licences'
      `);
        console.log(`licences_COLS: ${res.rows.map(r => r.column_name).join(",")}`);
    } catch (e: any) {
        console.log(`ERR: ${e.message}`);
    }
    process.exit();
}
checkCols();
