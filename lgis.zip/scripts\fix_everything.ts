
import { db } from "../server/db";
import {
    serviceRequests, licences, businesses, citizens, properties,
    payments, inspections, complaints, users, services,
    tenantConfig, roles
} from "../shared/schema";
import { eq, sql } from "drizzle-orm";

async function main() {
    const correctId = '3c4d4a9f-92a7-4dd2-82fb-ceff90c57094';
    const wrongId1 = 'f2739382-95a8-4197-ace0-bd1bcc5c1a11';
    const wrongId2 = 'ncdc-001';

    console.log("Starting comprehensive fix...");

    // 1. Migrate Data
    const tables = [
        { name: 'service_requests', table: serviceRequests, idCol: serviceRequests.councilId },
        { name: 'licences', table: licences, idCol: licences.councilId },
        { name: 'businesses', table: businesses, idCol: businesses.councilId },
        { name: 'citizens', table: citizens, idCol: citizens.councilId },
        { name: 'properties', table: properties, idCol: properties.councilId },
        { name: 'payments', table: payments, idCol: payments.councilId },
        { name: 'inspections', table: inspections, idCol: inspections.councilId },
        { name: 'complaints', table: complaints, idCol: complaints.councilId },
        { name: 'users', table: users, idCol: users.councilId },
        { name: 'services', table: services, idCol: services.councilId },
        { name: 'roles', table: roles, idCol: roles.councilId },
    ];

    for (const t of tables) {
        console.log(`Checking ${t.name}...`);

        // Fix wrongId1
        const res1 = await db.update(t.table)
            .set({ councilId: correctId })
            .where(eq(t.idCol, wrongId1))
            .returning();
        if (res1.length > 0) console.log(`  Migrated ${res1.length} records from ${wrongId1}`);

        // Fix wrongId2
        const res2 = await db.update(t.table)
            .set({ councilId: correctId })
            .where(eq(t.idCol, wrongId2))
            .returning();
        if (res2.length > 0) console.log(`  Migrated ${res2.length} records from ${wrongId2}`);

        // Count total correct
        const count = await db.select({ count: sql<number>`count(*)` })
            .from(t.table)
            .where(eq(t.idCol, correctId));
        console.log(`  Total correct records in ${t.name}: ${count[0].count}`);
    }

    // 2. Enable All Modules
    const allModules = [
        "dashboard", "registry", "licensing", "services", "payments",
        "inspections", "enforcement", "complaints", "audit",
        "gis", "properties", "planning", "environment", "building",
        "assets", "waste", "procurement", "fleet",
        "portal", "mobile", "notifications", "feedback",
        "reports", "api", "documents", "workflows", "configuration"
    ];

    console.log("Updating tenant config modules...");
    let configUpdate = await db.update(tenantConfig)
        .set({ enabledModules: allModules })
        .where(eq(tenantConfig.councilId, correctId))
        .returning();

    if (configUpdate.length === 0) {
        console.log("No config found, creating new one...");
        configUpdate = await db.insert(tenantConfig).values({
            councilId: correctId,
            enabledModules: allModules,
            councilName: 'National Capital District Commission',
            shortName: 'NCDC',
            primaryColor: '#000000',
            secondaryColor: '#FFD700',
            accentColor: '#FFFFFF',
            fontFamily: 'Inter'
        }).returning();
    }

    console.log("Tenant config updated/created:", configUpdate.length > 0 ? "YES" : "NO");

    console.log("Fix complete.");
}

main().catch(console.error).finally(() => process.exit(0));
