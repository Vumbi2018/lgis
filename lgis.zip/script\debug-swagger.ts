import swaggerJsdoc from 'swagger-jsdoc';
import swaggerUi from 'swagger-ui-express';

console.log('Modules loaded successfully');
console.log('swaggerJsdoc:', typeof swaggerJsdoc);
console.log('swaggerUi:', typeof swaggerUi);
console.log('swaggerUi details:', swaggerUi);
