
import { db } from "./server/db";
import { serviceRequests } from "@shared/schema";
import { eq } from "drizzle-orm";

async function checkRequests() {
    try {
        console.log("Checking service requests...");
        const allRequests = await db.select().from(serviceRequests);
        console.log(`Total requests: ${allRequests.length}`);

        if (allRequests.length > 0) {
            console.log("First 3 requests:");
            allRequests.slice(0, 3).forEach(r => {
                console.log(`- ID: ${r.requestId}, Status: ${r.status}, CouncilID: ${r.councilId}`);
            });
        } else {
            console.log("No service requests found.");
        }
    } catch (error) {
        console.error("Error checking requests:", error);
    }
    process.exit(0);
}

checkRequests();
