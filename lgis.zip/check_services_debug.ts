import { db } from "./server/db";
import { services } from "./shared/schema";
import { eq } from "drizzle-orm";

async function check() {
    const ids = [
        "3c4d4a9f-92a7-4dd2-82fb-ceff90c57094",
        "3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3"
    ];

    for (const id of ids) {
        const srvs = await db.select().from(services).where(eq(services.councilId, id));
        console.log(`COUNCIL ${id} HAS ${srvs.length} SERVICES`);
        if (srvs.length > 0) {
            console.log(JSON.stringify(srvs.map(s => ({ name: s.name, category: s.category })), null, 2));
        }
    }
    process.exit(0);
}

check().catch(err => {
    console.error(err);
    process.exit(1);
});
