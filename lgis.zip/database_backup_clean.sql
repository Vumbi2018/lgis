--
-- PostgreSQL database dump
--


-- Dumped from database version 18.0
-- Dumped by pg_dump version 18.0

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: drizzle; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA drizzle;


ALTER SCHEMA drizzle OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: __drizzle_migrations; Type: TABLE; Schema: drizzle; Owner: postgres
--

CREATE TABLE drizzle.__drizzle_migrations (
    id integer NOT NULL,
    hash text NOT NULL,
    created_at bigint
);


ALTER TABLE drizzle.__drizzle_migrations OWNER TO postgres;

--
-- Name: __drizzle_migrations_id_seq; Type: SEQUENCE; Schema: drizzle; Owner: postgres
--

CREATE SEQUENCE drizzle.__drizzle_migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE drizzle.__drizzle_migrations_id_seq OWNER TO postgres;

--
-- Name: __drizzle_migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: drizzle; Owner: postgres
--

ALTER SEQUENCE drizzle.__drizzle_migrations_id_seq OWNED BY drizzle.__drizzle_migrations.id;


--
-- Name: accounts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.accounts (
    account_id character varying DEFAULT gen_random_uuid() NOT NULL,
    council_id character varying NOT NULL,
    holder_type text NOT NULL,
    holder_id character varying NOT NULL,
    account_no text NOT NULL,
    status text DEFAULT 'active'::text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.accounts OWNER TO postgres;

--
-- Name: assets; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.assets (
    asset_id character varying DEFAULT gen_random_uuid() NOT NULL,
    council_id character varying NOT NULL,
    asset_no text NOT NULL,
    name text NOT NULL,
    type text NOT NULL,
    location text,
    condition text,
    value text,
    status text DEFAULT 'active'::text,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.assets OWNER TO postgres;

--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.audit_logs (
    audit_id character varying DEFAULT gen_random_uuid() NOT NULL,
    council_id character varying NOT NULL,
    user_id character varying,
    action text NOT NULL,
    entity_type text NOT NULL,
    entity_id character varying,
    before_state jsonb,
    after_state jsonb,
    ip_address text,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.audit_logs OWNER TO postgres;

--
-- Name: business_verification_requests; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.business_verification_requests (
    request_id character varying DEFAULT gen_random_uuid() NOT NULL,
    business_id character varying NOT NULL,
    council_id character varying NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    submitted_at timestamp without time zone DEFAULT now() NOT NULL,
    reviewed_at timestamp without time zone,
    reviewed_by character varying,
    comments text
);


ALTER TABLE public.business_verification_requests OWNER TO postgres;

--
-- Name: businesses; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.businesses (
    business_id character varying DEFAULT gen_random_uuid() NOT NULL,
    council_id character varying NOT NULL,
    registration_no text,
    tin text,
    legal_name text NOT NULL,
    trading_name text,
    business_type text,
    industry text,
    owner_name text,
    owner_user_id character varying,
    contact_phone text,
    contact_email text,
    physical_address text,
    section text,
    lot text,
    suburb text,
    status text DEFAULT 'pending_verification'::text,
    is_foreign_enterprise boolean DEFAULT false,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    block text,
    village text,
    district text,
    province text,
    latitude real,
    longitude real
);


ALTER TABLE public.businesses OWNER TO postgres;

--
-- Name: checklist_requirements; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.checklist_requirements (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    license_type_id character varying NOT NULL,
    item_number integer NOT NULL,
    document_name text NOT NULL,
    responsible_entity text,
    requirement_note text,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.checklist_requirements OWNER TO postgres;

--
-- Name: citizens; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.citizens (
    citizen_id character varying DEFAULT gen_random_uuid() NOT NULL,
    council_id character varying NOT NULL,
    national_id text,
    local_citizen_no text,
    first_name text NOT NULL,
    last_name text NOT NULL,
    dob date,
    sex text,
    phone text,
    email text,
    address text,
    village text,
    district text,
    province text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    section text,
    lot text,
    block text,
    suburb text,
    nationality text
);


ALTER TABLE public.citizens OWNER TO postgres;

--
-- Name: complaint_updates; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.complaint_updates (
    update_id character varying DEFAULT gen_random_uuid() NOT NULL,
    council_id character varying NOT NULL,
    complaint_id character varying NOT NULL,
    updated_by character varying,
    status text,
    comment text,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.complaint_updates OWNER TO postgres;

--
-- Name: complaints; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.complaints (
    complaint_id character varying DEFAULT gen_random_uuid() NOT NULL,
    council_id character varying NOT NULL,
    complainant_type text,
    complainant_id character varying,
    category text,
    status text DEFAULT 'new'::text NOT NULL,
    description text,
    latitude numeric(10,7),
    longitude numeric(10,7),
    location text,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.complaints OWNER TO postgres;

--
-- Name: council_units; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.council_units (
    unit_id character varying DEFAULT gen_random_uuid() NOT NULL,
    council_id character varying NOT NULL,
    name text NOT NULL,
    type text NOT NULL,
    parent_unit_id character varying
);


ALTER TABLE public.council_units OWNER TO postgres;

--
-- Name: councils; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.councils (
    council_id character varying DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    level text NOT NULL,
    country_code character(2) DEFAULT 'PG'::bpchar NOT NULL,
    currency_code character(3) DEFAULT 'PGK'::bpchar NOT NULL,
    timezone text DEFAULT 'Pacific/Port_Moresby'::text NOT NULL,
    status text DEFAULT 'active'::text NOT NULL,
    logo_url text,
    theme_color text DEFAULT '#EAB308'::text,
    font_family text DEFAULT 'Inter'::text,
    email text,
    phone text,
    website text,
    address text,
    date_format text DEFAULT 'dd/MM/yyyy'::text,
    time_format text DEFAULT 'HH:mm'::text,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.councils OWNER TO postgres;

--
-- Name: documents; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.documents (
    document_id character varying DEFAULT gen_random_uuid() NOT NULL,
    council_id character varying NOT NULL,
    owner_type text NOT NULL,
    owner_id character varying NOT NULL,
    type text NOT NULL,
    file_name text NOT NULL,
    file_path text NOT NULL,
    mime_type text NOT NULL,
    file_size integer NOT NULL,
    verified boolean DEFAULT false,
    verified_at timestamp without time zone,
    verified_by character varying,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    rejection_reason text,
    status text DEFAULT 'pending'::text
);


ALTER TABLE public.documents OWNER TO postgres;

--
-- Name: dynamic_locations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.dynamic_locations (
    location_id uuid DEFAULT gen_random_uuid() NOT NULL,
    council_id character varying NOT NULL,
    level text NOT NULL,
    level_index text NOT NULL,
    name text NOT NULL,
    code text,
    parent_id uuid,
    latitude text,
    longitude text,
    bounds jsonb,
    is_active text DEFAULT 'true'::text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.dynamic_locations OWNER TO postgres;

--
-- Name: enforcement_cases; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.enforcement_cases (
    case_id character varying DEFAULT gen_random_uuid() NOT NULL,
    council_id character varying NOT NULL,
    request_id character varying,
    case_no text NOT NULL,
    type text,
    status text DEFAULT 'open'::text,
    offender_type text,
    offender_id character varying,
    description text,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.enforcement_cases OWNER TO postgres;

--
-- Name: fee_schedules; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.fee_schedules (
    fee_id character varying DEFAULT gen_random_uuid() NOT NULL,
    council_id character varying NOT NULL,
    service_id character varying NOT NULL,
    name text NOT NULL,
    basis text NOT NULL,
    amount numeric(12,2) NOT NULL,
    currency character(3) DEFAULT 'PGK'::bpchar NOT NULL,
    valid_from date NOT NULL,
    valid_to date
);


ALTER TABLE public.fee_schedules OWNER TO postgres;

--
-- Name: inspection_evidence; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.inspection_evidence (
    evidence_id character varying DEFAULT gen_random_uuid() NOT NULL,
    council_id character varying NOT NULL,
    inspection_id character varying NOT NULL,
    media_type text,
    url text,
    hash text,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.inspection_evidence OWNER TO postgres;

--
-- Name: inspection_findings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.inspection_findings (
    finding_id character varying DEFAULT gen_random_uuid() NOT NULL,
    council_id character varying NOT NULL,
    inspection_id character varying NOT NULL,
    code text,
    severity text,
    description text,
    corrective_action text,
    due_date date
);


ALTER TABLE public.inspection_findings OWNER TO postgres;

--
-- Name: inspections; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.inspections (
    inspection_id character varying DEFAULT gen_random_uuid() NOT NULL,
    council_id character varying NOT NULL,
    request_id character varying,
    inspector_user_id character varying,
    scheduled_at timestamp without time zone,
    performed_at timestamp without time zone,
    result text,
    remarks text,
    latitude numeric(10,7),
    longitude numeric(10,7),
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.inspections OWNER TO postgres;

--
-- Name: integration_configs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.integration_configs (
    config_id character varying DEFAULT gen_random_uuid() NOT NULL,
    council_id character varying NOT NULL,
    name text NOT NULL,
    type text NOT NULL,
    status text DEFAULT 'disconnected'::text,
    last_sync_at timestamp without time zone,
    description text,
    details jsonb,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.integration_configs OWNER TO postgres;

--
-- Name: invoice_lines; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.invoice_lines (
    line_id character varying DEFAULT gen_random_uuid() NOT NULL,
    council_id character varying NOT NULL,
    invoice_id character varying NOT NULL,
    description text,
    quantity integer DEFAULT 1,
    unit_price numeric(12,2),
    line_total numeric(12,2)
);


ALTER TABLE public.invoice_lines OWNER TO postgres;

--
-- Name: invoices; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.invoices (
    invoice_id character varying DEFAULT gen_random_uuid() NOT NULL,
    council_id character varying NOT NULL,
    account_id character varying NOT NULL,
    invoice_no text NOT NULL,
    total_amount numeric(12,2) NOT NULL,
    currency character(3) DEFAULT 'PGK'::bpchar NOT NULL,
    status text DEFAULT 'draft'::text NOT NULL,
    issued_at timestamp without time zone,
    due_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.invoices OWNER TO postgres;

--
-- Name: licence_renewals; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.licence_renewals (
    renewal_id character varying DEFAULT gen_random_uuid() NOT NULL,
    council_id character varying NOT NULL,
    licence_id character varying NOT NULL,
    request_id character varying,
    previous_expiry_date date,
    new_expiry_date date,
    renewed_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.licence_renewals OWNER TO postgres;

--
-- Name: licences; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.licences (
    licence_id character varying DEFAULT gen_random_uuid() NOT NULL,
    council_id character varying NOT NULL,
    request_id character varying NOT NULL,
    licence_no text NOT NULL,
    issue_date date,
    expiry_date date,
    status text DEFAULT 'active'::text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    licence_payload_hash text,
    pdf_hash text,
    signed_pdf_hash text,
    signature_metadata jsonb,
    version integer DEFAULT 1
);


ALTER TABLE public.licences OWNER TO postgres;

--
-- Name: license_type_fees; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.license_type_fees (
    id character varying(255) DEFAULT gen_random_uuid() NOT NULL,
    license_type_id character varying(255) NOT NULL,
    amount numeric(12,2) NOT NULL,
    currency text DEFAULT 'PGK'::text NOT NULL,
    effective_date timestamp without time zone DEFAULT now() NOT NULL,
    active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.license_type_fees OWNER TO postgres;

--
-- Name: license_types; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.license_types (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    license_name text NOT NULL,
    license_category text NOT NULL,
    application_form text,
    description text,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.license_types OWNER TO postgres;

--
-- Name: location_levels; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.location_levels (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    council_id character varying NOT NULL,
    name text NOT NULL,
    level integer NOT NULL,
    description text,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.location_levels OWNER TO postgres;

--
-- Name: locations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.locations (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    council_id character varying NOT NULL,
    level_id character varying NOT NULL,
    code text NOT NULL,
    parent_id character varying,
    boundary jsonb,
    centroid text,
    status text DEFAULT 'active'::text,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.locations OWNER TO postgres;

--
-- Name: markets; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.markets (
    market_id character varying DEFAULT gen_random_uuid() NOT NULL,
    council_id character varying NOT NULL,
    name text NOT NULL,
    location text,
    capacity integer,
    operating_hours text,
    status text DEFAULT 'active'::text,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.markets OWNER TO postgres;

--
-- Name: notices; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.notices (
    notice_id character varying DEFAULT gen_random_uuid() NOT NULL,
    council_id character varying NOT NULL,
    case_id character varying NOT NULL,
    notice_no text NOT NULL,
    notice_type text,
    issued_date date,
    compliance_due date,
    details text,
    status text DEFAULT 'issued'::text,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.notices OWNER TO postgres;

--
-- Name: notifications; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.notifications (
    notification_id character varying DEFAULT gen_random_uuid() NOT NULL,
    council_id character varying NOT NULL,
    user_id character varying NOT NULL,
    type text NOT NULL,
    title text NOT NULL,
    message text NOT NULL,
    reference_type text,
    reference_id character varying,
    read boolean DEFAULT false,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.notifications OWNER TO postgres;

--
-- Name: otp_verifications; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.otp_verifications (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    identifier text NOT NULL,
    code text NOT NULL,
    type text NOT NULL,
    expires_at timestamp without time zone NOT NULL,
    verified boolean DEFAULT false,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.otp_verifications OWNER TO postgres;

--
-- Name: payment_allocations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.payment_allocations (
    allocation_id character varying DEFAULT gen_random_uuid() NOT NULL,
    council_id character varying NOT NULL,
    payment_id character varying NOT NULL,
    invoice_id character varying NOT NULL,
    allocated_amount numeric(12,2) NOT NULL
);


ALTER TABLE public.payment_allocations OWNER TO postgres;

--
-- Name: payments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.payments (
    payment_id character varying DEFAULT gen_random_uuid() NOT NULL,
    council_id character varying NOT NULL,
    account_id character varying NOT NULL,
    payment_ref text NOT NULL,
    amount numeric(12,2) NOT NULL,
    currency character(3) DEFAULT 'PGK'::bpchar NOT NULL,
    method text NOT NULL,
    provider text,
    status text DEFAULT 'pending'::text NOT NULL,
    external_reference text,
    payment_details jsonb,
    paid_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.payments OWNER TO postgres;

--
-- Name: permissions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.permissions (
    permission_code text NOT NULL,
    description text NOT NULL
);


ALTER TABLE public.permissions OWNER TO postgres;

--
-- Name: properties; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.properties (
    property_id character varying DEFAULT gen_random_uuid() NOT NULL,
    council_id character varying NOT NULL,
    parcel_id text,
    section text,
    lot text,
    allotment text,
    suburb text,
    district text,
    land_type text,
    title_number text,
    owner_name text,
    owner_type text,
    land_area text,
    zoning text,
    rateable_value numeric(12,2),
    coordinates text,
    status text DEFAULT 'active'::text,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.properties OWNER TO postgres;

--
-- Name: purchase_order_lines; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.purchase_order_lines (
    line_id character varying DEFAULT gen_random_uuid() NOT NULL,
    order_id character varying NOT NULL,
    description text NOT NULL,
    quantity integer DEFAULT 1 NOT NULL,
    unit_price numeric(12,2) NOT NULL,
    line_total numeric(12,2) NOT NULL
);


ALTER TABLE public.purchase_order_lines OWNER TO postgres;

--
-- Name: purchase_orders; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.purchase_orders (
    order_id character varying DEFAULT gen_random_uuid() NOT NULL,
    council_id character varying NOT NULL,
    vendor_id character varying NOT NULL,
    requestor_id character varying,
    order_date date DEFAULT now(),
    expected_date date,
    status text DEFAULT 'draft'::text,
    total_amount numeric(12,2) DEFAULT '0'::numeric,
    currency character(3) DEFAULT 'PGK'::bpchar,
    description text,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.purchase_orders OWNER TO postgres;

--
-- Name: rate_assessments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.rate_assessments (
    assessment_id character varying DEFAULT gen_random_uuid() NOT NULL,
    council_id character varying NOT NULL,
    property_id character varying NOT NULL,
    assessment_year integer NOT NULL,
    rateable_value numeric(12,2),
    rate_amount numeric(12,2),
    status text DEFAULT 'pending'::text,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.rate_assessments OWNER TO postgres;

--
-- Name: role_permissions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.role_permissions (
    role_id character varying NOT NULL,
    permission_code text NOT NULL
);


ALTER TABLE public.role_permissions OWNER TO postgres;

--
-- Name: roles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.roles (
    role_id character varying DEFAULT gen_random_uuid() NOT NULL,
    council_id character varying NOT NULL,
    name text NOT NULL,
    scope text DEFAULT 'council'::text NOT NULL
);


ALTER TABLE public.roles OWNER TO postgres;

--
-- Name: service_requests; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.service_requests (
    request_id character varying DEFAULT gen_random_uuid() NOT NULL,
    council_id character varying NOT NULL,
    service_id character varying NOT NULL,
    requester_type text NOT NULL,
    requester_id character varying NOT NULL,
    status text DEFAULT 'draft'::text NOT NULL,
    channel text DEFAULT 'web'::text NOT NULL,
    form_data jsonb,
    submitted_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    processing_data jsonb,
    request_ref text,
    reviewed_at timestamp without time zone,
    inspected_at timestamp without time zone,
    approved_at timestamp without time zone
);


ALTER TABLE public.service_requests OWNER TO postgres;

--
-- Name: services; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.services (
    service_id character varying DEFAULT gen_random_uuid() NOT NULL,
    council_id character varying NOT NULL,
    code text NOT NULL,
    name text NOT NULL,
    category text NOT NULL,
    description text,
    requires_inspection boolean DEFAULT false,
    requires_approval boolean DEFAULT true,
    active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.services OWNER TO postgres;

--
-- Name: special_requirements; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.special_requirements (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    license_type_id character varying NOT NULL,
    requirement_name text NOT NULL,
    issuing_authority text,
    description text,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.special_requirements OWNER TO postgres;

--
-- Name: stalls; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.stalls (
    stall_id character varying DEFAULT gen_random_uuid() NOT NULL,
    council_id character varying NOT NULL,
    market_id character varying NOT NULL,
    stall_no text NOT NULL,
    category text,
    size text,
    daily_rate numeric(10,2),
    monthly_rate numeric(10,2),
    status text DEFAULT 'available'::text,
    current_tenant_id character varying,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.stalls OWNER TO postgres;

--
-- Name: tenant_config; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tenant_config (
    config_id uuid DEFAULT gen_random_uuid() NOT NULL,
    council_id character varying NOT NULL,
    council_name text,
    short_name text,
    logo_url text,
    favicon_url text,
    tagline text,
    primary_color text DEFAULT '#1e40af'::text,
    secondary_color text DEFAULT '#7c3aed'::text,
    accent_color text DEFAULT '#f59e0b'::text,
    background_root_color text DEFAULT '#EBECED'::text,
    background_default_color text DEFAULT '#FCFCFC'::text,
    background_higher_color text DEFAULT '#F0F1F2'::text,
    foreground_default_color text DEFAULT '#07080A'::text,
    foreground_dimmer_color text DEFAULT '#3D4047'::text,
    outline_color text DEFAULT '#C0C3C4'::text,
    primary_foreground text,
    positive_color text DEFAULT '#10b981'::text,
    warning_color text DEFAULT '#f59e0b'::text,
    negative_color text DEFAULT '#ef4444'::text,
    sidebar_background text,
    sidebar_foreground text,
    header_background text,
    header_foreground text,
    card_background text,
    border_radius integer DEFAULT 4,
    button_radius integer DEFAULT 4,
    card_radius integer DEFAULT 8,
    input_radius integer DEFAULT 4,
    font_family text DEFAULT 'Inter'::text,
    location_levels jsonb DEFAULT '["Country", "Province", "District", "Ward"]'::jsonb,
    locale text DEFAULT 'en-PG'::text,
    timezone text DEFAULT 'Pacific/Port_Moresby'::text,
    date_format text DEFAULT 'DD/MM/YYYY'::text,
    time_format text DEFAULT 'HH:mm'::text,
    first_day_of_week text DEFAULT 'monday'::text,
    currency text DEFAULT 'PGK'::text,
    currency_symbol text DEFAULT 'K'::text,
    currency_position text DEFAULT 'before'::text,
    decimal_separator text DEFAULT '.'::text,
    thousands_separator text DEFAULT ','::text,
    address text,
    phone text,
    email text,
    website text,
    emergency_contact text,
    facebook text,
    twitter text,
    linkedin text,
    enable_multi_language text DEFAULT 'false'::text,
    supported_languages jsonb DEFAULT '["en"]'::jsonb,
    enabled_modules jsonb DEFAULT '["registry", "licensing", "services", "payments", "portal"]'::jsonb,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.tenant_config OWNER TO postgres;

--
-- Name: user_roles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_roles (
    user_id character varying NOT NULL,
    role_id character varying NOT NULL,
    assigned_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.user_roles OWNER TO postgres;

--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    user_id character varying DEFAULT gen_random_uuid() NOT NULL,
    council_id character varying NOT NULL,
    unit_id character varying,
    full_name text NOT NULL,
    email text NOT NULL,
    phone text,
    password_hash text NOT NULL,
    status text DEFAULT 'active'::text NOT NULL,
    mfa_enabled boolean DEFAULT false,
    last_login_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    role text DEFAULT 'user'::text NOT NULL,
    national_id text
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: workflow_definitions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.workflow_definitions (
    workflow_id character varying DEFAULT gen_random_uuid() NOT NULL,
    council_id character varying NOT NULL,
    service_id character varying NOT NULL,
    version text DEFAULT '1.0'::text NOT NULL,
    name text,
    description text,
    active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.workflow_definitions OWNER TO postgres;

--
-- Name: workflow_instances; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.workflow_instances (
    instance_id character varying DEFAULT gen_random_uuid() NOT NULL,
    council_id character varying NOT NULL,
    request_id character varying NOT NULL,
    workflow_id character varying NOT NULL,
    state text DEFAULT 'pending'::text NOT NULL,
    current_step_id character varying,
    started_at timestamp without time zone DEFAULT now(),
    ended_at timestamp without time zone
);


ALTER TABLE public.workflow_instances OWNER TO postgres;

--
-- Name: workflow_steps; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.workflow_steps (
    step_id character varying DEFAULT gen_random_uuid() NOT NULL,
    council_id character varying NOT NULL,
    workflow_id character varying NOT NULL,
    name text NOT NULL,
    order_no integer NOT NULL,
    assignee_role text,
    sla_rule text,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.workflow_steps OWNER TO postgres;

--
-- Name: __drizzle_migrations id; Type: DEFAULT; Schema: drizzle; Owner: postgres
--

ALTER TABLE ONLY drizzle.__drizzle_migrations ALTER COLUMN id SET DEFAULT nextval('drizzle.__drizzle_migrations_id_seq'::regclass);


--
-- Data for Name: __drizzle_migrations; Type: TABLE DATA; Schema: drizzle; Owner: postgres
--

COPY drizzle.__drizzle_migrations (id, hash, created_at) FROM stdin;
\.


--
-- Data for Name: accounts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.accounts (account_id, council_id, holder_type, holder_id, account_no, status, created_at) FROM stdin;
9f0753db-6dfa-408c-9b10-4e74cd89347b	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	citizen	edb0bb1c-b524-4d3d-b9d6-3c59572eb35d	NCDC-ACC-C0001	active	2026-01-14 06:40:16.262116
a2ce6d63-c2ef-4bac-bae0-294700334b08	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	citizen	3ddb05da-6712-4db8-b25c-2106711cc6b6	NCDC-ACC-C0002	active	2026-01-14 06:40:16.262116
dcd9b8cd-3626-4ffe-8c0d-5d969e48c7dd	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	business	1c0bf792-8d5b-466a-acc5-83bbcf22e979	NCDC-ACC-B0001	active	2026-01-14 06:40:16.262116
ad48e2f6-91c7-4393-8e1a-84726584bd09	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	business	9503c736-dfe0-4973-9cf8-129383661614	NCDC-ACC-B0002	active	2026-01-14 06:40:16.262116
ee80e26c-6d86-419c-903f-6cbfd1508edf	f2739382-95a8-4197-ace0-bd1bcc5c1a11	citizen	f5c265f3-5548-49b4-9109-08bff3528d6f	NCDC-ACC-C0001	active	2026-01-19 04:04:14.534435
ddef027b-63ba-4ae3-8678-ab69bd2040f7	f2739382-95a8-4197-ace0-bd1bcc5c1a11	citizen	441fdec2-a854-446c-ba81-eac495058d86	NCDC-ACC-C0002	active	2026-01-19 04:04:14.534435
066bba8d-4920-484c-ba17-cc6eb26e2970	f2739382-95a8-4197-ace0-bd1bcc5c1a11	business	3a26c163-36f7-4b66-9f95-fdc8abc7bce8	NCDC-ACC-B0001	active	2026-01-19 04:04:14.534435
370169b3-874f-4358-9ef5-6d319ff71c30	f2739382-95a8-4197-ace0-bd1bcc5c1a11	business	78f0a170-818b-4b72-8447-9b5c7def9f42	NCDC-ACC-B0002	active	2026-01-19 04:04:14.534435
f377959e-3144-4877-b5db-e2abe6295103	90c57094-13e2-42f1-be1f-1a1b50595f70	citizen	7a093521-cf5e-424f-96c5-71bd02edefb6	NCDC-ACC-C0001	active	2026-01-19 13:30:22.631606
d57a14bb-127b-4b42-aa68-f81b720e65ec	90c57094-13e2-42f1-be1f-1a1b50595f70	citizen	e5731d8f-a7d8-4768-8ee5-b8cd13f70110	NCDC-ACC-C0002	active	2026-01-19 13:30:22.631606
19e005e2-bda3-4102-8a51-cfef552c6f85	90c57094-13e2-42f1-be1f-1a1b50595f70	business	c3611e79-fed6-43c1-b8e4-b689cac27471	NCDC-ACC-B0001	active	2026-01-19 13:30:22.631606
0f9f2d57-7b7f-4d21-8d44-bc22f9e653f2	90c57094-13e2-42f1-be1f-1a1b50595f70	business	c994ada8-ac06-4b71-9a23-b61c4f1364ce	NCDC-ACC-B0002	active	2026-01-19 13:30:22.631606
\.


--
-- Data for Name: assets; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.assets (asset_id, council_id, asset_no, name, type, location, condition, value, status, created_at) FROM stdin;
9a57b801-2e55-4a5c-9b92-e5dab6d828c7	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	AST-002	Konedobu Council Depot	building	Konedobu	fair	PGK 2,500,000	active	2026-01-14 06:40:16.298341
7f10e8f9-e94b-4179-a2ae-6b2a9a81d030	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	AST-003	Toyota Hilux Fleet #4	vehicle	City Hall Garage	excellent	PGK 120,000	active	2026-01-14 06:40:16.298341
74661d8f-c32a-4ae8-ae3c-91c6dfe0e2bd	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	AST-004	Waigani Community Hall	building	Waigani	good	PGK 850,000	active	2026-01-14 06:40:16.298341
5669a834-544a-463e-8ace-45c1c60a6b7f	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	ABG 123	Toyota Landcruiser	Motor Vehicle	Main Office	excellent	540000	active	2026-01-18 16:46:04.69329
15867a75-440c-4aa7-bdd4-827700453de7	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	AST-001	Boroko Market Stall Block A	market_facility	Boroko	good	PGK 15,000	active	2026-01-14 06:40:16.298341
e396be72-a6fa-4ae5-8900-d47b0dedcb3b	f2739382-95a8-4197-ace0-bd1bcc5c1a11	AST-001	Boroko Market Stall Block A	market_facility	Boroko	good	PGK 15,000	active	2026-01-19 04:04:14.595026
9f457865-5f7a-4d39-8e20-44d062bd05fb	f2739382-95a8-4197-ace0-bd1bcc5c1a11	AST-002	Konedobu Council Depot	building	Konedobu	fair	PGK 2,500,000	active	2026-01-19 04:04:14.595026
94e7b37a-453e-414a-aba2-0e09ef37bf5f	f2739382-95a8-4197-ace0-bd1bcc5c1a11	AST-003	Toyota Hilux Fleet #4	vehicle	City Hall Garage	excellent	PGK 120,000	active	2026-01-19 04:04:14.595026
b0a0af31-00a6-46d7-844d-5d8db38abd07	f2739382-95a8-4197-ace0-bd1bcc5c1a11	AST-004	Waigani Community Hall	building	Waigani	good	PGK 850,000	active	2026-01-19 04:04:14.595026
b0f2896c-19cb-4581-be91-7b2b03d526e6	90c57094-13e2-42f1-be1f-1a1b50595f70	AST-001	Boroko Market Stall Block A	market_facility	Boroko	good	PGK 15,000	active	2026-01-19 13:30:22.686791
47127820-a7f6-45c4-b6d6-81f2365f33e2	90c57094-13e2-42f1-be1f-1a1b50595f70	AST-002	Konedobu Council Depot	building	Konedobu	fair	PGK 2,500,000	active	2026-01-19 13:30:22.686791
78daf055-44c4-43bc-9822-ee749dbb0282	90c57094-13e2-42f1-be1f-1a1b50595f70	AST-003	Toyota Hilux Fleet #4	vehicle	City Hall Garage	excellent	PGK 120,000	active	2026-01-19 13:30:22.686791
5de4662c-559e-4b97-ba09-666eab4eeaec	90c57094-13e2-42f1-be1f-1a1b50595f70	AST-004	Waigani Community Hall	building	Waigani	good	PGK 850,000	active	2026-01-19 13:30:22.686791
\.


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.audit_logs (audit_id, council_id, user_id, action, entity_type, entity_id, before_state, after_state, ip_address, created_at) FROM stdin;
017e5d3d-64e1-446d-9f62-6dd73236cdd0	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	\N	update	citizen	edb0bb1c-b524-4d3d-b9d6-3c59572eb35d	{"dob": "1985-03-15", "sex": "male", "email": "mkila@email.pg", "phone": "+675 7234 5678", "address": "Section 45, Lot 12, Boroko", "village": "Hanuabada", "district": "Port Moresby", "lastName": "Kila", "province": "Central Province", "citizenId": "edb0bb1c-b524-4d3d-b9d6-3c59572eb35d", "councilId": "3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3", "createdAt": "2026-01-14T06:40:16.246Z", "firstName": "Michael", "nationalId": "NID-2024-00123", "localCitizenNo": "NCDC-CIT-0001"}	{"dob": "1985-03-15", "sex": "male", "email": "mkila@email.pg", "phone": "+675 7234 5678", "address": "Section 45, Lot 12, Boroko", "village": "Hanuabada", "district": "Moresby North-West", "lastName": "Kila", "province": "National Capital District", "citizenId": "edb0bb1c-b524-4d3d-b9d6-3c59572eb35d", "councilId": "3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3", "createdAt": "2026-01-14T06:40:16.246Z", "firstName": "Michael", "nationalId": "NID-2024-00123", "localCitizenNo": "NCDC-CIT-0001"}	system	2026-01-14 17:53:38.635903
8e7f15f0-6a2d-4f2f-bbf0-ef9d0f117587	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	\N	update	citizen	3ddb05da-6712-4db8-b25c-2106711cc6b6	{"dob": "1992-07-22", "lot": null, "sex": "female", "block": null, "email": "stoua@email.pg", "phone": "+675 7345 6789", "suburb": null, "address": "Section 12, Lot 8, Gordons", "section": null, "village": null, "district": "Port Moresby", "lastName": "Toua", "province": "NCD", "citizenId": "3ddb05da-6712-4db8-b25c-2106711cc6b6", "councilId": "3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3", "createdAt": "2026-01-14T06:40:16.251Z", "firstName": "Sarah", "nationalId": "NID-2024-00456", "localCitizenNo": "NCDC-CIT-0002"}	{"dob": "1992-07-22", "lot": "88", "sex": "female", "block": "", "email": "stoua@email.pg", "phone": "+675 7345 6789", "suburb": "", "address": "", "section": "92", "village": "Hanuabada", "district": "Kairuku-Hiri", "lastName": "Toua", "province": "Central", "citizenId": "3ddb05da-6712-4db8-b25c-2106711cc6b6", "councilId": "3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3", "createdAt": "2026-01-14T06:40:16.251Z", "firstName": "Sarah", "nationalId": "NID-2024-00456", "localCitizenNo": "NCDC-CIT-0002"}	system	2026-01-15 04:56:00.272335
6615a754-5a8b-476a-84f1-1a6e01574bbf	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	\N	update	citizen	edb0bb1c-b524-4d3d-b9d6-3c59572eb35d	{"dob": "1985-03-15", "lot": null, "sex": "male", "block": null, "email": "mkila@email.pg", "phone": "+675 7234 5678", "suburb": null, "address": "Section 45, Lot 12, Boroko", "section": null, "village": "Hanuabada", "district": "Moresby North-West", "lastName": "Kila", "province": "National Capital District", "citizenId": "edb0bb1c-b524-4d3d-b9d6-3c59572eb35d", "councilId": "3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3", "createdAt": "2026-01-14T06:40:16.246Z", "firstName": "Michael", "nationalId": "NID-2024-00123", "localCitizenNo": "NCDC-CIT-0001"}	{"dob": "1985-03-15", "lot": "98", "sex": "male", "block": "", "email": "mkila@email.pg", "phone": "+675 7234 5678", "suburb": "", "address": "Section 45, Lot 12, Boroko", "section": "91", "village": "Hanuabada", "district": "Moresby North-West", "lastName": "Kila", "province": "National Capital District", "citizenId": "edb0bb1c-b524-4d3d-b9d6-3c59572eb35d", "councilId": "3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3", "createdAt": "2026-01-14T06:40:16.246Z", "firstName": "Michael", "nationalId": "NID-2024-00123", "localCitizenNo": "NCDC-CIT-0001"}	system	2026-01-15 04:56:50.506195
c1698470-c018-46c7-abb2-bff718b904cd	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	\N	update	citizen	edb0bb1c-b524-4d3d-b9d6-3c59572eb35d	{"dob": "1985-03-15", "lot": "98", "sex": "male", "block": "", "email": "mkila@email.pg", "phone": "+675 7234 5678", "suburb": "", "address": "Section 45, Lot 12, Boroko", "section": "91", "village": "Hanuabada", "district": "Moresby North-West", "lastName": "Kila", "province": "National Capital District", "citizenId": "edb0bb1c-b524-4d3d-b9d6-3c59572eb35d", "councilId": "3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3", "createdAt": "2026-01-14T06:40:16.246Z", "firstName": "Michael", "nationalId": "NID-2024-00123", "localCitizenNo": "NCDC-CIT-0001"}	{"dob": "1985-03-15", "lot": "98", "sex": "male", "block": "", "email": "mkila@email.pg", "phone": "+675 7234 5678", "suburb": "", "address": "Kikila", "section": "91", "village": "Hanuabada", "district": "Moresby North-West", "lastName": "Kila", "province": "National Capital District", "citizenId": "edb0bb1c-b524-4d3d-b9d6-3c59572eb35d", "councilId": "3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3", "createdAt": "2026-01-14T06:40:16.246Z", "firstName": "Michael", "nationalId": "NID-2024-00123", "localCitizenNo": "NCDC-CIT-0001"}	system	2026-01-15 04:57:20.397698
4aee6a03-e8bc-4202-a749-10a7b3604229	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	\N	update	citizen	3ddb05da-6712-4db8-b25c-2106711cc6b6	{"dob": "1992-07-22", "lot": "88", "sex": "female", "block": "", "email": "stoua@email.pg", "phone": "+675 7345 6789", "suburb": "", "address": "", "section": "92", "village": "Hanuabada", "district": "Kairuku-Hiri", "lastName": "Toua", "province": "Central", "citizenId": "3ddb05da-6712-4db8-b25c-2106711cc6b6", "councilId": "3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3", "createdAt": "2026-01-14T06:40:16.251Z", "firstName": "Sarah", "nationalId": "NID-2024-00456", "localCitizenNo": "NCDC-CIT-0002"}	{"dob": "1992-07-22", "lot": "88", "sex": "female", "block": "", "email": "stoua@email.pg", "phone": "+675 7345 6789", "suburb": "", "address": "Papa", "section": "92", "village": "Hanuabada", "district": "Kairuku-Hiri", "lastName": "Toua", "province": "Central", "citizenId": "3ddb05da-6712-4db8-b25c-2106711cc6b6", "councilId": "3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3", "createdAt": "2026-01-14T06:40:16.251Z", "firstName": "Sarah", "nationalId": "NID-2024-00456", "localCitizenNo": "NCDC-CIT-0002"}	system	2026-01-15 04:57:51.149829
503548f8-d9d7-4f58-aa37-e57a444f670f	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	\N	update	business	1c0bf792-8d5b-466a-acc5-83bbcf22e979	{"lot": "5", "tin": "TIN-987654321", "status": "active", "suburb": "Gordons", "section": "32", "industry": "Retail", "councilId": "3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3", "createdAt": "2026-01-14T06:40:16.254Z", "legalName": "Papindo Trading Limited", "ownerName": "John Kamaso", "businessId": "1c0bf792-8d5b-466a-acc5-83bbcf22e979", "ownerUserId": null, "tradingName": "Papindo Supermarket", "businessType": "Company", "contactEmail": "info@papindo.pg", "contactPhone": "+675 325 1234", "registrationNo": "BIZ-2020-0045", "physicalAddress": "Section 32, Lot 5, Gordons", "isForeignEnterprise": false}	{"lot": "84", "tin": "TIN-987654321", "status": "active", "suburb": "Gordons", "section": "32", "industry": "Retail", "councilId": "3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3", "createdAt": "2026-01-14T06:40:16.254Z", "legalName": "Papindo Trading Limited", "ownerName": "John Kamaso", "businessId": "1c0bf792-8d5b-466a-acc5-83bbcf22e979", "ownerUserId": null, "tradingName": "Papindo Supermarket", "businessType": "Company", "contactEmail": "info@papindo.pg", "contactPhone": "+675 325 1234", "registrationNo": "BIZ-2020-0045", "physicalAddress": "Section 32, Lot 5, Gordons", "isForeignEnterprise": false}	system	2026-01-15 06:13:24.486203
c10c7e12-935e-4e3f-9054-7780b809d400	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	\N	review_document	document	9aaff19b-72ac-4c79-9501-46d105847003	{"status": "pending"}	{"status": "approved"}	system	2026-01-18 16:52:29.779661
5eaf5109-58b5-42c6-97aa-08ea45841398	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	\N	review_document	document	63bd05c2-9d22-4fe8-b096-02c038fad669	{"status": "pending"}	{"status": "approved"}	system	2026-01-18 16:52:33.733364
548fdd37-487c-44c4-8c60-45289991fb68	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	\N	update	business	3f8febd7-1aae-45b1-a512-2013c5d697f2	{"lot": "6", "tin": "12345678523456435", "status": "active", "suburb": "Town", "section": "28", "industry": "Retail", "councilId": "3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3", "createdAt": "2026-01-15T19:21:25.657Z", "legalName": "Hamney Enterprises", "ownerName": "Lawrence Mukombo", "businessId": "3f8febd7-1aae-45b1-a512-2013c5d697f2", "ownerUserId": null, "tradingName": "Hanmey Enterprises", "businessType": "sole_trader", "contactEmail": "hamney@gmail.com", "contactPhone": "+67571693959", "registrationNo": "", "physicalAddress": "Independence Boulevard", "isForeignEnterprise": false}	{"lot": "6", "tin": "TIN-523456435", "status": "active", "suburb": "Town", "section": "28", "industry": "Retail", "councilId": "3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3", "createdAt": "2026-01-15T19:21:25.657Z", "legalName": "Hamney Enterprises", "ownerName": "Lawrence Mukombo", "businessId": "3f8febd7-1aae-45b1-a512-2013c5d697f2", "ownerUserId": null, "tradingName": "Hanmey Enterprises", "businessType": "sole_trader", "contactEmail": "hamney@gmail.com", "contactPhone": "+67571693959", "registrationNo": "PNG0012333667", "physicalAddress": "Independence Boulevard", "isForeignEnterprise": false}	system	2026-01-15 19:22:09.593139
58c7dc0d-3e91-4243-8fbe-ce865d0b6d71	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	\N	update	business	9503c736-dfe0-4973-9cf8-129383661614	{"lot": "22", "tin": "TIN-123456789", "block": null, "status": "active", "suburb": "Waigani", "section": "14", "village": null, "district": null, "industry": "Healthcare", "latitude": null, "province": null, "councilId": "3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3", "createdAt": "2026-01-14T06:40:16.259Z", "legalName": "City Pharmacy PNG", "longitude": null, "ownerName": "Maria Santos", "businessId": "9503c736-dfe0-4973-9cf8-129383661614", "ownerUserId": null, "tradingName": "City Pharmacy Waigani", "businessType": "Company", "contactEmail": "waigani@citypharmacy.pg", "contactPhone": "+675 325 5678", "registrationNo": "BIZ-2021-0112", "physicalAddress": "Section 14, Lot 22, Waigani", "isForeignEnterprise": false}	{"lot": "22", "tin": "TIN-123456789", "block": "", "status": "active", "suburb": "Waigani", "section": "14", "village": "Boroko", "district": "Moresby North-East", "industry": "Healthcare", "latitude": -9.479851, "province": "National Capital District", "councilId": "3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3", "createdAt": "2026-01-14T06:40:16.259Z", "legalName": "City Pharmacy PNG", "longitude": 147.1489, "ownerName": "Maria Santos", "businessId": "9503c736-dfe0-4973-9cf8-129383661614", "ownerUserId": null, "tradingName": "City Pharmacy Waigani", "businessType": "Company", "contactEmail": "waigani@citypharmacy.pg", "contactPhone": "+675 325 5678", "registrationNo": "BIZ-2021-0112", "physicalAddress": "Section 14, Lot 22, Waigani", "isForeignEnterprise": false}	system	2026-01-17 23:09:14.15528
08d5fb05-2805-4ba7-a124-f8a68a790422	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	\N	update	business	1c0bf792-8d5b-466a-acc5-83bbcf22e979	{"lot": "84", "tin": "TIN-987654321", "block": null, "status": "active", "suburb": "Gordons", "section": "32", "village": null, "district": null, "industry": "Retail", "latitude": null, "province": null, "councilId": "3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3", "createdAt": "2026-01-14T06:40:16.254Z", "legalName": "Papindo Trading Limited", "longitude": null, "ownerName": "John Kamaso", "businessId": "1c0bf792-8d5b-466a-acc5-83bbcf22e979", "ownerUserId": null, "tradingName": "Papindo Supermarket", "businessType": "Company", "contactEmail": "info@papindo.pg", "contactPhone": "+675 325 1234", "registrationNo": "BIZ-2020-0045", "physicalAddress": "Section 32, Lot 5, Gordons", "isForeignEnterprise": false}	{"lot": "84", "tin": "TIN-987654321", "block": "", "status": "active", "suburb": "Gordons", "section": "32", "village": "Town", "district": "Moresby North-West", "industry": "Retail", "latitude": -9.479851, "province": "National Capital District", "councilId": "3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3", "createdAt": "2026-01-14T06:40:16.254Z", "legalName": "Papindo Trading Limited", "longitude": 147.1489, "ownerName": "John Kamaso", "businessId": "1c0bf792-8d5b-466a-acc5-83bbcf22e979", "ownerUserId": null, "tradingName": "Papindo Supermarket", "businessType": "company", "contactEmail": "info@papindo.pg", "contactPhone": "+675 325 1234", "registrationNo": "BIZ-2020-0045", "physicalAddress": "Section 32, Lot 5, Gordons", "isForeignEnterprise": false}	system	2026-01-17 23:10:18.351689
6e9bc898-fc7b-425e-a7fc-692a60a42ec3	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	\N	status_change	service_request	48967986-6b8b-430f-960f-056a7620b906	{"status": "submitted"}	{"status": "processing"}	system	2026-01-17 23:58:58.040869
02fdc392-0cfa-464e-9a4c-bc2eb859271b	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	\N	status_change	service_request	2263b419-d125-4e00-ad7e-18b365b3af8e	{"status": "submitted"}	{"status": "processing"}	system	2026-01-18 01:18:51.218144
dc9ed8f2-b061-4f9f-a51e-6f47c8d72ff3	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	\N	status_change	service_request	2263b419-d125-4e00-ad7e-18b365b3af8e	{"status": "processing"}	{"status": "rejected"}	system	2026-01-18 01:19:28.933982
121b4094-71b5-4337-be65-de0f01f67140	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	\N	update	business	bcc966f0-cf72-4b73-85ee-f1d1b8f196e4	{"lot": "90", "tin": "TIN-573972383622", "block": "Baruni", "status": "active", "suburb": "Baruni", "section": "84", "village": "Baruni", "district": "Moresby North-West", "industry": "Oil&Gas", "latitude": -9.4438, "province": "National Capital District", "councilId": "3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3", "createdAt": "2026-01-18T07:13:54.075Z", "legalName": "Swan Swift", "longitude": 147.1803, "ownerName": "George Swan", "businessId": "bcc966f0-cf72-4b73-85ee-f1d1b8f196e4", "ownerUserId": null, "tradingName": "Swan", "businessType": "company", "contactEmail": "info@swan.com.pg", "contactPhone": "+67571693959", "registrationNo": "", "physicalAddress": "Napa-Napa Rd", "isForeignEnterprise": false}	{"lot": "90", "tin": "TIN-573972383622", "block": "Baruni", "status": "active", "suburb": "Baruni", "section": "84", "village": "Baruni", "district": "Moresby North-West", "industry": "Oil&Gas", "latitude": -9.4438, "province": "National Capital District", "councilId": "3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3", "createdAt": "2026-01-18T07:13:54.075Z", "legalName": "Swan Swift", "longitude": 147.1803, "ownerName": "George Swan", "businessId": "bcc966f0-cf72-4b73-85ee-f1d1b8f196e4", "ownerUserId": null, "tradingName": "Swan", "businessType": "company", "contactEmail": "info@swan.com.pg", "contactPhone": "+67571693959", "registrationNo": "BIZ-5677348", "physicalAddress": "Napa-Napa Rd", "isForeignEnterprise": false}	system	2026-01-18 07:15:21.39501
15c05773-ca5a-411e-89b1-f82dc97687ad	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	\N	review_document	document	089ceafd-aa88-4c46-ac99-e1d0bb8da498	{"status": "pending"}	{"status": "approved"}	system	2026-01-18 07:23:00.095838
db850db1-8566-4ee0-abcf-df50fbb66115	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	a43cc5b6-043b-44e7-9320-34a39a0acb11	status_change	service_request	163cf2e6-8653-4d88-8daa-67c8c7bf20fd	{"status": "processing"}	{"status": "inspection"}	system	2026-01-18 16:52:57.490076
727190fa-71e6-4f87-9bdd-778379a43105	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	a43cc5b6-043b-44e7-9320-34a39a0acb11	status_change	service_request	163cf2e6-8653-4d88-8daa-67c8c7bf20fd	{"status": "inspection"}	{"status": "approved"}	system	2026-01-18 16:53:11.249782
96267a81-4d59-4356-8f2e-581bd1772dd9	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	\N	update	business	d3329bb0-5fa5-42ab-99a8-af5dc0398fe1	{"lot": "97", "tin": "TIN-77382377", "block": "", "status": "active", "suburb": "Gerehu", "section": "76", "village": "Gerehu", "district": "Moresby North-East", "industry": "General Mechandise", "latitude": -9.4438, "province": "National Capital District", "councilId": "3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3", "createdAt": "2026-01-18T16:00:59.928Z", "legalName": "Gaot Enterprises Ltd", "longitude": 147.1803, "ownerName": "Francis Sakal", "businessId": "d3329bb0-5fa5-42ab-99a8-af5dc0398fe1", "ownerUserId": null, "tradingName": "Gaot Enterprises", "businessType": "company", "contactEmail": "gaot@gmail.com", "contactPhone": "+67572896734", "registrationNo": "", "physicalAddress": "56 Gerehu Drive, NCD", "isForeignEnterprise": false}	{"lot": "97", "tin": "TIN-77382377", "block": "", "status": "active", "suburb": "Gerehu", "section": "76", "village": "Gerehu", "district": "Moresby North-East", "industry": "General Mechandise", "latitude": -9.4438, "province": "National Capital District", "councilId": "3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3", "createdAt": "2026-01-18T16:00:59.928Z", "legalName": "Gaot Enterprises Ltd", "longitude": 147.1803, "ownerName": "Francis Sakal", "businessId": "d3329bb0-5fa5-42ab-99a8-af5dc0398fe1", "ownerUserId": null, "tradingName": "Gaot Enterprises", "businessType": "company", "contactEmail": "gaot@gmail.com", "contactPhone": "+67572896734", "registrationNo": "", "physicalAddress": "56 Gerehu Drive, NCD", "isForeignEnterprise": false}	system	2026-01-18 16:01:27.948721
7762e853-7c77-411d-a70b-d2ef2f3c5b27	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	\N	review_document	document	48e07799-64da-4315-a238-883ed26fb8a0	{"status": "pending"}	{"status": "approved"}	system	2026-01-18 16:07:39.372194
ffb198dc-546c-4a3b-b1e6-17843994d594	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	\N	review_document	document	e3e670a9-93ac-4fe8-8582-5ca1aa886369	{"status": "pending"}	{"status": "approved"}	system	2026-01-18 16:07:53.189581
8fc9ef93-d726-4e34-96bd-22de189d7a11	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	\N	review_document	document	0f3c3540-b077-4344-822f-ae2b9495f2aa	{"status": "pending"}	{"status": "approved"}	system	2026-01-18 16:08:00.303936
3adcffd0-7b4e-4541-9dd9-19257ba78c65	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	\N	review_document	document	bf4d9d3b-4d14-4f1b-bc4a-095964db691d	{"status": "pending"}	{"status": "approved"}	system	2026-01-18 16:08:06.701328
769ce1d0-3388-4e97-8dea-589c85b2a45b	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	\N	status_change	service_request	c206729f-0afa-4157-88d6-9c90ff876107	{"status": "submitted"}	{"status": "processing"}	system	2026-01-18 16:08:10.698068
3e3fa0d4-8fd1-4f49-b57d-b3bce0c4933d	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	\N	review_document	document	98af3981-ff03-4dc6-9697-b74f9f8d383b	{"status": "pending"}	{"status": "approved"}	system	2026-01-18 16:08:11.919436
ed9af267-8fe0-4863-8fa0-45efc6750887	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	\N	review_document	document	4dc1e059-e253-48b8-ad31-6f25add9c5a9	{"status": "pending"}	{"status": "approved"}	system	2026-01-18 16:08:16.738713
ea26f359-2405-48e9-b596-233dccaa5ea6	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	\N	review_document	document	dda12099-12a2-4aae-b332-919e3e7801dd	{"status": "pending"}	{"status": "approved"}	system	2026-01-18 16:08:20.915934
86b086fa-ca72-46c4-996a-fe969c660172	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	\N	review_document	document	98c485a9-825f-4627-8847-92a9e997d17a	{"status": "pending"}	{"status": "approved"}	system	2026-01-18 16:08:29.967332
32aea83a-531c-45ce-89c2-9e78b668c71c	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	\N	status_change	service_request	c206729f-0afa-4157-88d6-9c90ff876107	{"status": "processing"}	{"status": "inspection"}	system	2026-01-18 16:09:40.654745
efe37e2b-b334-4ba2-8435-04242c9c33cf	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	\N	status_change	service_request	c206729f-0afa-4157-88d6-9c90ff876107	{"status": "inspection"}	{"status": "approved"}	system	2026-01-18 16:10:38.686437
c9a93521-f005-40a2-aed3-d8cf167948a9	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	\N	update	business	f40ff078-c74a-4688-9aea-d3f01d23dedd	{"lot": "98", "tin": "TIN-2355367", "block": "", "status": "active", "suburb": "Waigani", "section": "76", "village": "Waigani", "district": "Moresby North-East", "industry": "Services", "latitude": -9.486349, "province": "National Capital District", "councilId": "3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3", "createdAt": "2026-01-18T16:44:41.102Z", "legalName": "NCDC Ltd", "longitude": 147.19284, "ownerName": "NCDC", "businessId": "f40ff078-c74a-4688-9aea-d3f01d23dedd", "ownerUserId": null, "tradingName": "NCDC", "businessType": "ngo", "contactEmail": "test@ncdc.gov.pg", "contactPhone": "+67583225563", "registrationNo": "", "physicalAddress": "Plot 4563 Waigani", "isForeignEnterprise": false}	{"lot": "98", "tin": "TIN-2355367", "block": "", "status": "active", "suburb": "Waigani", "section": "76", "village": "Waigani", "district": "Moresby North-East", "industry": "Services", "latitude": -9.486349, "province": "National Capital District", "councilId": "3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3", "createdAt": "2026-01-18T16:44:41.102Z", "legalName": "NCDC Ltd", "longitude": 147.19284, "ownerName": "NCDC", "businessId": "f40ff078-c74a-4688-9aea-d3f01d23dedd", "ownerUserId": null, "tradingName": "NCDC", "businessType": "ngo", "contactEmail": "test@ncdc.gov.pg", "contactPhone": "+67583225563", "registrationNo": "", "physicalAddress": "Plot 4563 Waigani", "isForeignEnterprise": false}	system	2026-01-18 16:45:05.437925
d118f069-948c-4db3-b281-2f42f36b199e	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	a43cc5b6-043b-44e7-9320-34a39a0acb11	status_change	service_request	163cf2e6-8653-4d88-8daa-67c8c7bf20fd	{"status": "submitted"}	{"status": "processing"}	system	2026-01-18 16:51:20.762931
cb678c4f-9d4e-4dbc-a0e3-56e2b5863333	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	\N	review_document	document	4d8b9e4f-bd74-4191-8abf-f76fdd2b5cd9	{"status": "pending"}	{"status": "approved"}	system	2026-01-18 16:51:34.230679
9015cc7d-40c9-4f72-b78e-362ae63d7d5b	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	\N	review_document	document	ebc0bfbd-e91b-4a9c-819c-d3f2aad87f85	{"status": "pending"}	{"status": "approved"}	system	2026-01-18 16:51:42.554908
f787d4f5-3294-46ed-87d5-917083a5ef46	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	\N	review_document	document	5011b5dd-1ad5-4b2f-8ca8-e1924c587791	{"status": "pending"}	{"status": "approved"}	system	2026-01-18 16:51:48.002418
dd1d29ba-25e6-45b2-bbfe-cdb02932cc52	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	\N	review_document	document	9cecf4cb-535a-4569-abea-319e55e8edd0	{"status": "pending"}	{"status": "approved"}	system	2026-01-18 16:51:54.430958
f8a12c1a-4d06-48a5-bbad-af1b7d314eef	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	\N	review_document	document	ca668143-1d45-48d4-8cb9-e93e4f81625d	{"status": "pending"}	{"status": "approved"}	system	2026-01-18 16:52:00.273092
f1912822-ce4d-4a76-ab95-0e16664591cc	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	\N	review_document	document	d95c0da9-b5bc-49f6-b4c0-1c21a4a3ebe7	{"status": "pending"}	{"status": "approved"}	system	2026-01-18 16:52:08.35151
1e890b20-fb4c-4ffa-804c-3f98a3efee12	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	\N	review_document	document	cab31302-8851-49d3-8897-dd700b669d9c	{"status": "pending"}	{"status": "approved"}	system	2026-01-18 16:52:25.213112
0122cde5-0818-4bdc-9ee3-e2483a081b56	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	\N	create	licence	963fa233-61a2-4804-9499-40ebaa8166d9	\N	{"status": "active", "councilId": "3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3", "createdAt": "2026-01-18T19:52:56.108Z", "issueDate": "2026-01-18", "licenceId": "963fa233-61a2-4804-9499-40ebaa8166d9", "licenceNo": "LIC-2026-6373", "requestId": "cce4af46-d401-445f-a59e-d9371f0d9265", "expiryDate": "2027-01-18"}	system	2026-01-18 19:52:56.135438
40c6b31e-7179-43ea-9d20-48785089b083	council-123	\N	create	payment	80e1872e-de17-4eca-a180-0d0052a30125	\N	{"amount": "100.00", "method": "cash", "paidAt": "2026-01-18T11:38:02.991Z", "status": "completed", "currency": "PGK", "provider": null, "accountId": "acc-123", "councilId": "council-123", "createdAt": "2026-01-18T21:38:03.124Z", "paymentId": "80e1872e-de17-4eca-a180-0d0052a30125", "paymentRef": "REF-123", "paymentDetails": null, "externalReference": null}	system	2026-01-18 21:38:03.14539
a3ec9b45-f8b5-4577-85a0-b7a4b9427fcd	council-123	\N	create	payment	c2d33e03-cc41-485b-948a-6f1b085da840	\N	{"amount": "100.00", "method": "cash", "paidAt": "2026-01-18T11:39:41.926Z", "status": "completed", "currency": "PGK", "provider": null, "accountId": "acc-123", "councilId": "council-123", "createdAt": "2026-01-18T21:39:42.064Z", "paymentId": "c2d33e03-cc41-485b-948a-6f1b085da840", "paymentRef": "REF-123", "paymentDetails": null, "externalReference": null}	system	2026-01-18 21:39:42.085903
37e741b6-2162-41a4-9a02-f0df80190365	council-123	\N	create	payment	10c0b9df-84e5-4ce3-9147-dac4b4b11c3c	\N	{"amount": "100.00", "method": "cash", "paidAt": "2026-01-18T11:41:58.704Z", "status": "completed", "currency": "PGK", "provider": null, "accountId": "acc-123", "councilId": "council-123", "createdAt": "2026-01-18T21:41:58.819Z", "paymentId": "10c0b9df-84e5-4ce3-9147-dac4b4b11c3c", "paymentRef": "REF-123", "paymentDetails": null, "externalReference": null}	system	2026-01-18 21:41:58.828829
c2630a7f-4f5f-4c20-aa5b-1b8876d598cc	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	\N	create	payment	f2cdb45e-3837-412d-92ef-2b34b8ca29a5	\N	{"amount": "500.00", "method": "cash", "paidAt": "2026-01-18T11:44:41.067Z", "status": "completed", "currency": "PGK", "provider": null, "accountId": "citizen-account-id", "councilId": "3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3", "createdAt": "2026-01-18T21:44:41.174Z", "paymentId": "f2cdb45e-3837-412d-92ef-2b34b8ca29a5", "paymentRef": "163cf2e6-8653-4d88-8daa-67c8c7bf20fd", "paymentDetails": {}, "externalReference": "REF-7746200"}	system	2026-01-18 21:44:41.192297
82f8f90d-d3b0-4bfe-bfa4-9d0096066e5e	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	\N	create	licence	d76602e1-b20e-4687-80ea-6c348c7d7700	\N	{"status": "active", "councilId": "3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3", "createdAt": "2026-01-18T21:44:53.884Z", "issueDate": "2026-01-18", "licenceId": "d76602e1-b20e-4687-80ea-6c348c7d7700", "licenceNo": "LIC-2026-2917", "requestId": "163cf2e6-8653-4d88-8daa-67c8c7bf20fd", "expiryDate": "2027-01-18"}	system	2026-01-18 21:44:53.897601
5cba9d32-875f-4c59-a705-fe0a1576c17e	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	\N	update	citizen	edb0bb1c-b524-4d3d-b9d6-3c59572eb35d	{"dob": "1985-03-15", "lot": "98", "sex": "male", "block": "", "email": "mkila@email.pg", "phone": "+675 7234 5678", "suburb": "", "address": "Kikila", "section": "91", "village": "Hanuabada", "district": "Moresby North-West", "lastName": "Kila", "province": "National Capital District", "citizenId": "edb0bb1c-b524-4d3d-b9d6-3c59572eb35d", "councilId": "3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3", "createdAt": "2026-01-14T06:40:16.246Z", "firstName": "Michael", "nationalId": "NID-2024-00123", "nationality": null, "localCitizenNo": "NCDC-CIT-0001"}	{"dob": "1985-03-15", "lot": "98", "sex": "male", "block": "", "email": "mkila@email.pg", "phone": "+675 7234 5678", "suburb": "", "address": "Kikila", "section": "91", "village": "Hanuabada", "district": "Moresby North-West", "lastName": "Kila", "province": "National Capital District", "citizenId": "edb0bb1c-b524-4d3d-b9d6-3c59572eb35d", "councilId": "3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3", "createdAt": "2026-01-14T06:40:16.246Z", "firstName": "Michael", "nationalId": "NID-2024-00123", "nationality": "PNG", "localCitizenNo": "NCDC-CIT-0001"}	system	2026-01-19 03:42:51.361258
b582003d-a439-41e8-bba1-0010068c2fc8	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	\N	update	business	3f8febd7-1aae-45b1-a512-2013c5d697f2	{"lot": "6", "tin": "TIN-523456435", "block": null, "status": "active", "suburb": "Town", "section": "28", "village": null, "district": null, "industry": "Retail", "latitude": null, "province": null, "councilId": "3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3", "createdAt": "2026-01-15T19:21:25.657Z", "legalName": "Hamney Enterprises", "longitude": null, "ownerName": "Lawrence Mukombo", "businessId": "3f8febd7-1aae-45b1-a512-2013c5d697f2", "ownerUserId": null, "tradingName": "Hanmey Enterprises", "businessType": "sole_trader", "contactEmail": "hamney@gmail.com", "contactPhone": "+67571693959", "registrationNo": "PNG0012333667", "physicalAddress": "Independence Boulevard", "isForeignEnterprise": false}	{"lot": "92", "tin": "TIN-523456435", "block": "", "status": "active", "suburb": "Town", "section": "28", "village": "Ramu", "district": "Middle Ramu", "industry": "Retail", "latitude": -6.0990887, "province": "Madang", "councilId": "3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3", "createdAt": "2026-01-15T19:21:25.657Z", "legalName": "Hamney Enterprises", "longitude": 145.68501, "ownerName": "Lawrence Mukombo", "businessId": "3f8febd7-1aae-45b1-a512-2013c5d697f2", "ownerUserId": null, "tradingName": "Hanmey Enterprises", "businessType": "sole_trader", "contactEmail": "hamney@gmail.com", "contactPhone": "+67571693959", "registrationNo": "PNG0012333667", "physicalAddress": "Independence Boulevard", "isForeignEnterprise": false}	system	2026-01-19 03:44:49.815829
a0f08c7e-209e-4c6b-b008-b0ab507dc4c9	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	\N	status_change	service_request	cd0419e9-5560-4105-ac03-f933a22063b9	{"status": "submitted"}	{"status": "processing"}	system	2026-01-19 03:50:51.279549
cc639042-3bda-479a-884c-d73a7fe4211e	3c4d4a9f-92a7-4dd2-82fb-ceff90c57094	\N	create	payment	cda478f3-2108-4222-97ce-34dbf7e34168	\N	{"amount": "500.00", "method": "cash", "paidAt": "2026-01-22T08:15:53.928Z", "status": "completed", "currency": "PGK", "provider": null, "accountId": "citizen-account-id", "councilId": "3c4d4a9f-92a7-4dd2-82fb-ceff90c57094", "createdAt": "2026-01-22T18:15:59.030Z", "paymentId": "cda478f3-2108-4222-97ce-34dbf7e34168", "paymentRef": "f89a1660-6f49-4b41-9b8e-72bf103f82fb", "paymentDetails": {}, "externalReference": "NCDC-662733"}	system	2026-01-22 18:16:03.83018
05c6158b-9896-4bb3-a0a3-7323171d65ef	3c4d4a9f-92a7-4dd2-82fb-ceff90c57094	\N	create	payment	a44e1af2-09a6-41de-9a9c-4cff070f92d2	\N	{"amount": "500.00", "method": "cash", "paidAt": "2026-01-22T08:16:20.162Z", "status": "completed", "currency": "PGK", "provider": null, "accountId": "citizen-account-id", "councilId": "3c4d4a9f-92a7-4dd2-82fb-ceff90c57094", "createdAt": "2026-01-22T18:16:20.958Z", "paymentId": "a44e1af2-09a6-41de-9a9c-4cff070f92d2", "paymentRef": "f89a1660-6f49-4b41-9b8e-72bf103f82fb", "paymentDetails": {}, "externalReference": "NCDC-662733"}	system	2026-01-22 18:16:21.662751
ada01aca-20c4-4536-946c-a1ba61f49ac8	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	\N	review_document	document	22360f67-f1b1-4e01-82a3-4b31c65b5c4e	{"status": "pending"}	{"status": "approved"}	system	2026-01-24 15:23:42.499382
c167960a-a336-43dc-b398-ac48bb942594	3c4d4a9f-92a7-4dd2-82fb-ceff90c57094	\N	create	payment	137b38fe-501e-4fd5-8935-5a76094b8841	\N	{"amount": "500.00", "method": "cash", "paidAt": "2026-01-22T08:28:23.388Z", "status": "completed", "currency": "PGK", "provider": null, "accountId": "citizen-account-id", "councilId": "3c4d4a9f-92a7-4dd2-82fb-ceff90c57094", "createdAt": "2026-01-22T18:28:25.762Z", "paymentId": "137b38fe-501e-4fd5-8935-5a76094b8841", "paymentRef": "f89a1660-6f49-4b41-9b8e-72bf103f82fb", "paymentDetails": {}, "externalReference": "NCDC-6637248"}	system	2026-01-22 18:28:25.922
c7f9aec4-43ea-451f-b608-547b1dabad10	3c4d4a9f-92a7-4dd2-82fb-ceff90c57094	\N	create	payment	60e40ec2-bb48-4365-8b72-5b16e79d7289	\N	{"amount": "560.00", "method": "cash", "paidAt": "2026-01-22T08:29:22.076Z", "status": "completed", "currency": "PGK", "provider": null, "accountId": "citizen-account-id", "councilId": "3c4d4a9f-92a7-4dd2-82fb-ceff90c57094", "createdAt": "2026-01-22T18:29:22.422Z", "paymentId": "60e40ec2-bb48-4365-8b72-5b16e79d7289", "paymentRef": "f89a1660-6f49-4b41-9b8e-72bf103f82fb", "paymentDetails": {}, "externalReference": "rgbbbb"}	system	2026-01-22 18:29:22.44296
a022f287-74c5-49a4-916e-665c945dcfce	3c4d4a9f-92a7-4dd2-82fb-ceff90c57094	\N	create	payment	303ee43d-21eb-40ff-9b07-dc14b26ee91c	\N	{"amount": "560.00", "method": "cash", "paidAt": "2026-01-22T08:29:46.888Z", "status": "completed", "currency": "PGK", "provider": null, "accountId": "citizen-account-id", "councilId": "3c4d4a9f-92a7-4dd2-82fb-ceff90c57094", "createdAt": "2026-01-22T18:29:47.480Z", "paymentId": "303ee43d-21eb-40ff-9b07-dc14b26ee91c", "paymentRef": "f89a1660-6f49-4b41-9b8e-72bf103f82fb", "paymentDetails": {}, "externalReference": "rgbbbb"}	system	2026-01-22 18:29:47.633815
b86dbd5b-cb74-4b15-9ae2-69d7f4a8dc09	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	\N	create	licence	7acac6c0-6e99-47da-b8bc-5de822ade391	\N	{"status": "active", "councilId": "3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3", "createdAt": "2026-01-23T15:23:43.784Z", "issueDate": "2026-01-23", "licenceId": "7acac6c0-6e99-47da-b8bc-5de822ade391", "licenceNo": "LIC-2026-7367", "requestId": "f89a1660-6f49-4b41-9b8e-72bf103f82fb", "expiryDate": "2027-01-23"}	system	2026-01-23 15:23:43.831363
f5ce599b-2fcb-4227-aa14-b6105bbde7ec	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	\N	status_change	service_request	8a6e1251-4755-44f4-8d67-503250f7e063	{"status": "processing"}	{"status": "rejected"}	system	2026-01-23 23:18:22.297119
1385a5af-94fd-4d06-a993-49a13a36724a	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	\N	review_document	document	339f6b9e-6155-4ef1-b4ef-71b2543710a8	{"status": "pending"}	{"status": "approved"}	system	2026-01-23 23:19:04.075755
61f867f4-f644-45e8-9d96-43fc7badfa3b	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	\N	review_document	document	e7d8a5da-a643-4884-89bd-7575a3c2dce1	{"status": "pending"}	{"status": "approved"}	system	2026-01-23 23:19:11.300228
0d14944c-4aa9-4f4c-9eca-c81158b58e5b	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	\N	review_document	document	718c9fc0-99ab-4678-b175-23e9dc9ff796	{"status": "pending"}	{"status": "approved"}	system	2026-01-23 23:19:17.848599
24e3b126-935f-47bc-b73e-5ce9ebfe3f6b	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	\N	review_document	document	ec7e4bf1-75fb-43ef-8018-a5327b5074f8	{"status": "pending"}	{"status": "approved"}	system	2026-01-23 23:20:20.256764
a9c6287e-4635-4f14-95d6-6494b3870775	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	\N	review_document	document	c192f3e2-cb58-4e30-b948-17770003bce6	{"status": "pending"}	{"status": "approved"}	system	2026-01-23 23:23:31.4198
399d0c16-bb17-4075-80a2-dc16686befcb	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	\N	review_document	document	aa067816-140f-4999-9641-ceb3121c3d65	{"status": "pending"}	{"status": "approved"}	system	2026-01-23 23:23:38.42031
8b857c5f-57b4-4aad-9011-478dee41cc30	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	\N	review_document	document	ad8a8bf8-4752-42de-bc5c-0254fe3941e0	{"status": "pending"}	{"status": "approved"}	system	2026-01-23 23:23:45.690114
91e0b26e-26e7-4af0-a7ae-1156bc3291e3	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	\N	review_document	document	839dc4e3-4874-48dd-a2f3-ec56614fcd12	{"status": "pending"}	{"status": "approved"}	system	2026-01-23 23:23:57.648463
8c2d8bec-abb5-4d79-a1b4-16b2db3f33de	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	\N	create	inspection	6fa4f521-3594-499b-8d73-12faacd9ffd3	\N	{"result": null, "remarks": null, "latitude": null, "councilId": "3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3", "createdAt": "2026-01-24T01:06:51.882Z", "longitude": null, "requestId": "5b2364db-ca28-4f8b-a64b-a960c7131e8f", "performedAt": null, "scheduledAt": "2026-01-26T00:00:00.000Z", "inspectionId": "6fa4f521-3594-499b-8d73-12faacd9ffd3", "inspectorUserId": null}	system	2026-01-24 01:06:51.932331
02956900-1210-4794-aec6-9a30b8769f4b	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	\N	status_change	service_request	5b2364db-ca28-4f8b-a64b-a960c7131e8f	{"status": "processing"}	{"status": "inspection"}	system	2026-01-24 01:06:55.333609
528a3ad2-c102-43c7-a98b-23d049f413f3	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	\N	status_change	service_request	5b2364db-ca28-4f8b-a64b-a960c7131e8f	{"status": "inspection"}	{"status": "approved"}	system	2026-01-24 01:08:46.306309
cf9b15b8-6a7d-4ae4-b711-97ca39e5f204	3c4d4a9f-92a7-4dd2-82fb-ceff90c57094	\N	create	inspection	587fda3c-33b1-4a60-8d1d-ebfb3ea9912c	\N	{"result": null, "remarks": null, "latitude": null, "councilId": "3c4d4a9f-92a7-4dd2-82fb-ceff90c57094", "createdAt": "2026-01-24T01:12:40.794Z", "longitude": null, "requestId": null, "performedAt": null, "scheduledAt": "2026-01-23T15:12:40.143Z", "inspectionId": "587fda3c-33b1-4a60-8d1d-ebfb3ea9912c", "inspectorUserId": null}	system	2026-01-24 01:12:40.800752
0c61851c-6399-48fe-bec0-0e300c11d9da	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	\N	review_document	document	e6449447-7cf2-464c-8f1b-e2d9311446f7	{"status": "pending"}	{"status": "approved"}	system	2026-01-24 04:10:23.953456
431f02a3-a999-457a-8c8a-10bb724565db	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	\N	review_document	document	6ac86747-8f1f-404c-a5c2-714046092dff	{"status": "pending"}	{"status": "approved"}	system	2026-01-24 04:10:33.93873
fa7cfb48-b91b-48cb-8014-e13e79f765ca	system	\N	delete_document	document	f0e75859-0cc5-4e50-adc0-03148b2f7977	{"status": "deleted"}	\N	system	2026-01-24 05:47:07.848037
d2db3b5a-9dc2-4a86-a5ad-0cef35a1fba4	system	\N	delete_document	document	e397e2fe-e603-471a-bde9-325d5295bc93	{"status": "deleted"}	\N	system	2026-01-24 05:47:16.034454
84f4f9c8-da74-4387-9b60-5987f886183b	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	\N	create	inspection	bd181d76-3ccd-4b67-98a2-b059ef8b8b60	\N	{"result": null, "remarks": null, "latitude": null, "councilId": "3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3", "createdAt": "2026-01-24T15:08:39.997Z", "longitude": null, "requestId": "163cf2e6-8653-4d88-8daa-67c8c7bf20fd", "performedAt": null, "scheduledAt": "2026-01-28T00:00:00.000Z", "inspectionId": "bd181d76-3ccd-4b67-98a2-b059ef8b8b60", "inspectorUserId": null}	system	2026-01-24 15:08:40.025267
3f14708f-6066-4212-bb6c-44c51a8f7130	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	\N	status_change	service_request	163cf2e6-8653-4d88-8daa-67c8c7bf20fd	{"status": "processing"}	{"status": "inspection"}	system	2026-01-24 15:08:44.28335
9783fc02-3448-4086-8078-e921c3096274	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	\N	status_change	service_request	163cf2e6-8653-4d88-8daa-67c8c7bf20fd	{"status": "inspection"}	{"status": "approved"}	system	2026-01-24 15:09:20.864684
d15ff7fd-3ab3-4c39-8101-f9236d7f5689	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	\N	create	licence	8ede2303-572d-4a18-b098-9466cd0c7bc8	\N	{"status": "active", "pdfHash": "1444c46ae9fbc4a0e314b41d1c22df9acdd52f6d52cc2f4ee69fd6fca1249f6c", "version": 1, "councilId": "3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3", "createdAt": "2026-01-24T15:30:29.779Z", "issueDate": "2026-01-24", "licenceId": "8ede2303-572d-4a18-b098-9466cd0c7bc8", "licenceNo": "LIC-2026-5625", "requestId": "163cf2e6-8653-4d88-8daa-67c8c7bf20fd", "expiryDate": "2027-01-24", "signedPdfHash": "eb75a8b8f0508b4d711f8aeffafe1549bda6bd7ec7e0130b5af5cd3ff32010c6", "signatureMetadata": {"issuedAt": "2026-01-24T05:30:29.772Z", "algorithm": "RSASSA-PKCS1-v1_5-SHA256", "signature": "9fb24ce6298d10c20d0109520ee611807131b924ce9cdc1e3c70dd8e73c8ac222241faa1994a6cf69bc0922b2d13d3c81e4bc7c42be2fbc168f17f041300a6df3d1d32a5d6baad660868a5069f8da0656685cf0f6101a2dc2a4aef6fa7beae9ee46dd4000356683e8acdd41da5a2c01f040ff8943f7332b2be336482eef5de12eb711b278616906cab123c70292e394508b738af2777db8577a8ad5bac435ab0bd0d7edc2a28cc48d38c11a7027a1be873f02bddb0551dc9695643fd6a388b36c7d9c149530a7b5dfd8af2999b6eadec258cb371731614753c862590319977b4164ea98278d8ea588d5924c679facabfa50fb260e307cf31907c9b2f7af00339"}, "licencePayloadHash": "7ea08557e2eaaea1ae29b3a8360c07d3efcd75fe07ed7fcd6ffca861b2fb7a5f"}	system	2026-01-24 15:30:29.806531
\.


--
-- Data for Name: business_verification_requests; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.business_verification_requests (request_id, business_id, council_id, status, submitted_at, reviewed_at, reviewed_by, comments) FROM stdin;
\.


--
-- Data for Name: businesses; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.businesses (business_id, council_id, registration_no, tin, legal_name, trading_name, business_type, industry, owner_name, owner_user_id, contact_phone, contact_email, physical_address, section, lot, suburb, status, is_foreign_enterprise, created_at, block, village, district, province, latitude, longitude) FROM stdin;
9503c736-dfe0-4973-9cf8-129383661614	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	BIZ-2021-0112	TIN-123456789	City Pharmacy PNG	City Pharmacy Waigani	Company	Healthcare	Maria Santos	\N	+675 325 5678	waigani@citypharmacy.pg	Section 14, Lot 22, Waigani	14	22	Waigani	active	f	2026-01-14 06:40:16.259455		Boroko	Moresby North-East	National Capital District	-9.479851	147.1489
1c0bf792-8d5b-466a-acc5-83bbcf22e979	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	BIZ-2020-0045	TIN-987654321	Papindo Trading Limited	Papindo Supermarket	company	Retail	John Kamaso	\N	+675 325 1234	info@papindo.pg	Section 32, Lot 5, Gordons	32	84	Gordons	active	f	2026-01-14 06:40:16.254828		Town	Moresby North-West	National Capital District	-9.479851	147.1489
bcc966f0-cf72-4b73-85ee-f1d1b8f196e4	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	BIZ-5677348	TIN-573972383622	Swan Swift	Swan	company	Oil&Gas	George Swan	\N	+67571693959	info@swan.com.pg	Napa-Napa Rd	84	90	Baruni	active	f	2026-01-18 07:13:54.075965	Baruni	Baruni	Moresby North-West	National Capital District	-9.4438	147.1803
d3329bb0-5fa5-42ab-99a8-af5dc0398fe1	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3		TIN-77382377	Gaot Enterprises Ltd	Gaot Enterprises	company	General Mechandise	Francis Sakal	\N	+67572896734	gaot@gmail.com	56 Gerehu Drive, NCD	76	97	Gerehu	active	f	2026-01-18 16:00:59.928945		Gerehu	Moresby North-East	National Capital District	-9.4438	147.1803
f40ff078-c74a-4688-9aea-d3f01d23dedd	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3		TIN-2355367	NCDC Ltd	NCDC	ngo	Services	NCDC	\N	+67583225563	test@ncdc.gov.pg	Plot 4563 Waigani	76	98	Waigani	active	f	2026-01-18 16:44:41.102115		Waigani	Moresby North-East	National Capital District	-9.486349	147.19284
3f8febd7-1aae-45b1-a512-2013c5d697f2	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	PNG0012333667	TIN-523456435	Hamney Enterprises	Hanmey Enterprises	sole_trader	Retail	Lawrence Mukombo	\N	+67571693959	hamney@gmail.com	Independence Boulevard	28	92	Town	active	f	2026-01-15 19:21:25.657061		Ramu	Middle Ramu	Madang	-6.0990887	145.68501
c3611e79-fed6-43c1-b8e4-b689cac27471	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	BIZ-2020-0045	TIN-987654321	Papindo Trading Limited	Papindo Supermarket	Company	Retail	John Kamaso	\N	+675 325 1234	info@papindo.pg	Section 32, Lot 5, Gordons	32	5	Gordons	active	f	2026-01-19 13:30:22.621264	\N	\N	\N	\N	\N	\N
c994ada8-ac06-4b71-9a23-b61c4f1364ce	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	BIZ-2021-0112	TIN-123456789	City Pharmacy PNG	City Pharmacy Waigani	Company	Healthcare	Maria Santos	\N	+675 325 5678	waigani@citypharmacy.pg	Section 14, Lot 22, Waigani	14	22	Waigani	active	f	2026-01-19 13:30:22.626323	\N	\N	\N	\N	\N	\N
3a26c163-36f7-4b66-9f95-fdc8abc7bce8	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	BIZ-2020-0045	TIN-987654321	Papindo Trading Limited	Papindo Supermarket	Company	Retail	John Kamaso	\N	+675 325 1234	info@papindo.pg	Section 32, Lot 5, Gordons	32	5	Gordons	active	f	2026-01-19 04:04:14.527664	\N	\N	\N	\N	\N	\N
78f0a170-818b-4b72-8447-9b5c7def9f42	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	BIZ-2021-0112	TIN-123456789	City Pharmacy PNG	City Pharmacy Waigani	Company	Healthcare	Maria Santos	\N	+675 325 5678	waigani@citypharmacy.pg	Section 14, Lot 22, Waigani	14	22	Waigani	active	f	2026-01-19 04:04:14.53181	\N	\N	\N	\N	\N	\N
\.


--
-- Data for Name: checklist_requirements; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.checklist_requirements (id, license_type_id, item_number, document_name, responsible_entity, requirement_note, created_at) FROM stdin;
9f5dd812-b517-4449-b1d6-0a20182fb951	3039e203-0714-4d5c-86dd-9acd1e99081f	1	Application FORM.1	NCDC	Completed form, signed and dated	2026-01-24 06:24:23.516734
bc0fcc52-9840-48b8-a35c-e8eaf345b756	3039e203-0714-4d5c-86dd-9acd1e99081f	2	Physical Planning Approvals	NCDC	Applicable if land use changes	2026-01-24 06:24:23.522537
8fd41470-d467-4e63-b155-e8260320da28	3039e203-0714-4d5c-86dd-9acd1e99081f	3	Building Authority Approvals	NCDC	Applicable if structural changes occur	2026-01-24 06:24:23.524674
79f9ffb9-acbc-4a49-901f-877fb691a129	3039e203-0714-4d5c-86dd-9acd1e99081f	4	Land Title/Lease Agreement or Consent letter	Landlord	Applicable if change of ownership or tenancy	2026-01-24 06:24:23.526841
237667d7-ec6f-4e8c-b935-67c8ba0e4af8	3039e203-0714-4d5c-86dd-9acd1e99081f	5	Radio communication Apparatus License	National Information and Technology Authority (NICTA)	Valid	2026-01-24 06:24:23.529123
8d7b1cb5-23dd-49e8-9140-1f4052df7327	3039e203-0714-4d5c-86dd-9acd1e99081f	6	Certificate of Incorporation	IPA	Local & Foreign Companies	2026-01-24 06:24:23.531446
d8d9981c-473a-41cf-9d73-265a25972bc7	3039e203-0714-4d5c-86dd-9acd1e99081f	7	Company Extract	IPA	Local & Foreign Companies	2026-01-24 06:24:23.533589
a47f2a86-9f1e-4c74-8cf2-a8735042e468	3039e203-0714-4d5c-86dd-9acd1e99081f	8	Certificate of Registration of Business Name	IPA	Valid	2026-01-24 06:24:23.535978
66950ca3-64e0-492a-b4fc-80d93f777916	3039e203-0714-4d5c-86dd-9acd1e99081f	9	Certificate Permitting Foreigners to Operate Business in PNG	IPA	Applicable if foreign owned entity	2026-01-24 06:24:23.538246
06d00bb2-f417-4f50-a45b-7a7232820cd9	3039e203-0714-4d5c-86dd-9acd1e99081f	10	Land Tax & Garbage Rate	NCDC	Evidence of payment	2026-01-24 06:24:23.539984
48efbf80-eb26-4e25-a44c-156ad5110db0	3039e203-0714-4d5c-86dd-9acd1e99081f	11	Copy of License for previous operator	Applicant	Application if COM	2026-01-24 06:24:23.541761
29fe42e6-6462-421f-975c-2af7514292ee	f948d0d4-f28b-4163-b3c6-f907a6c5d840	1	Application FORM .1	NCDC	Completed, signed and dated	2026-01-24 06:24:23.543267
6d362fdf-876a-426d-b25c-02e0acc046b7	f948d0d4-f28b-4163-b3c6-f907a6c5d840	2	Physical Planning Approvals	NCDC	Applicable if land use changes	2026-01-24 06:24:23.54476
715537f4-6ebc-4c87-9eee-23b2671f1b1d	f948d0d4-f28b-4163-b3c6-f907a6c5d840	3	Building Authority Approvals	NCDC	Applicable if structural changes occur	2026-01-24 06:24:23.546263
0e597866-0bcb-410b-82bd-ce1031bda992	f948d0d4-f28b-4163-b3c6-f907a6c5d840	4	Land Title/Lease Agreement	Landlord	Valid	2026-01-24 06:24:23.547756
c5ae5638-9a8a-4326-ac7d-062a7c224e8b	f948d0d4-f28b-4163-b3c6-f907a6c5d840	5	Certificate of Incorporation	IPA	Local and Foreign Companies	2026-01-24 06:24:23.549169
6a029c86-de0f-4029-a7dc-a9da60e90b9b	f948d0d4-f28b-4163-b3c6-f907a6c5d840	6	Company Extract	IPA	Local and Foreign Companies	2026-01-24 06:24:23.550519
05c7e7bb-8b71-4620-8c3d-3a39dcf5ca27	f948d0d4-f28b-4163-b3c6-f907a6c5d840	7	Certificate of Registration of Business Name	IPA	Valid	2026-01-24 06:24:23.551924
a3557924-27d0-43f6-b6c8-cd91b63a3a22	f948d0d4-f28b-4163-b3c6-f907a6c5d840	8	Certificate Permitting Foreigners to Operate Business in PNG	IPA	Applicable for Foreign Enterprise	2026-01-24 06:24:23.553602
cbfdf51a-9b29-4bad-a068-5845f6a3ef5c	f948d0d4-f28b-4163-b3c6-f907a6c5d840	9	Land Tax & Garbage Rates	NCDC	Evidence of payment	2026-01-24 06:24:23.555208
bb8b9262-26ab-4cc1-973d-6d09768f60ec	f948d0d4-f28b-4163-b3c6-f907a6c5d840	10	Copy of License for previous Operator	Applicant	Applicable if COM/New Ownership	2026-01-24 06:24:23.556933
ff1aeecd-1ebe-4ad2-983e-6cc67e7fb4ee	692b0796-76f8-43eb-acfa-4d9472c59535	1	Application FORM.1 Reg:Sec.5(1)	NCDC	Completed, signed and dated	2026-01-24 06:24:23.55828
e4ecaab2-21f8-472b-8582-dd8b45a938ae	692b0796-76f8-43eb-acfa-4d9472c59535	2	Physical Planning Approvals	NCDC	Applicable if land use changes	2026-01-24 06:24:23.559721
371124af-d57b-4c8e-8e7b-ebafcd8937b3	692b0796-76f8-43eb-acfa-4d9472c59535	3	Building Authority Approvals	NCDC	Applicable if structural changes occur	2026-01-24 06:24:23.561096
223edb21-3b8d-4f02-b8c3-18746410eef0	692b0796-76f8-43eb-acfa-4d9472c59535	4	Land Title/Lease Agreement	Landlord	Valid	2026-01-24 06:24:23.562501
daef8810-b7df-487a-8239-b5eacecc200a	692b0796-76f8-43eb-acfa-4d9472c59535	5	Certificate of Incorporation	IPA	Local and Foreign Companies	2026-01-24 06:24:23.563709
1fada82f-47f2-4199-a64b-5d27f220fd2c	692b0796-76f8-43eb-acfa-4d9472c59535	6	Company Extract	IPA	Local & Foreign Companies	2026-01-24 06:24:23.565154
fbcc824f-72b9-4b4e-89f1-6934d0398f26	692b0796-76f8-43eb-acfa-4d9472c59535	7	Certificate of Registration of Business Name	IPA	Valid	2026-01-24 06:24:23.566521
1c20fd58-2dc2-4418-b737-32a18975a910	692b0796-76f8-43eb-acfa-4d9472c59535	8	Certificate Permitting Foreigners to Operate Business in PNG	IPA	Applicable for Foreign Enterprise	2026-01-24 06:24:23.568357
e0e4f909-1e80-49dd-a50d-7397f246dc9f	692b0796-76f8-43eb-acfa-4d9472c59535	9	Land Tax & Garbage Rate	NCDC-Revenue	Evidence of payment	2026-01-24 06:24:23.570322
b3b1d16a-57a3-423d-94c7-908058a1d259	692b0796-76f8-43eb-acfa-4d9472c59535	10	Copy of License for previous operator	Applicant	Applicable if COM/New Ownership	2026-01-24 06:24:23.572004
9b8092e1-c81c-4363-83bd-2ce5a0ea539b	824aeb14-49d0-4e19-a5a5-dcd81f6a414d	1	Application FORM.1	NCDC	Completed, signed and dated	2026-01-24 06:24:23.573503
4d9d6806-9239-463e-af54-ade4acdd6fb9	824aeb14-49d0-4e19-a5a5-dcd81f6a414d	2	Physical Planning Approvals	NCDC	Applicable if land use changes	2026-01-24 06:24:23.575114
b13baf86-beef-40db-831a-58537523b537	824aeb14-49d0-4e19-a5a5-dcd81f6a414d	3	Building Authority Approvals	NCDC	Applicable if structural changes occur	2026-01-24 06:24:23.576688
f9dab5cc-90d7-4d2a-bf05-fc75d8d95fa5	824aeb14-49d0-4e19-a5a5-dcd81f6a414d	4	Land Title/Lease Agreement	Landlord	Valid	2026-01-24 06:24:23.578555
32c96c14-a975-4a05-a52d-60becd65056b	824aeb14-49d0-4e19-a5a5-dcd81f6a414d	5	Pharmaceutical License	NDoH-Pharmacy Board	Valid	2026-01-24 06:24:23.580204
44b3e9d5-e4d7-4615-a793-65798bdaf49d	824aeb14-49d0-4e19-a5a5-dcd81f6a414d	6	Certificate of Incorporation	IPA	Local and Foreign Companies	2026-01-24 06:24:23.581521
c6688dbd-16a0-48b4-9f50-207e93cbd9c1	824aeb14-49d0-4e19-a5a5-dcd81f6a414d	7	Company Extract	IPA	Local and Foreign Companies	2026-01-24 06:24:23.5828
e154f8f1-3ac9-47d8-b373-c09bb5f5d033	824aeb14-49d0-4e19-a5a5-dcd81f6a414d	8	Certificate of Registration of Business Name	IPA	Valid	2026-01-24 06:24:23.58439
315d4bad-95b2-4052-bc01-fe74a0230ad3	824aeb14-49d0-4e19-a5a5-dcd81f6a414d	9	Certificate Permitting Foreigners to Operate Business in PNG	IPA	Applicable for Foreign Enterprise	2026-01-24 06:24:23.587093
26b23ee9-575e-4aba-a015-888368f8d0bd	824aeb14-49d0-4e19-a5a5-dcd81f6a414d	10	Land Tax & Garbage Rate	NCDC	Evidence of payment	2026-01-24 06:24:23.589566
0d8fe6cd-67e7-4277-ac37-89bf2c533a4a	824aeb14-49d0-4e19-a5a5-dcd81f6a414d	11	Copy of License for previous operator	Applicant	Application if COM/New Ownership	2026-01-24 06:24:23.591128
4ef7d777-6ee5-4b26-b585-cd0250fe2149	97a10043-0a7a-4530-9a3b-f8a5684e6559	1	Application FORM.5	NCDC	Completed, signed and dated	2026-01-24 06:24:23.592536
bf8b1fb4-e8e8-428f-8037-105981849e87	97a10043-0a7a-4530-9a3b-f8a5684e6559	2	Certificate of Fumigation	National Department of Health (NDoH)	Valid	2026-01-24 06:24:23.593804
23e1c134-566f-43e5-8508-d9de80957b99	97a10043-0a7a-4530-9a3b-f8a5684e6559	3	Physical Planning Approvals	NCDC	Applicable if land use changes	2026-01-24 06:24:23.595122
9c0feac4-e5bb-4d45-a383-b28ff6ab1bcb	97a10043-0a7a-4530-9a3b-f8a5684e6559	4	Building Authority Approvals	NCDC	Applicable if structural changes occur	2026-01-24 06:24:23.597204
37d110bf-6f42-4db3-aafa-81051bd949a4	97a10043-0a7a-4530-9a3b-f8a5684e6559	5	Land Title/Lease Agreement	Landlord	Valid	2026-01-24 06:24:23.598558
6e4d2db0-9ba8-4a24-b956-e80f653a0643	97a10043-0a7a-4530-9a3b-f8a5684e6559	6	Certificate of Incorporation	IPA	Local and Foreign Companies	2026-01-24 06:24:23.600019
d2c92e7a-e6f5-4ba9-bd40-3b320c7e44ef	97a10043-0a7a-4530-9a3b-f8a5684e6559	7	Company Extract	IPA	Local and Foreign Companies	2026-01-24 06:24:23.60168
c315344f-be61-44bf-8aaf-60961ebee7bc	97a10043-0a7a-4530-9a3b-f8a5684e6559	8	Certificate of Registration of Business Name	IPA	Valid	2026-01-24 06:24:23.603112
20f58ca9-3de3-411f-bf32-c5847af23551	97a10043-0a7a-4530-9a3b-f8a5684e6559	9	Certificate Permitting Foreigners to Operate Business in PNG	IPA	Applicable for foreign Enterprise	2026-01-24 06:24:23.604703
82e217b0-eaa3-4a46-9d5f-919fca7333c1	97a10043-0a7a-4530-9a3b-f8a5684e6559	10	Land Tax & Garbage Rate	NCDC	Evidence of Payment	2026-01-24 06:24:23.606178
d8ab67d7-6fb2-45f4-83da-866fd9d45ad8	97a10043-0a7a-4530-9a3b-f8a5684e6559	11	Copy of License for previous Operator	Applicant	Application if COM/New Ownership	2026-01-24 06:24:23.607422
c4de6faf-0e8f-4b30-9561-a2bdf6b5de98	3630246a-9c75-45c0-b429-eca768e8ba03	1	Application FORM.1	NCDC	Completed form ,signed & dated	2026-01-24 06:24:23.608412
2a3685e1-2f84-4827-90d0-710ab6e51b32	3630246a-9c75-45c0-b429-eca768e8ba03	2	Inflammable & Dangerous Goods License/certificate	Labour Department	Valid	2026-01-24 06:24:23.609771
c0fa3e82-edec-403f-9ed3-fa21dba06679	3630246a-9c75-45c0-b429-eca768e8ba03	3	Physical Planning Approvals	NCDC	Applicable if land use changes occur	2026-01-24 06:24:23.611011
eeead87b-d884-4f8e-b746-d2e6fad645af	3630246a-9c75-45c0-b429-eca768e8ba03	4	Building Authority Approvals	NCDC	Applicable if structural changes occur	2026-01-24 06:24:23.612196
22ca59aa-fe51-4419-841a-04a9c3c0ed34	3630246a-9c75-45c0-b429-eca768e8ba03	5	Land Title/Lease Agreement or Consent letter	Landlord	Valid Lease	2026-01-24 06:24:23.613412
59e6938b-9eb4-401e-a9be-e3a6570f01c1	3630246a-9c75-45c0-b429-eca768e8ba03	6	Certificate of Incorporation	IPA	Local & Foreign Enterprise	2026-01-24 06:24:23.6147
d92eff95-c0b9-45f7-a9a6-04b1a2d29837	3630246a-9c75-45c0-b429-eca768e8ba03	7	Company Extract	IPA	Local & Foreign Enterprise	2026-01-24 06:24:23.615895
8df626c0-1e1e-47b2-9f50-8c966a3053bb	3630246a-9c75-45c0-b429-eca768e8ba03	8	Certificate of Registration of Business Name	IPA	Valid	2026-01-24 06:24:23.61724
79a6a6c2-1b2b-4fff-801a-d601a39aef4c	3630246a-9c75-45c0-b429-eca768e8ba03	9	Certificate Permitting Foreigners to Operate Business in PNG	IPA	Applicable if foreign owned entity	2026-01-24 06:24:23.618817
6755d720-0c0e-4c91-912c-ac8ec108eac5	3630246a-9c75-45c0-b429-eca768e8ba03	10	Land Tax & Garbage Rate	NCDC	Evidence of payment	2026-01-24 06:24:23.620662
f6b90d15-8b0b-41a0-895d-40cdb77f40c8	3630246a-9c75-45c0-b429-eca768e8ba03	11	Copy of License for previous operator	Applicant	Application if COM	2026-01-24 06:24:23.622409
25b9d400-1c12-435e-9292-6fe33c0e15e4	ed80198f-9d2d-49be-82f1-8d13f3b91e03	1	Application FORM.1	NCDC	Completed, signed and dated	2026-01-24 06:24:23.623781
0ab02f02-c359-421e-84dc-33439f92971a	ed80198f-9d2d-49be-82f1-8d13f3b91e03	2	Physical Planning Approvals	NCDC	Applicable if land use changes	2026-01-24 06:24:23.625277
414f49b9-af1c-4afb-9462-7ba6554d6183	ed80198f-9d2d-49be-82f1-8d13f3b91e03	3	Building Authority Approvals	NCDC	Applicable if structural changes occur	2026-01-24 06:24:23.626655
82f2671f-226e-47ef-8a47-442984f1e707	ed80198f-9d2d-49be-82f1-8d13f3b91e03	4	Land Title/Lease Agreement	Landlord	Valid	2026-01-24 06:24:23.628229
7b362392-7fab-4674-b26a-8d2a8ccc53a4	ed80198f-9d2d-49be-82f1-8d13f3b91e03	5	Factory/Manufacturer License	Labour Department	Valid	2026-01-24 06:24:23.629386
c6640d81-7603-406d-b01f-1ac78f70faf0	ed80198f-9d2d-49be-82f1-8d13f3b91e03	6	Certificate of Incorporation	IPA	Local and Foreign Companies	2026-01-24 06:24:23.630604
171a0495-d9a9-421c-8c90-4cec67239f92	ed80198f-9d2d-49be-82f1-8d13f3b91e03	7	Company Extract	IPA	Local and Foreign Companies	2026-01-24 06:24:23.631842
017ee146-cc64-4143-bdc1-9e447a5ee9ff	ed80198f-9d2d-49be-82f1-8d13f3b91e03	8	Certificate of Registration of Business Name	IPA	Valid	2026-01-24 06:24:23.633119
7e414c50-754e-4a6d-a748-5953f65d7197	ed80198f-9d2d-49be-82f1-8d13f3b91e03	9	Certificate Permitting Foreigners to Operate Business in PNG	IPA	Applicable for foreign Enterprise	2026-01-24 06:24:23.634378
355726bb-c7fb-4a42-8058-f019814ada08	ed80198f-9d2d-49be-82f1-8d13f3b91e03	10	Land Tax & Garbage Rate	NCDC	Evidence of payment	2026-01-24 06:24:23.635775
75b6febb-c486-4d02-9dbc-01e9361b3519	ed80198f-9d2d-49be-82f1-8d13f3b91e03	11	Copy of license for the previous operator	Applicant	Application if COM/New Ownership	2026-01-24 06:24:23.637211
95e71842-11e2-4185-827b-52f5c6df6588	8b20d5fd-3890-453a-88f1-5f39a3ba8356	1	Application FORM.1	NCDC	Completed, signed and dated	2026-01-24 06:24:23.63867
ddc9bc05-e66a-4d06-9073-8b0bfc55f152	8b20d5fd-3890-453a-88f1-5f39a3ba8356	2	Physical Planning Approvals	NCDC	Applicable if land use changes	2026-01-24 06:24:23.640233
b5bb938d-9fe5-4ac3-9d3a-76322f4bb68e	8b20d5fd-3890-453a-88f1-5f39a3ba8356	3	Building Authority Approvals	NCDC	Applicable if structural changes occur	2026-01-24 06:24:23.641742
c371ad6e-5b3e-4e82-87a3-f272b477ce9d	8b20d5fd-3890-453a-88f1-5f39a3ba8356	4	Land Title/Lease Agreement	Landlord	Valid	2026-01-24 06:24:23.643063
adfb99f5-e597-44e8-82d5-5bdb5f29b3eb	8b20d5fd-3890-453a-88f1-5f39a3ba8356	5	Food Safety Management System (HACCP)	Applicant	Applicable for Food Manufacturers	2026-01-24 06:24:23.644372
e16dd972-f96e-4473-a95b-be4161b47377	8b20d5fd-3890-453a-88f1-5f39a3ba8356	6	Factory/Manufacturer License	Labour Department	Valid	2026-01-24 06:24:23.645914
14c9d9b8-bcd5-4de3-b38a-a16bdb574e9e	8b20d5fd-3890-453a-88f1-5f39a3ba8356	7	Certificate of Incorporation	IPA	Local and Foreign Companies	2026-01-24 06:24:23.647336
f90c6cba-6168-4a20-97f7-5f8744ecb8a5	8b20d5fd-3890-453a-88f1-5f39a3ba8356	8	Company Extract	IPA	Local and Foreign Companies	2026-01-24 06:24:23.650999
9b908233-a27f-458f-939d-735b9c2c832d	8b20d5fd-3890-453a-88f1-5f39a3ba8356	9	Certificate of Registration of Business Name	IPA	Valid	2026-01-24 06:24:23.652661
42ac15be-e988-48c5-bad5-6d6023be77f0	8b20d5fd-3890-453a-88f1-5f39a3ba8356	10	Certificate Permitting Foreigners to Operate Business in PNG	IPA	Applicable for foreign Enterprise	2026-01-24 06:24:23.654468
8e9b3068-fac7-4bb5-85a8-53853627bba5	8b20d5fd-3890-453a-88f1-5f39a3ba8356	11	Land Tax & Garbage Rate	NCDC	Evidence of payment	2026-01-24 06:24:23.655978
6b66a886-048d-4525-9e6f-b3867cfc7ab4	8b20d5fd-3890-453a-88f1-5f39a3ba8356	12	Copy of License for previous operator	Applicant	Applicable if COM/New Ownership	2026-01-24 06:24:23.657311
6477845b-fb52-4a0e-82aa-2d7138f67b34	6c8ca3d6-01c9-42d0-abbe-69fc1d3645aa	1	Application FORM.1	NCDC	Completed, signed and dated	2026-01-24 06:24:23.658568
86423914-98dd-4c76-979d-bc9d93f222cf	6c8ca3d6-01c9-42d0-abbe-69fc1d3645aa	2	Inflammable & Dangerous Goods License/certificate	Labour Department	Valid	2026-01-24 06:24:23.659964
bb5d82be-0664-4473-9889-c9b59285afe5	6c8ca3d6-01c9-42d0-abbe-69fc1d3645aa	3	Physical Planning Approvals	NCDC	Applicable if land use changes	2026-01-24 06:24:23.661505
e55270ed-c86a-4d27-83e7-95defee460e1	6c8ca3d6-01c9-42d0-abbe-69fc1d3645aa	4	Building Authority Approvals	NCDC	Applicable if structural changes occur	2026-01-24 06:24:23.662947
d4145a88-160f-4be3-b1d4-9663e62facd4	6c8ca3d6-01c9-42d0-abbe-69fc1d3645aa	5	Land Title/Lease Agreement	Landlord	Valid	2026-01-24 06:24:23.664545
1a98954b-ad1b-4742-97f8-fcd3a4e44507	6c8ca3d6-01c9-42d0-abbe-69fc1d3645aa	6	Certificate of Incorporation	IPA	Local and Foreign Companies	2026-01-24 06:24:23.666032
64ebd9ac-e347-4060-b4e2-e5da4d4e35fc	6c8ca3d6-01c9-42d0-abbe-69fc1d3645aa	7	Company Extract	IPA	Local and Foreign Companies	2026-01-24 06:24:23.667421
401987ce-9d2c-4eb2-9ff8-2510cdd1c07c	6c8ca3d6-01c9-42d0-abbe-69fc1d3645aa	8	Certificate of Registration of Business Name	IPA	Valid	2026-01-24 06:24:23.668995
3a313a58-9c7d-4242-b483-75064e5e26b7	6c8ca3d6-01c9-42d0-abbe-69fc1d3645aa	9	Certificate Permitting Foreigners to Operate Business in PNG	IPA	Applicable for foreign Enterprise	2026-01-24 06:24:23.670804
93f6e055-d7ba-40e2-b051-8225a96be16e	6c8ca3d6-01c9-42d0-abbe-69fc1d3645aa	10	Land Tax & Garbage Rate	NCDC	Evidence of payment	2026-01-24 06:24:23.672662
895528bf-779f-4e9a-90bf-96aee70dc98d	6c8ca3d6-01c9-42d0-abbe-69fc1d3645aa	11	Copy of License for previous operator	Applicant	Applicable if COM/New Ownership	2026-01-24 06:24:23.674484
948dab82-e5f6-4fcc-8804-e70cc1b0bebf	9f564cc0-65c8-4277-9d3a-5585fb57dc3b	1	Application FORM 1	NCDC	Completed, dated and signed	2026-01-24 06:24:23.675984
ecebbdea-fdac-4ed8-873c-cb150e845417	9f564cc0-65c8-4277-9d3a-5585fb57dc3b	2	Physical planning Approvals	NCDC	Applicable if Land Use Changes	2026-01-24 06:24:23.677767
95da2000-b154-4054-b0ab-a6a62e3bf691	9f564cc0-65c8-4277-9d3a-5585fb57dc3b	3	Building Authority Approvals	NCDC	Applicable if structural changes occur	2026-01-24 06:24:23.679209
d749e540-1e51-4f38-b213-77120b9fc874	9f564cc0-65c8-4277-9d3a-5585fb57dc3b	4	Land title or Lease Agreement	Landlord	Valid	2026-01-24 06:24:23.680554
2b556948-b29f-49ff-92d7-31b27dfe1541	9f564cc0-65c8-4277-9d3a-5585fb57dc3b	5	Certificate of Incorporation	IPA	Local and Foreign Enterprises	2026-01-24 06:24:23.682076
02f3ed36-bbb4-46e9-a1fc-5e17145dbf8d	9f564cc0-65c8-4277-9d3a-5585fb57dc3b	6	Foreign Enterprise Certificate	IPA	Applicable if Foreign Enterprise	2026-01-24 06:24:23.683478
a0dfe675-fc6e-4c1b-b87c-7e79c0a28e31	9f564cc0-65c8-4277-9d3a-5585fb57dc3b	7	Company Extract	IPA	Local and Foreign Enterprise	2026-01-24 06:24:23.685128
cd77b5af-fb39-4d51-8745-fe505e9a965d	9f564cc0-65c8-4277-9d3a-5585fb57dc3b	8	Business Name Registration Certificate	IPA	Valid	2026-01-24 06:24:23.68641
9d5fbdd2-012e-4342-8625-64adeb32e8e3	9f564cc0-65c8-4277-9d3a-5585fb57dc3b	9	Food Safety Management System (HACCP)	Applicant	Applicable if Food is served (Hazard Analysis Critical Control Point	2026-01-24 06:24:23.688026
5460a755-285c-4f0c-a15d-9c08951ce61f	9f564cc0-65c8-4277-9d3a-5585fb57dc3b	10	Copy of License of Previous Operator	Applicant	Applicable if Change of Management occur	2026-01-24 06:24:23.689591
429a7cbf-c9ce-4318-be6c-f8ebae38932e	9f564cc0-65c8-4277-9d3a-5585fb57dc3b	11	Number of Bars	Applicant	Name(s) of Bars to be identified by way of letter	2026-01-24 06:24:23.691202
2b7c98ad-29e3-465a-9c70-91095940e5f7	9f564cc0-65c8-4277-9d3a-5585fb57dc3b	12	Name of Approved Manager of the premise	Applicant	To be identified by way of letter	2026-01-24 06:24:23.692691
49a3300b-868a-4435-9af0-c227c1b3d145	9f564cc0-65c8-4277-9d3a-5585fb57dc3b	13	Statutory Declaration	Justice of Peace	Declaring all information, Materials are true and correct in nature	2026-01-24 06:24:23.693924
21ed7f86-7021-4c1c-b50e-c026cf1185d4	9f564cc0-65c8-4277-9d3a-5585fb57dc3b	14	Land Tax & Garbage Bills	NCDC	Evidence of Payments	2026-01-24 06:24:23.695284
c6f7ca14-52a7-4cd6-ac55-c5e797e9fa3c	759ee9bf-5fcc-4300-a1f9-bea1158a08a2	1	Application FORM 1	NCDC	Completed, dated and signed	2026-01-24 06:24:23.696642
a734e934-bbfa-49c9-b0a3-21b58da5ad0d	759ee9bf-5fcc-4300-a1f9-bea1158a08a2	2	Physical planning Approvals	NCDC	Applicable if Land Use Changes	2026-01-24 06:24:23.698245
27ce051e-0e14-4140-ac1a-e2682ae6dd46	759ee9bf-5fcc-4300-a1f9-bea1158a08a2	3	Building Authority Approvals	NCDC	Applicable if structural changes occurs	2026-01-24 06:24:23.69961
0401d4bb-53a6-48a9-b419-4ef2b0084c80	759ee9bf-5fcc-4300-a1f9-bea1158a08a2	4	Land title or Lease Agreement	Landlord	Valid	2026-01-24 06:24:23.700845
9212397a-05c7-45a9-8d10-cdfb386e9c16	759ee9bf-5fcc-4300-a1f9-bea1158a08a2	5	Certificate of Incorporation	IPA	Local and Foreign Enterprises	2026-01-24 06:24:23.702592
f5b31dff-422b-4edc-a046-c5eb91f9a481	759ee9bf-5fcc-4300-a1f9-bea1158a08a2	6	Foreign Enterprise Certificate	IPA	Applicable if Foreign Enterprise	2026-01-24 06:24:23.704356
c23d0ef0-332e-4b30-b193-8853b0651b3d	759ee9bf-5fcc-4300-a1f9-bea1158a08a2	7	Company Extract	IPA	Local and Foreign Enterprise	2026-01-24 06:24:23.705867
c637eb53-4c3f-4470-ba67-c9d4da0b567c	759ee9bf-5fcc-4300-a1f9-bea1158a08a2	8	Business Name Registration Certificate	IPA	Valid	2026-01-24 06:24:23.707495
13ff3ce8-46ac-4905-95b2-229af4ffe603	759ee9bf-5fcc-4300-a1f9-bea1158a08a2	9	Food Safety Management System	Applicant	Applicable if Food is served. Hazard Analysis Critical Control Point (HACCP)	2026-01-24 06:24:23.708891
6202b9ea-3a80-4878-9f5d-d04d8244e7a8	759ee9bf-5fcc-4300-a1f9-bea1158a08a2	10	Copy of License of Previous Operator	Applicant	Applicable if Change of Management occurs	2026-01-24 06:24:23.710328
c29a4bf3-f875-43fa-872e-565f45fb5c4b	759ee9bf-5fcc-4300-a1f9-bea1158a08a2	11	Number of Bars	Applicant	Name(s) of Bars to be identified by way of letter	2026-01-24 06:24:23.711612
71f48751-67e8-4cd1-9228-9ad2189c508a	759ee9bf-5fcc-4300-a1f9-bea1158a08a2	12	Name of Approved Manager of the premise	Applicant	To be identified by way of letter	2026-01-24 06:24:23.712751
7bf6511d-428e-44b7-a2cf-c9c22569aca3	759ee9bf-5fcc-4300-a1f9-bea1158a08a2	13	Statutory Declaration	Justice of Peace	Declaring all information, Materials are true and correct in nature	2026-01-24 06:24:23.713928
641dd07b-0a3f-43a2-919e-ab5b6dfcf2c4	759ee9bf-5fcc-4300-a1f9-bea1158a08a2	14	Land Tax & Garbage Bills	NCDC	Evidence	2026-01-24 06:24:23.71509
e93909e9-cd2f-45bd-bdaf-81dc8c10f268	582f971b-f5c1-481d-be88-13c68df2628d	1	Application Form No.5	NCDC	Completed, signed and dated	2026-01-24 06:24:23.71618
d493f3db-0075-4790-8fd6-1c4aae85392e	582f971b-f5c1-481d-be88-13c68df2628d	2	Certificate Business Name Registration	IPA	Valid	2026-01-24 06:24:23.717294
0c6429d1-d6c9-4c0b-afaf-4ff1b7be9353	582f971b-f5c1-481d-be88-13c68df2628d	3	Certified Sea Going Vessel	National Maritime Safety Authority	Safety	2026-01-24 06:24:23.718896
20c03a34-b8d4-482a-bf3a-8c3c09441f80	582f971b-f5c1-481d-be88-13c68df2628d	4	Certified Overseas Ship	National Maritime Safety Authority	Safety	2026-01-24 06:24:23.720244
d59d3f52-3e47-4362-9836-0fcfea095033	582f971b-f5c1-481d-be88-13c68df2628d	5	Name of Master /Captain of Vessel/ship	Applicant	To be confirmed by way of Letter	2026-01-24 06:24:23.721668
a28ac2fb-3ca3-490d-8982-0bef29030342	582f971b-f5c1-481d-be88-13c68df2628d	6	Statutory Declaration Form	Justice of Peace	All information, material particular are true and correct	2026-01-24 06:24:23.723257
1163d086-3955-4f8a-8bbf-01f94c7289ca	feb731e5-e68a-4b8d-8551-cb75cab71492	1	Application FORM 7	NCDC	Completed, dated and signed	2026-01-24 06:24:23.72467
f991de90-053c-4bc5-a745-6db2b61a9d75	feb731e5-e68a-4b8d-8551-cb75cab71492	2	Physical planning Approvals	NCDC	Applicable if Land Use Changes	2026-01-24 06:24:23.725992
628bd3a4-d0c5-4472-832a-7e2a606433a3	feb731e5-e68a-4b8d-8551-cb75cab71492	3	Building Authority Approvals	NCDC	Applicable if structural changes occur	2026-01-24 06:24:23.72733
5681fac2-81dd-4c33-950c-b89725bc9c00	feb731e5-e68a-4b8d-8551-cb75cab71492	4	Land title or Lease Agreement	LandLord	Valid	2026-01-24 06:24:23.728624
c0f0ab36-2099-4260-b43e-66b93d8dd896	feb731e5-e68a-4b8d-8551-cb75cab71492	5	Certificate of Incorporation	IPA	Local and Foreign Enterprises	2026-01-24 06:24:23.72979
e23ef05a-63d0-4915-a0fe-7b3a01627f0f	feb731e5-e68a-4b8d-8551-cb75cab71492	6	Certificate Permitting Foreigners to Operate Business in PNG	IPA	Applicable if Foreign Enterprise	2026-01-24 06:24:23.731179
6ee67c93-a6d4-4be0-a828-7b9a3b803896	feb731e5-e68a-4b8d-8551-cb75cab71492	7	Company Extract	IPA	Local and Foreign Enterprises	2026-01-24 06:24:23.732463
7a974796-ed76-49f9-b2c5-065ac442c677	feb731e5-e68a-4b8d-8551-cb75cab71492	8	Business Name Registration Certificate	IPA	Valid	2026-01-24 06:24:23.733585
939c35e2-74da-48b8-a300-ce4459d3b69e	feb731e5-e68a-4b8d-8551-cb75cab71492	9	Food Safety Management System (HACCP)	Applicant	Hazard Analysis Critical Control Point (HACCP)	2026-01-24 06:24:23.734888
47e303c2-3a16-42fd-a20a-13af81d832ec	feb731e5-e68a-4b8d-8551-cb75cab71492	10	Copy of license for previous operator	Applicant	Applicable if Change of Management	2026-01-24 06:24:23.736528
7c8c0c07-62dd-4fab-8fcd-461e8e9939e7	feb731e5-e68a-4b8d-8551-cb75cab71492	11	Number of Bars	Applicant	Name of bar (s) to be identified by way of letter	2026-01-24 06:24:23.738017
6a06d301-2c90-4679-961d-7248652229ff	feb731e5-e68a-4b8d-8551-cb75cab71492	12	Name of Approved Manager of the premise	Applicant	Name of Manager (s) to be identified by way of letter	2026-01-24 06:24:23.739445
0cd0e1a7-355f-4fe1-a8ea-4b847da95aee	feb731e5-e68a-4b8d-8551-cb75cab71492	13	Statutory Declaration	Justice of Peace	Declaring all information, Materials are true and correct in nature	2026-01-24 06:24:23.740729
6bb79fc7-63d7-47de-90f1-b4d3a638fc82	feb731e5-e68a-4b8d-8551-cb75cab71492	14	Land Tax & Garbage Bills	NCDC	Evidence of payment	2026-01-24 06:24:23.742042
da33b662-99b6-48c5-acc2-efc99fe00910	0442a370-8413-4a3e-8c20-81d372fb1899	1	Application Form No 12	NCDC	Completed, dated & signed	2026-01-24 06:24:23.743583
4f0a6526-2ef5-4000-903f-3866156f1771	0442a370-8413-4a3e-8c20-81d372fb1899	2	Physical planning Approvals	NCDC	Applicable if Land Use Changes	2026-01-24 06:24:23.744891
1ef784bb-99ac-4737-a218-65232de2cc94	0442a370-8413-4a3e-8c20-81d372fb1899	3	Building Authority Approvals	NCDC	Applicable if structural changes occur	2026-01-24 06:24:23.746142
ef1e8048-c8ec-47ae-bd72-6eb163d95467	0442a370-8413-4a3e-8c20-81d372fb1899	4	Land title or Lease Agreement	LandLord	Valid	2026-01-24 06:24:23.747379
74b0e090-f884-431a-ba12-0b5722a40b78	0442a370-8413-4a3e-8c20-81d372fb1899	5	Certificate of Incorporation	IPA	Local and Foreign	2026-01-24 06:24:23.748989
e97207fb-18fe-4d05-81b2-65e37578051d	0442a370-8413-4a3e-8c20-81d372fb1899	6	Certificate Permitting Foreigners to Operate Business in PNG	IPA	Applicable if Foreign Enterprise	2026-01-24 06:24:23.750415
81efa2a5-0048-4e19-90d7-d49df1d3caf2	0442a370-8413-4a3e-8c20-81d372fb1899	7	Company Extract	IPA	Local and Foreign Enterprises	2026-01-24 06:24:23.752111
1fb7cac7-8089-4de2-95e2-dd23ce180fcb	0442a370-8413-4a3e-8c20-81d372fb1899	8	Business Name Registration Certificate	IPA	Valid	2026-01-24 06:24:23.754458
d132ec05-6857-4734-9eb6-51c8a1ac8c69	0442a370-8413-4a3e-8c20-81d372fb1899	9	Name of Approved Manager of the Premise	Applicant	To be identified by way of letter	2026-01-24 06:24:23.756229
25187753-0c2b-4da8-a2c0-ee4b58f4f335	0442a370-8413-4a3e-8c20-81d372fb1899	10	Statutory Declaration	Justice of Peace	All information, Materials are true and correct in nature	2026-01-24 06:24:23.758106
10ed9643-18e5-4886-97bf-0b07aeda67ff	0442a370-8413-4a3e-8c20-81d372fb1899	11	Copy of License of Previous Operator	Applicant	Applicable if Change of Management	2026-01-24 06:24:23.759878
1693ff7f-22f4-454b-8cd2-5ba2cac606b6	0442a370-8413-4a3e-8c20-81d372fb1899	12	Land Tax and Garbage Bills	NCDC	Evidence	2026-01-24 06:24:23.76177
dde8c5eb-6e02-40ce-9afd-46160f23c995	38eec32b-ea1f-4a60-8244-a635552b9685	1	Application FORM No.12	NCDC	Completed, signed and dated	2026-01-24 06:24:23.763701
37177d01-cd49-4c91-85de-16a26710263e	38eec32b-ea1f-4a60-8244-a635552b9685	2	Physical planning Approvals	NCDC	Applicable if change in Land Use occur	2026-01-24 06:24:23.765435
52bd84fc-c9e8-4d57-aed5-ee12cacd2d0d	38eec32b-ea1f-4a60-8244-a635552b9685	3	Building Authority Approvals	NCDC	Applicable if structural changes occur	2026-01-24 06:24:23.767116
8909c84d-5476-47a1-9916-db9c8cbb8540	38eec32b-ea1f-4a60-8244-a635552b9685	4	Land Title or Lease Agreement	LandLord	Valid	2026-01-24 06:24:23.768526
976b2ce3-d5b3-4e35-9d94-9dda4f26cd87	38eec32b-ea1f-4a60-8244-a635552b9685	5	Certificate of Incorporation	IPA	Valid	2026-01-24 06:24:23.770446
935aafbc-1fbe-4d64-a8a6-26c16f670abd	38eec32b-ea1f-4a60-8244-a635552b9685	6	Business Name Registration Certificate	IPA	Local and Foreign Enterprise	2026-01-24 06:24:23.772332
2dfb2e71-ecab-44d6-a3c9-1fe3f60ce2dc	38eec32b-ea1f-4a60-8244-a635552b9685	7	Certificate Permitting Foreigners to Operate Business in PNG	IPA	Applicable if Foreign Enterprises	2026-01-24 06:24:23.774012
d29a968e-cb48-4c7b-ad45-693de0cbcea6	38eec32b-ea1f-4a60-8244-a635552b9685	8	Company Extract	IPA	Local and Foreign Enterprise	2026-01-24 06:24:23.77551
3c7a1637-2a6a-4e6b-93f3-ef637c11b1e6	38eec32b-ea1f-4a60-8244-a635552b9685	9	Copy of License for the Previous Operator	Applicant	Applicable if change of Management occurs	2026-01-24 06:24:23.776827
cb2dafc9-dc3e-4323-8f56-43e44602e11f	38eec32b-ea1f-4a60-8244-a635552b9685	10	Canteen's Rules	Applicant	Updated Operational Orders/Rules	2026-01-24 06:24:23.778044
e60c3176-7f8b-474d-bd65-917cf484a834	38eec32b-ea1f-4a60-8244-a635552b9685	11	List of number of Employees	Applicant	Updated List with Minimum of 25 heads	2026-01-24 06:24:23.779402
74aafc53-4c81-4911-82bc-970ef982f5df	38eec32b-ea1f-4a60-8244-a635552b9685	12	Food Safety Management System (HACCP)	Applicant	Applicable If food is involved. Hazard Analysis Critical Control Point	2026-01-24 06:24:23.780719
5551eb8b-77b5-4e2b-b93f-3daa5d81e3cc	38eec32b-ea1f-4a60-8244-a635552b9685	13	Name of Approved Licensee	Applicant	To be identified by way of letter	2026-01-24 06:24:23.782212
037c66e9-f49e-4df3-8b39-e2ddf4936efb	38eec32b-ea1f-4a60-8244-a635552b9685	14	Statutory Declaration Form	Justice of Peace	All information, Materials are true and correct in nature	2026-01-24 06:24:23.783718
e2ed6829-baa4-4018-a01b-ff42dcc067da	38eec32b-ea1f-4a60-8244-a635552b9685	15	Land Tax & Garbage Bills	NCDC	Evidence	2026-01-24 06:24:23.785279
ebed839a-cd44-4273-90f1-0045c943c95a	07a39f8e-2ef3-40de-bce2-572bd1e08d45	1	Application Form 6	NCDC	Completed, signed and dated	2026-01-24 06:24:23.787268
1713f9ba-588e-43bc-b241-b6554f58cc2a	07a39f8e-2ef3-40de-bce2-572bd1e08d45	2	Physical planning Approvals	NCDC	Applicable if Land Use Changes	2026-01-24 06:24:23.789295
f93f0682-d251-4c94-a4a6-45a02e4da7cb	07a39f8e-2ef3-40de-bce2-572bd1e08d45	3	Building Authority Approvals	NCDC	Applicable if structural changes occur	2026-01-24 06:24:23.790907
ace4566c-d532-4244-bad8-5ac7d993e58c	07a39f8e-2ef3-40de-bce2-572bd1e08d45	4	Land title or Lease Agreement	LandLord	Valid	2026-01-24 06:24:23.792432
7ff2b651-614c-43b0-b63b-5e9fab59a4be	07a39f8e-2ef3-40de-bce2-572bd1e08d45	5	Certificate of Incorporation	IPA	Local and Foreign Enterprise	2026-01-24 06:24:23.793884
3b8f7fdd-1aea-4963-a570-82b012ab821a	07a39f8e-2ef3-40de-bce2-572bd1e08d45	6	Foreign Enterprise Certificate	IPA	Applicable if Foreign Enterprise	2026-01-24 06:24:23.795214
ef79ab3d-e9f4-430e-811d-0cb7c36403f1	07a39f8e-2ef3-40de-bce2-572bd1e08d45	7	Business Name Registration Certificate	IPA	Valid	2026-01-24 06:24:23.7966
64458c90-4774-473b-9fec-4fa2d8525a1b	07a39f8e-2ef3-40de-bce2-572bd1e08d45	8	Food Safety Management System	Applicant	Applicable if food is involved	2026-01-24 06:24:23.797966
577fbae7-8f3c-4fa5-b846-9b5fe7d4802a	07a39f8e-2ef3-40de-bce2-572bd1e08d45	9	Number of Bars	Applicant	Name(s) of Bars to be identified by way of letter	2026-01-24 06:24:23.799612
49d1e2b0-7625-4cce-945e-5dfea52e565c	07a39f8e-2ef3-40de-bce2-572bd1e08d45	10	Name of Approved Manager of the premise	Applicant	Valid	2026-01-24 06:24:23.801181
dfd7b237-d345-4a6b-9dc1-9f8d63295d88	07a39f8e-2ef3-40de-bce2-572bd1e08d45	11	Club Constitution/Rules	Applicant	Valid	2026-01-24 06:24:23.802772
148c10db-7730-4960-aa82-0d453115b32c	07a39f8e-2ef3-40de-bce2-572bd1e08d45	12	List of Subscribing Members	Applicant	In excess of 50 members	2026-01-24 06:24:23.804388
a0727cdc-f346-4211-9fbf-94d77b26925f	07a39f8e-2ef3-40de-bce2-572bd1e08d45	13	Copy of the Annual General Meeting Minutes (AGM)	Applicant	Valid	2026-01-24 06:24:23.805941
15451b9f-716e-4a01-8cf4-74606a76d76b	07a39f8e-2ef3-40de-bce2-572bd1e08d45	14	Copy of license of Previous Operator	Applicant	Applicable if Change of Management (COM)	2026-01-24 06:24:23.807391
7a86e6d4-4023-4651-a3e5-1e8a64d08e06	07a39f8e-2ef3-40de-bce2-572bd1e08d45	15	Statutory Declaration	Justice of Peace	All information, Materials are true and correct in nature	2026-01-24 06:24:23.808895
deba69f0-e386-43b0-92ea-d47f710ae9ad	07a39f8e-2ef3-40de-bce2-572bd1e08d45	16	Land Tax & Garbage Bills	NCDC	Evidence of payment	2026-01-24 06:24:23.810201
27dddbd0-4f9a-432a-87c9-24bdd997ec72	926eb276-15e4-4dbd-b397-0520ba13f387	1	Application FORM.1	NCDC	Completed, signed and dated	2026-01-24 06:24:23.811556
299b5b54-78f7-466d-890c-c93577ebe2dd	926eb276-15e4-4dbd-b397-0520ba13f387	2	Physical Planning Approvals	NCDC	Applicable if land use changes	2026-01-24 06:24:23.812836
1554d365-b188-4ac7-9d8c-38da2ea8e7bd	926eb276-15e4-4dbd-b397-0520ba13f387	3	Building Authority Approvals	NCDC	Applicable if structural changes occur	2026-01-24 06:24:23.814208
e113b316-9b06-46f0-a8d4-cb5b6cf3c9a7	926eb276-15e4-4dbd-b397-0520ba13f387	4	Land Title/Lease Agreement	Landlord	Valid	2026-01-24 06:24:23.815425
1bdcd25c-acab-429d-b4e6-16067efbdb0b	926eb276-15e4-4dbd-b397-0520ba13f387	5	Motor Car Dealers License	Land Transport Board	Valid	2026-01-24 06:24:23.816729
4a478728-c6f0-452d-992b-6abc84063c31	926eb276-15e4-4dbd-b397-0520ba13f387	6	Certificate of Incorporation	IPA	Local and Foreign Company	2026-01-24 06:24:23.818146
b24ca8c6-d729-4c15-a533-7be9ebe0e41a	926eb276-15e4-4dbd-b397-0520ba13f387	7	Company Extract	IPA	Local and Foreign Company	2026-01-24 06:24:23.819548
efc96114-e7c8-44f6-a657-e2a726b78185	926eb276-15e4-4dbd-b397-0520ba13f387	8	Certificate of Registration of Business Name	IPA	Valid	2026-01-24 06:24:23.820893
31f3dc8f-84c1-4e45-981a-bd6eccdd6b17	926eb276-15e4-4dbd-b397-0520ba13f387	9	Certificate Permitting Foreigners to Operate Business in PNG	IPA	Applicable for foreign Enterprise	2026-01-24 06:24:23.822451
d34d9661-fc39-46ec-8410-72c85f756a5f	926eb276-15e4-4dbd-b397-0520ba13f387	10	Land Tax & Garbage Rate	NCDC	Evidence of payment	2026-01-24 06:24:23.823851
f7e6eb65-8716-47a3-a0cb-433dbe11ae4a	926eb276-15e4-4dbd-b397-0520ba13f387	11	Copy of License for previous operator	Applicant	Application if COM/New Ownership	2026-01-24 06:24:23.825258
54fe016b-a8bd-4b1f-8e05-413bc8b095bf	ebcef708-32b1-4bc8-a090-c3dff544cfcd	1	Application FORM.1 Reg:3(2)	NCDC	Completed, signed and dated	2026-01-24 06:24:23.826556
c804570b-4552-4250-a281-ebb7e9212cad	ebcef708-32b1-4bc8-a090-c3dff544cfcd	2	Physical Planning Approvals	NCDC	Applicable if land use changes	2026-01-24 06:24:23.828059
a601d17c-0a98-4c1f-a008-f7aa4219c53f	ebcef708-32b1-4bc8-a090-c3dff544cfcd	3	Building Authority Approvals	NCDC	Applicable if structural changes occur	2026-01-24 06:24:23.829331
9a9f2088-a07e-4a2d-9b8c-bc902df7a11e	ebcef708-32b1-4bc8-a090-c3dff544cfcd	4	Land Title/Lease Agreement	Landlord	Valid	2026-01-24 06:24:23.830654
746e3717-3b9a-489f-a679-09831fcfdda7	ebcef708-32b1-4bc8-a090-c3dff544cfcd	5	Certificate of Incorporation	IPA	Local and Foreign Companies	2026-01-24 06:24:23.831988
1aa65dd6-2d38-44c3-9cbe-b6e4d47ff2cc	ebcef708-32b1-4bc8-a090-c3dff544cfcd	6	Company Extract	IPA	Local and Foreign Companies	2026-01-24 06:24:23.833277
e58cb5c2-d338-4dbf-9d02-7d6671b28237	ebcef708-32b1-4bc8-a090-c3dff544cfcd	7	Certificate of Registration of Business Name	IPA	Valid	2026-01-24 06:24:23.834607
3469752f-2445-4ef1-888a-ddb034daf815	ebcef708-32b1-4bc8-a090-c3dff544cfcd	8	Certificate Permitting Foreigners to Operate Business in PNG	IPA	Applicable for foreign Enterprise	2026-01-24 06:24:23.836606
2c3019b4-d238-4370-9433-ffc41b915946	ebcef708-32b1-4bc8-a090-c3dff544cfcd	9	Land Tax & Garbage Rate	NCDC	Evidence of payment	2026-01-24 06:24:23.838318
9e9d5d1a-dd54-49f9-8bbe-54786f05ace4	ebcef708-32b1-4bc8-a090-c3dff544cfcd	10	Copy of license for previous Operator	Applicant	Application if COM/New Ownership	2026-01-24 06:24:23.83971
c28eb4c6-34aa-4087-b397-5093a3bab83d	1a6d6c6a-382e-48e5-aac0-c63a4152ddd0	1	Application FORM 1	NCDC	Completed, dated and signed	2026-01-24 06:24:23.841118
1541c54d-9311-424e-8ff0-73252ad63208	1a6d6c6a-382e-48e5-aac0-c63a4152ddd0	2	Physical planning Approvals	NCDC	Applicable if Land Use Changes	2026-01-24 06:24:23.842448
a0867a2b-b1ab-4ee5-9cca-26d59032ed47	1a6d6c6a-382e-48e5-aac0-c63a4152ddd0	3	Building Authority Approvals	NCDC	Applicable if structural changes occurs	2026-01-24 06:24:23.843838
f69047de-1ab1-4b08-928c-af3cdd1c7314	1a6d6c6a-382e-48e5-aac0-c63a4152ddd0	4	Land title or Lease Agreement	Landlord	Valid	2026-01-24 06:24:23.84506
dea75685-7984-4db4-a4cf-a25790f6e6ed	1a6d6c6a-382e-48e5-aac0-c63a4152ddd0	5	Certificate of Incorporation	IPA	Local and Foreign Enterprises	2026-01-24 06:24:23.846485
edca1afa-88b8-4a24-92d3-38f1dac8a097	1a6d6c6a-382e-48e5-aac0-c63a4152ddd0	6	Foreign Enterprise Certificate	IPA	Applicable if Foreign Enterprise	2026-01-24 06:24:23.847818
3b7c3580-072c-49f5-a9ac-2464a0963d5d	1a6d6c6a-382e-48e5-aac0-c63a4152ddd0	7	Company Extract	IPA	Local and Foreign Enterprise	2026-01-24 06:24:23.849098
0e90a3bd-87eb-4ca1-9724-4f4653b1fec0	1a6d6c6a-382e-48e5-aac0-c63a4152ddd0	8	Business Name Registration Certificate	IPA	Valid	2026-01-24 06:24:23.85045
87f1e01d-7a85-4cdb-a38b-0bf7f55df210	1a6d6c6a-382e-48e5-aac0-c63a4152ddd0	9	Food Safety Management System	Applicant	Applicable if Food is served. Hazard Analysis Critical Control Point (HACCP)	2026-01-24 06:24:23.851824
8c8e52ab-27d1-449b-87d6-fb6aa66b9dcc	1a6d6c6a-382e-48e5-aac0-c63a4152ddd0	10	Copy of License of Previous Operator	Applicant	Applicable if Change of Management occurs	2026-01-24 06:24:23.853117
d450a5dd-6f30-42a3-b5dd-bcefc6407dbf	1a6d6c6a-382e-48e5-aac0-c63a4152ddd0	11	Number of Bars	Applicant	Name(s) of Bars to be identified by way of letter	2026-01-24 06:24:23.854507
f590dce2-0b7d-41d0-ba2b-950d0e1d4379	1a6d6c6a-382e-48e5-aac0-c63a4152ddd0	12	Name of Approved Manager of the premise	Applicant	To be identified by way of letter	2026-01-24 06:24:23.855766
0fa2ee54-cbf5-45cf-a574-5c9151e95845	1a6d6c6a-382e-48e5-aac0-c63a4152ddd0	13	Statutory Declaration	Justice of Peace	Declaring all information, Materials are true and correct in nature	2026-01-24 06:24:23.856998
a3aabf87-be57-4887-8fc0-9799bfc8693f	1a6d6c6a-382e-48e5-aac0-c63a4152ddd0	14	Land Tax & Garbage Bills	NCDC	Evidence	2026-01-24 06:24:23.858569
51a7170e-3102-444c-8943-4df7568d1ecf	76f2acf3-25b0-4de6-a246-72e11f40b139	1	Completed application Form No. 3	NCDC	Completed, dated & signed	2026-01-24 06:24:23.860031
23a97075-6495-494e-a2ed-da4c4f5c1715	76f2acf3-25b0-4de6-a246-72e11f40b139	2	Physical planning Approvals	NCDC	Applicable if Land Use Changes occur	2026-01-24 06:24:23.86114
82526bc3-6780-4cd7-9a06-9c8445339f2a	76f2acf3-25b0-4de6-a246-72e11f40b139	3	Building Authority Approvals	NCDC	Applicable if structural changes occur	2026-01-24 06:24:23.86235
a06d46ff-f096-4254-9546-5a782090a01f	76f2acf3-25b0-4de6-a246-72e11f40b139	4	Land title or Lease Agreement	IPA	Valid	2026-01-24 06:24:23.863723
8869d896-114d-4a86-8131-07e79fb865a3	76f2acf3-25b0-4de6-a246-72e11f40b139	5	Certificate of Incorporation	IPA	Local and Foreign Enterprises	2026-01-24 06:24:23.86507
04dface6-2418-4275-bf4b-02c4cb99c6c0	76f2acf3-25b0-4de6-a246-72e11f40b139	6	Certificate Permitting Foreigners to Operate Business in PNG	IPA	Applicable if Foreign Enterprise	2026-01-24 06:24:23.866336
50079adf-6b7b-422c-9679-5490daba825b	76f2acf3-25b0-4de6-a246-72e11f40b139	7	Business Name Registration Certificate	IPA	Valid	2026-01-24 06:24:23.867703
e3baeb0c-d81f-4051-abfd-f8b9afcca2ad	76f2acf3-25b0-4de6-a246-72e11f40b139	8	Company Extract	IPA	Local and Foreign Enterprise	2026-01-24 06:24:23.869129
04af28b9-473b-43a8-ae34-538662984df3	76f2acf3-25b0-4de6-a246-72e11f40b139	9	Name of Approved Manager of the Premise	Applicant	To be identified by way of writing to NCDC	2026-01-24 06:24:23.870774
9290c721-d25a-4592-a2e7-54b5817d7065	76f2acf3-25b0-4de6-a246-72e11f40b139	10	Statutory Declaration	Justice of Peace	Declaring all information, Materials are true and correct in nature	2026-01-24 06:24:23.872178
1fd90059-51d8-4c83-aad8-b187efe263b1	76f2acf3-25b0-4de6-a246-72e11f40b139	11	Copy of License for previous year	Applicant	Applicable if Change of Management	2026-01-24 06:24:23.873525
11d3012d-512f-436c-b19b-4edfed4dba0e	76f2acf3-25b0-4de6-a246-72e11f40b139	12	Land & Garbage Taxes	NCDC	Evidence	2026-01-24 06:24:23.874832
657efff0-eb43-420a-8e52-5adfa6aa9a9c	899bd00f-96d3-43b9-8025-a65815f191fc	1	Complete Application Form No.4	NCDC	Completed, signed and dated	2026-01-24 06:24:23.87604
982602f0-f9c1-4a39-a31a-92298e82e7a8	899bd00f-96d3-43b9-8025-a65815f191fc	2	Floor Plan of the Arena/venue	Applicant	Service Area for liquor	2026-01-24 06:24:23.877238
aaaa58c2-24e7-4135-9ac6-7ba77ec1e0de	899bd00f-96d3-43b9-8025-a65815f191fc	3	Nominated Name of Publican, Holders of Tavern license	Applicant	Applicable if occasion will be held in an unlicensed premises (To provide service of alcohol on behalf of the organizers	2026-01-24 06:24:23.87855
e6c9695e-9930-4489-a1a5-f1015ee9852f	899bd00f-96d3-43b9-8025-a65815f191fc	4	Written consent of other Venue's Management	Applicant	To be confirmed by way of Letter	2026-01-24 06:24:23.879905
f17b9bb1-291e-45b4-9b02-f375af01f278	899bd00f-96d3-43b9-8025-a65815f191fc	5	Statutory Declaration Form	Justice of Peace	All information, material particular are true and correct.	2026-01-24 06:24:23.88258
7ce50a5b-7282-4c79-bd5d-41123da601fa	899bd00f-96d3-43b9-8025-a65815f191fc	6	Copy of official Receipt For Payment of License fees	NCDC	For reference	2026-01-24 06:24:23.884102
2c7a8374-6c12-4234-98bb-786a88b4e7ec	899bd00f-96d3-43b9-8025-a65815f191fc	7	Land Tax & Garbage Bills	NCDC	Evidence	2026-01-24 06:24:23.885795
\.


--
-- Data for Name: citizens; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.citizens (citizen_id, council_id, national_id, local_citizen_no, first_name, last_name, dob, sex, phone, email, address, village, district, province, created_at, section, lot, block, suburb, nationality) FROM stdin;
3ddb05da-6712-4db8-b25c-2106711cc6b6	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	NID-2024-00456	NCDC-CIT-0002	Sarah	Toua	1992-07-22	female	+675 7345 6789	stoua@email.pg	Papa	Hanuabada	Kairuku-Hiri	Central	2026-01-14 06:40:16.251672	92	88			\N
4115a728-4f26-431d-ba4c-aa5231350eb1	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	NID-775322278	\N	Francis	Sakala	1992-07-09	\N	+67571562416	francis@gmail.com	Koala	Boroko	Moresby North-East	National Capital District	2026-01-17 17:47:08.41296	77	43	Boroko	Boroko	Australian
47418916-a288-4dd6-a901-71fb5caf6958	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	NID-6638829	\N	Test	NCDC	1977-02-03	\N	+67583674522	test@ncdc.gov.pg	Bata Street	Kokopo	Kokopo	East New Britain	2026-01-18 16:42:05.78753	95	84	Town	Town	PNG
edb0bb1c-b524-4d3d-b9d6-3c59572eb35d	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	NID-2024-00123	NCDC-CIT-0001	Michael	Kila	1985-03-15	male	+675 7234 5678	mkila@email.pg	Kikila	Hanuabada	Moresby North-West	National Capital District	2026-01-14 06:40:16.246408	91	98			PNG
7a093521-cf5e-424f-96c5-71bd02edefb6	90c57094-13e2-42f1-be1f-1a1b50595f70	NID-2024-00123	NCDC-CIT-0001	Michael	Kila	1985-03-15	male	+675 7234 5678	mkila@email.pg	Section 45, Lot 12, Boroko	Hanuabada	Port Moresby	Central Province	2026-01-19 13:30:22.610663	\N	\N	\N	\N	\N
e5731d8f-a7d8-4768-8ee5-b8cd13f70110	90c57094-13e2-42f1-be1f-1a1b50595f70	NID-2024-00456	NCDC-CIT-0002	Sarah	Toua	1992-07-22	female	+675 7345 6789	stoua@email.pg	Section 12, Lot 8, Gordons	\N	Port Moresby	NCD	2026-01-19 13:30:22.616819	\N	\N	\N	\N	\N
f5c265f3-5548-49b4-9109-08bff3528d6f	3c4d4a9f-92a7-4dd2-82fb-ceff90c57094	NID-2024-00123	NCDC-CIT-0001	Michael	Kila	1985-03-15	male	+675 7234 5678	mkila@email.pg	Section 45, Lot 12, Boroko	Hanuabada	Port Moresby	Central Province	2026-01-19 04:04:14.520757	\N	\N	\N	\N	\N
441fdec2-a854-446c-ba81-eac495058d86	3c4d4a9f-92a7-4dd2-82fb-ceff90c57094	NID-2024-00456	NCDC-CIT-0002	Sarah	Toua	1992-07-22	female	+675 7345 6789	stoua@email.pg	Section 12, Lot 8, Gordons	\N	Port Moresby	NCD	2026-01-19 04:04:14.524689	\N	\N	\N	\N	\N
\.


--
-- Data for Name: complaint_updates; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.complaint_updates (update_id, council_id, complaint_id, updated_by, status, comment, created_at) FROM stdin;
\.


--
-- Data for Name: complaints; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.complaints (complaint_id, council_id, complainant_type, complainant_id, category, status, description, latitude, longitude, location, created_at) FROM stdin;
34590860-b73f-4981-b446-5454d734015b	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	citizen	edb0bb1c-b524-4d3d-b9d6-3c59572eb35d	noise	new	Loud music from neighbouring business after 10pm	-9.4620000	147.1650000	Section 45, Boroko	2026-01-14 06:40:16.29403
91fd6644-37b7-47e4-bd3b-8c1199c6c5f2	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	anonymous	\N	illegal_business	investigating	Unlicensed street vendor operating without permit	-9.4780000	147.1550000	Near Gordons Market entrance	2026-01-14 06:40:16.29403
d19805ff-5381-49d5-ab95-e12a2b999a72	90c57094-13e2-42f1-be1f-1a1b50595f70	citizen	7a093521-cf5e-424f-96c5-71bd02edefb6	noise	new	Loud music from neighbouring business after 10pm	-9.4620000	147.1650000	Section 45, Boroko	2026-01-19 13:30:22.678905
6b9453c8-6245-44a3-8f22-01d6a908c096	90c57094-13e2-42f1-be1f-1a1b50595f70	anonymous	\N	illegal_business	investigating	Unlicensed street vendor operating without permit	-9.4780000	147.1550000	Near Gordons Market entrance	2026-01-19 13:30:22.678905
f5990e53-3a7a-49fd-afe4-023cd6db7122	3c4d4a9f-92a7-4dd2-82fb-ceff90c57094	citizen	f5c265f3-5548-49b4-9109-08bff3528d6f	noise	new	Loud music from neighbouring business after 10pm	-9.4620000	147.1650000	Section 45, Boroko	2026-01-19 04:04:14.585412
a05f2ed0-f539-4296-a217-1cba23c0e6d7	3c4d4a9f-92a7-4dd2-82fb-ceff90c57094	anonymous	\N	illegal_business	investigating	Unlicensed street vendor operating without permit	-9.4780000	147.1550000	Near Gordons Market entrance	2026-01-19 04:04:14.585412
\.


--
-- Data for Name: council_units; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.council_units (unit_id, council_id, name, type, parent_unit_id) FROM stdin;
\.


--
-- Data for Name: councils; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.councils (council_id, name, level, country_code, currency_code, timezone, status, logo_url, theme_color, font_family, email, phone, website, address, date_format, time_format, created_at) FROM stdin;
3c4d4a9f-92a7-4dd2-82fb-ceff90c57094	National Capital District Commission	city	PG	PGK	Pacific/Port_Moresby	active	\N	#EAB308	Inter	\N	\N	\N	\N	dd/MM/yyyy	HH:mm	2026-01-20 10:55:51.673331
3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	National Capital District Commission	city	PG	PGK	Pacific/Port_Moresby	active	\N	#EAB308	Inter	\N	\N	\N	\N	dd/MM/yyyy	HH:mm	2026-01-20 10:55:51.704364
\.


--
-- Data for Name: documents; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.documents (document_id, council_id, owner_type, owner_id, type, file_name, file_path, mime_type, file_size, verified, verified_at, verified_by, created_at, rejection_reason, status) FROM stdin;
2fbd5bb0-6b91-4716-836f-c181c553ff12	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	service_request	48967986-6b8b-430f-960f-056a7620b906	other	trade-license-application-form.pdf	uploads\\e1d6d6319ef0ae32cf0edb8f844353b4	application/pdf	129386	f	\N	\N	2026-01-17 23:56:20.351916	\N	pending
70347182-5e67-49f5-96ea-19e2fddeddec	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	service_request	48967986-6b8b-430f-960f-056a7620b906	other	place_of_entertainment_page_1.jpg	uploads\\3eb83513cd610b7d3eec274841cbd6a0	image/jpeg	301838	f	\N	\N	2026-01-17 23:58:36.853212	\N	pending
f2117e01-dd9a-4813-ad49-7d3efed3d138	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	service_request	cd0419e9-5560-4105-ac03-f933a22063b9	other	publicantavern-limited-hotel.pdf	uploads\\1b7e0b762291a97fd2707315c8122c2a	application/pdf	301149	f	\N	\N	2026-01-18 07:20:55.41791	\N	pending
b924ea49-19b7-4374-ae66-442101b7e903	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	service_request	cd0419e9-5560-4105-ac03-f933a22063b9	other	second-hand-dealer (1).pdf	uploads\\ab7beb8721e04de744d0fda77f19e596	application/pdf	135286	f	\N	\N	2026-01-18 07:20:55.541354	\N	pending
4b8faa23-8d95-4eb1-9d7e-87ac7487b12e	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	service_request	cd0419e9-5560-4105-ac03-f933a22063b9	other	barbers-shop-licence.pdf	uploads\\4a03cd47607f76c1ec5211427ac14626	application/pdf	139508	f	\N	\N	2026-01-18 07:20:55.557402	\N	pending
74c0b219-3fba-4294-83ae-269e0850c660	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	service_request	cd0419e9-5560-4105-ac03-f933a22063b9	other	Application Checklist (Trade) - New-General Business.pdf	uploads\\2df7787f04f46d6e999ca1aad1648ead	application/pdf	90220	f	\N	\N	2026-01-18 07:20:55.573413	\N	pending
05283ef9-e971-4c84-a013-e9534f8f1f6a	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	service_request	cd0419e9-5560-4105-ac03-f933a22063b9	other	application_checklist_new_-_for_electronics_shop.docx	uploads\\33bc72acf2bfd1a723ea268da81d252e	application/vnd.openxmlformats-officedocument.wordprocessingml.document	19231	f	\N	\N	2026-01-18 07:20:55.585391	\N	pending
97cbe2f0-439e-4eb3-ac88-0c0878f98c93	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	service_request	cd0419e9-5560-4105-ac03-f933a22063b9	other	Booth_Checklist_New_page_1.png	uploads\\7fb6491c94d9d459cfd15a1e0f740e45	image/png	284344	f	\N	\N	2026-01-18 07:20:55.586208	\N	pending
18e8e0c9-3d80-4423-952c-b4de45b906e5	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	service_request	cd0419e9-5560-4105-ac03-f933a22063b9	other	restaurant.pdf	uploads\\ccd7c7efc7a6ca6f53e05b2d2390baa9	application/pdf	107023	f	\N	\N	2026-01-18 07:20:55.606324	\N	pending
c6713b41-13a1-4521-8f0b-520b00add0ce	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	service_request	cd0419e9-5560-4105-ac03-f933a22063b9	other	Publican_Checklist_New_page_1.png	uploads\\21e199d7f1a76075dc6201455e616a5d	image/png	348623	f	\N	\N	2026-01-18 07:20:55.620269	\N	pending
9ff108e4-03b5-4f2c-a740-9d15b296d453	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	service_request	cd0419e9-5560-4105-ac03-f933a22063b9	other	Application_Checklist_New__For_Food_Establshments_page_1.png	uploads\\9bdc4ea2c318e880e7cd2319cbbcd03a	image/png	311201	f	\N	\N	2026-01-18 07:20:55.629937	\N	pending
089ceafd-aa88-4c46-ac99-e1d0bb8da498	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	service_request	5b2364db-ca28-4f8b-a64b-a960c7131e8f	other	trade-license-application-form.pdf	uploads\\9e67eb360bbe1369ac20b77fe7d5749c	application/pdf	129386	t	2026-01-17 21:22:59.963	system	2026-01-17 20:03:18.36717	\N	approved
48e07799-64da-4315-a238-883ed26fb8a0	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	service_request	c206729f-0afa-4157-88d6-9c90ff876107	other	liquor-club-license.pdf	uploads\\3578d62461cec104702c77e71128b57b	application/pdf	216364	t	2026-01-18 06:07:39.117	system	2026-01-18 16:06:15.987479	\N	approved
bf4d9d3b-4d14-4f1b-bc4a-095964db691d	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	service_request	c206729f-0afa-4157-88d6-9c90ff876107	other	Application_Checklist_New_For_Barber_Shop_License_page_1.png	uploads\\b0d35c8a2d5dd837b28a1648671d4a47	image/png	284894	t	2026-01-18 06:08:06.681	system	2026-01-18 16:06:16.152919	\N	approved
98af3981-ff03-4dc6-9697-b74f9f8d383b	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	service_request	c206729f-0afa-4157-88d6-9c90ff876107	other	Application_Checklist_New_For_Barber_Shop_License_page_1.png	uploads\\c6f20a0df8de03fc274a579db4ef2142	image/png	284894	t	2026-01-18 06:08:11.901	system	2026-01-18 16:06:16.082435	\N	approved
4dc1e059-e253-48b8-ad31-6f25add9c5a9	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	service_request	c206729f-0afa-4157-88d6-9c90ff876107	other	trade_license_application_form_page_1.png	uploads\\f25395bc5fba39f95fe627351aa4fa82	image/png	320005	t	2026-01-18 06:08:16.73	system	2026-01-18 16:06:16.229674	\N	approved
dda12099-12a2-4aae-b332-919e3e7801dd	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	service_request	c206729f-0afa-4157-88d6-9c90ff876107	other	dinner-special-permit-license1.pdf	uploads\\1ceb8bde1ef414f2a5f557994057eceb	application/pdf	415798	t	2026-01-18 06:08:20.891	system	2026-01-18 16:06:16.236081	\N	approved
98c485a9-825f-4627-8847-92a9e997d17a	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	service_request	c206729f-0afa-4157-88d6-9c90ff876107	other	application_checklist_new_-_for_electronics_shop.docx	uploads\\4f526d09cba583f94dbf74526c13e003	application/vnd.openxmlformats-officedocument.wordprocessingml.document	19231	t	2026-01-18 06:08:29.954	system	2026-01-18 16:06:16.117781	\N	approved
339f6b9e-6155-4ef1-b4ef-71b2543710a8	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	service_request	5b2364db-ca28-4f8b-a64b-a960c7131e8f	other	trade-license-application-form.pdf	uploads\\33da62131495cb69707a665aedeadfd1	application/pdf	129386	t	2026-01-23 13:19:03.936	system	2026-01-17 20:03:18.480124	\N	approved
e7d8a5da-a643-4884-89bd-7575a3c2dce1	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	service_request	5b2364db-ca28-4f8b-a64b-a960c7131e8f	other	publicantavern-limited-hotel.pdf	uploads\\57faa0b8ef5d66546ca9ebf5bc75c926	application/pdf	301149	t	2026-01-23 13:19:11.292	system	2026-01-17 20:03:18.502442	\N	approved
718c9fc0-99ab-4678-b175-23e9dc9ff796	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	service_request	5b2364db-ca28-4f8b-a64b-a960c7131e8f	other	barbers-shop-licence.pdf	uploads\\ee9d65dd665bc9b5930bcf2b8828cd91	application/pdf	139508	t	2026-01-23 13:19:17.844	system	2026-01-17 20:03:18.645565	\N	approved
ec7e4bf1-75fb-43ef-8018-a5327b5074f8	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	service_request	5b2364db-ca28-4f8b-a64b-a960c7131e8f	other	Restaurant_Checklist_NEW_page_1.png	uploads\\3c3bb318a99d087d735aa68c76cd2183	image/png	370524	t	2026-01-23 13:20:20.136	system	2026-01-17 20:03:18.945973	\N	approved
aa067816-140f-4999-9641-ceb3121c3d65	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	service_request	5b2364db-ca28-4f8b-a64b-a960c7131e8f	other	Store_KeepersChecklist_New_page_1.png	uploads\\b521e7d9daa6e53440929c781e6f0e23	image/png	348075	t	2026-01-23 13:23:38.414	system	2026-01-17 20:03:18.945088	\N	approved
ad8a8bf8-4752-42de-bc5c-0254fe3941e0	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	service_request	5b2364db-ca28-4f8b-a64b-a960c7131e8f	other	Canteen_Checklist_New_page_1.png	uploads\\fe6818702b111062bc8f01dd864303ec	image/png	356899	t	2026-01-23 13:23:45.684	system	2026-01-17 20:03:18.937938	\N	approved
839dc4e3-4874-48dd-a2f3-ec56614fcd12	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	service_request	5b2364db-ca28-4f8b-a64b-a960c7131e8f	other	place_of_entertainment_page_1.jpg	uploads\\2c33c91c500814632d8864e16d723b41	image/jpeg	301838	t	2026-01-23 13:23:57.641	system	2026-01-17 20:03:18.762608	\N	approved
e3e670a9-93ac-4fe8-8582-5ca1aa886369	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	service_request	c206729f-0afa-4157-88d6-9c90ff876107	other	Application_Checklist_Trade___New_General_Business_page_1.png	uploads\\6c393a918ff53db565139149d7ebc6a8	image/png	287832	t	2026-01-18 06:07:52.872	system	2026-01-18 16:06:16.368008	\N	approved
0f3c3540-b077-4344-822f-ae2b9495f2aa	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	service_request	c206729f-0afa-4157-88d6-9c90ff876107	other	second-hand-dealer (1).pdf	uploads\\c32c6c1c3e1008d3526385650859b8c7	application/pdf	135286	t	2026-01-18 06:08:00.286	system	2026-01-18 16:06:16.285099	\N	approved
4d8b9e4f-bd74-4191-8abf-f76fdd2b5cd9	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	service_request	163cf2e6-8653-4d88-8daa-67c8c7bf20fd	other	Canteen_Checklist_New_page_1.png	uploads\\0851f4a985d3c2e81f5849cce64016be	image/png	356899	t	2026-01-18 06:51:34.113	system	2026-01-18 16:50:49.470869	\N	approved
ebc0bfbd-e91b-4a9c-819c-d3f2aad87f85	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	service_request	163cf2e6-8653-4d88-8daa-67c8c7bf20fd	other	dinner_special_permit_license1_page_1.png	uploads\\b842e728a79e327de8cea6f8245fef36	image/png	223180	t	2026-01-18 06:51:42.55	system	2026-01-18 16:50:49.643065	\N	approved
5011b5dd-1ad5-4b2f-8ca8-e1924c587791	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	service_request	163cf2e6-8653-4d88-8daa-67c8c7bf20fd	other	Application_Checklist_New__For_Second_Hand_Used_Clothing_page_1.png	uploads\\071d31eea57258c6f32b4982b5b14362	image/png	310736	t	2026-01-18 06:51:47.997	system	2026-01-18 16:50:49.623036	\N	approved
9cecf4cb-535a-4569-abea-319e55e8edd0	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	service_request	163cf2e6-8653-4d88-8daa-67c8c7bf20fd	other	Canteen_Checklist_New_page_1.png	uploads\\f515da7674dac79f408fd54924f451f2	image/png	356899	t	2026-01-18 06:51:54.353	system	2026-01-18 16:50:49.604264	\N	approved
ca668143-1d45-48d4-8cb9-e93e4f81625d	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	service_request	163cf2e6-8653-4d88-8daa-67c8c7bf20fd	other	Store_KeepersChecklist_New_page_1.png	uploads\\550d5e4349f86b2a37203d2fcee6e4e5	image/png	348075	t	2026-01-18 06:52:00.258	system	2026-01-18 16:50:49.584872	\N	approved
d95c0da9-b5bc-49f6-b4c0-1c21a4a3ebe7	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	service_request	163cf2e6-8653-4d88-8daa-67c8c7bf20fd	other	manufacturer_page_1.jpg	uploads\\a86d450a611b5d9f9e0cf31f183fba5a	image/jpeg	327246	t	2026-01-18 06:52:08.345	system	2026-01-18 16:50:49.564417	\N	approved
cab31302-8851-49d3-8897-dd700b669d9c	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	service_request	163cf2e6-8653-4d88-8daa-67c8c7bf20fd	other	Application_Checklist_New__For_Fuel_Station_page_1.png	uploads\\4d869419350ee76ef8c11ac4c7fcba39	image/png	318141	t	2026-01-18 06:52:25.031	system	2026-01-18 16:50:49.520626	\N	approved
9aaff19b-72ac-4c79-9501-46d105847003	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	service_request	163cf2e6-8653-4d88-8daa-67c8c7bf20fd	other	Application_Checklist_Trade___New_General_Business_page_1.png	uploads\\3fee77cf52d5f8edaf31cd2bbeab6911	image/png	287832	t	2026-01-18 06:52:29.773	system	2026-01-18 16:50:49.539827	\N	approved
63bd05c2-9d22-4fe8-b096-02c038fad669	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	service_request	163cf2e6-8653-4d88-8daa-67c8c7bf20fd	other	BOTTLE_SHOP_Checklist_New_page_1.png	uploads\\44c400b6950169490009d1936cad2e50	image/png	323569	t	2026-01-18 06:52:33.727	system	2026-01-18 16:50:49.497279	\N	approved
3878cd8d-a0b8-47d2-899f-306589154236	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	council	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	logo	Logo_transparent.png	uploads\\fdfc5c84d936ccda18434a1a818b9662	image/png	56164	f	\N	\N	2026-01-19 13:40:54.978245	\N	pending
d45e9ef7-d5c9-4469-a7fb-f3feed6954f9	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	council	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	logo	Logo_transparent.png	uploads\\8c63fa483e39e218736eb84530af774d	image/png	56164	f	\N	\N	2026-01-19 13:51:12.027952	\N	pending
35de06fe-e5e3-4d14-84cf-9c1b6a8e8194	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	council	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	logo	Logo_transparent.png	uploads\\a72e424b4aa344e0e303aa6fba557c24	image/png	56164	f	\N	\N	2026-01-19 13:51:28.133758	\N	pending
3f3df484-e2cd-4d14-8ab0-2619472bfe5a	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	council	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	logo	Logo_transparent.png	uploads\\d4074ca455ac3506a2e1d0321d193fc0	image/png	56164	f	\N	\N	2026-01-20 11:21:29.668783	\N	pending
485c4a55-56fe-487e-a904-8e839c5ef38d	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	council	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	logo	Logo_transparent.png	uploads\\68f29f57228313308ebd46f1f629f3f9	image/png	56164	f	\N	\N	2026-01-20 11:29:09.670304	\N	pending
a95c3d13-0049-4a08-97a8-40769ed384cf	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	council	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	logo	Logo_transparent.png	uploads\\ab55c1643648ad5820abe09b964dd4c0	image/png	56164	f	\N	\N	2026-01-20 15:48:24.821506	\N	pending
b3d5f71a-57f0-4061-8079-b60687827eae	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	council	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	logo	NCDC Logo.jpg	uploads\\f982f83dc4fdecafa9560833d95567b3	image/jpeg	13702	f	\N	\N	2026-01-20 16:01:46.578706	\N	pending
59fc4bc8-7a17-4e5d-a278-a63b4da2794c	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	council	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	logo	Logo_transparent.png	uploads\\a6c5784f2776bf6cbbcc0965568ce2cf	image/png	56164	f	\N	\N	2026-01-20 16:21:09.959319	\N	pending
8793596a-ce6c-41c3-b63a-20c79e91edbb	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	council	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	logo	Logo_transparent.png	uploads\\7a09beedf91449c256cb0116481ce379	image/png	56164	f	\N	\N	2026-01-20 16:21:21.387881	\N	pending
ea411129-8bac-49b9-a5ad-77c3be667a3d	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	council	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	logo	Logo_transparent.png	uploads\\cae0686da78fa7b8a62013204af8a2f0	image/png	56164	f	\N	\N	2026-01-21 05:42:29.644881	\N	pending
416f8414-5f5f-4365-bbfb-8d564a390021	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	council	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	logo	Logo_transparent.png	uploads\\d7e247787eabc6a9b5ffcc8a7aeca2f6	image/png	56164	f	\N	\N	2026-01-21 05:43:59.089091	\N	pending
44dd3be0-48f3-4591-bfef-083ac9a3061f	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	council	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	logo	Logo_transparent.png	uploads\\7699fdd931b8c5cba0d0d2f47762e5fe	image/png	56164	f	\N	\N	2026-01-21 05:44:10.3863	\N	pending
feeee3a4-d163-4d74-a5bc-af6640064743	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	service_request	a3308191-165c-4487-8036-25c2316b08d7	other	publicantavern_limited_hotel_page_1.png	uploads\\59b6f76d5bc7424f513f5a64cd7e001c	image/png	277141	f	\N	\N	2026-01-23 04:17:26.37482	\N	pending
59977197-a510-4d1e-b536-6f767d93e0cc	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	service_request	a3308191-165c-4487-8036-25c2316b08d7	other	Application_Checklist_New__For_Pharmacy_page_1.png	uploads\\f41111e6f23dbd01d9917a9cff7789a9	image/png	297223	f	\N	\N	2026-01-23 04:17:26.435417	\N	pending
41faebaa-25e8-4685-9d5f-457c77b7d503	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	service_request	a3308191-165c-4487-8036-25c2316b08d7	other	PACKET_Checklist_New_page_1.png	uploads\\fbbbb5af83a52caa61788a1d1e9ca27a	image/png	250821	f	\N	\N	2026-01-23 04:17:26.471191	\N	pending
ff38ea9b-78c6-47d0-b9bc-348af01ce1b5	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	service_request	a3308191-165c-4487-8036-25c2316b08d7	other	Limited_Hotel_Checklist_New_page_1.png	uploads\\4342c673433dca3bc3d3e0a49ca368a9	image/png	365950	f	\N	\N	2026-01-23 04:17:26.511931	\N	pending
122846cd-29f0-4251-bbef-13808db99ae6	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	service_request	a3308191-165c-4487-8036-25c2316b08d7	other	GRADE 4 CBC SCIENCE LESSON PLAN CALL MR KABASO JOSEPH ON 0974382239.docx	uploads\\bcc2cadba347d38e47116bbd27adde89	application/vnd.openxmlformats-officedocument.wordprocessingml.document	35630	f	\N	\N	2026-01-23 04:17:26.576332	\N	pending
009376e3-a53a-4d0a-b1ef-3d259110819b	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	service_request	a3308191-165c-4487-8036-25c2316b08d7	other	second-hand-dealer.pdf	uploads\\40e629978bee6c7e02894d77037abb65	application/pdf	135286	f	\N	\N	2026-01-23 04:17:26.603657	\N	pending
ac5173b4-8ea9-4432-a26f-fd616a17d94f	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	service_request	a3308191-165c-4487-8036-25c2316b08d7	other	PACKET_Checklist_New_page_1.png	uploads\\5b86107029504f063c0da45faa7c12d5	image/png	250821	f	\N	\N	2026-01-23 04:17:26.630958	\N	pending
30e727bc-6c25-4d56-922e-2f15aea201d0	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	service_request	a3308191-165c-4487-8036-25c2316b08d7	other	publicantavern_limited_hotel_page_1.png	uploads\\7b59fdc1aeb1eac9950c5d3367eb43cd	image/png	277141	f	\N	\N	2026-01-23 04:17:26.646064	\N	pending
4c99fd28-63a0-420d-a8f4-18624369e81d	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	service_request	a3308191-165c-4487-8036-25c2316b08d7	other	barbers_shop_licence_page_1.png	uploads\\65eefbd14a434f60ffd9196d80a9e170	image/png	249447	f	\N	\N	2026-01-23 04:17:26.753672	\N	pending
c192f3e2-cb58-4e30-b948-17770003bce6	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	service_request	5b2364db-ca28-4f8b-a64b-a960c7131e8f	other	Restaurant_Checklist_NEW_page_1.png	uploads\\9fa55d78c299132692b6464fd2a5debd	image/png	370524	t	2026-01-23 13:23:31.203	system	2026-01-17 20:03:18.939814	\N	approved
97638192-b4f2-4d9a-967a-01f71a4ace44	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	service_request	5b2364db-ca28-4f8b-a64b-a960c7131e8f	Inspection Report	BOTTLE_SHOP_Checklist_New_page_1.png	uploads\\c5540ad1c7e6609bff52ec1bd0e577ed	image/png	323569	f	\N	\N	2026-01-24 01:07:39.993108	\N	pending
e6449447-7cf2-464c-8f1b-e2d9311446f7	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	service_request	c206729f-0afa-4157-88d6-9c90ff876107	Application FORM .1	BOTTLE_SHOP_Checklist_New_page_1.png	uploads\\4bc777a4fc2bd3bc874d65b4beea5630	image/png	323569	t	2026-01-23 18:10:23.841	system	2026-01-24 04:08:38.411213	\N	approved
6ac86747-8f1f-404c-a5c2-714046092dff	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	service_request	c206729f-0afa-4157-88d6-9c90ff876107	Physical Planning Approvals	restaurant_page_1.png	uploads\\c2484b98b64dfda467d4a2eb1e7a4d9e	image/png	216666	t	2026-01-23 18:10:33.924	system	2026-01-24 04:08:56.793343	\N	approved
d308f50c-a0dc-46a5-81a0-4064c0387078	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	service_request	11e0f60a-7447-4faf-a00e-94e8b07b8751	other	second_hand_dealer_1_page_1.png	uploads\\8db0279f6c60ca6a91aaeb3fc84d438e	image/png	233041	f	\N	\N	2026-01-24 06:18:54.192146	\N	pending
e30c999f-50d4-47f7-8a91-1fcc80d2bd21	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	service_request	ad037f22-82cd-45e0-9378-4e2d845b37c1	other	liquor_club_license_page_1.png	uploads\\e6f271c37dca8d6580b4acfe75893887	image/png	278207	f	\N	\N	2026-01-24 07:01:28.223039	\N	pending
22360f67-f1b1-4e01-82a3-4b31c65b5c4e	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	service_request	163cf2e6-8653-4d88-8daa-67c8c7bf20fd	Inspection Report	Application_Checklist_New__For_Second_Hand_Used_Clothing_page_1.png	uploads\\96bff61ce4493e8daa46b8e22d353a1a	image/png	310736	t	2026-01-24 05:23:42.375	system	2026-01-24 15:09:03.070879	\N	approved
8ab7ed5f-6266-4cff-a619-0cd08c09ba34	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	licence	8ede2303-572d-4a18-b098-9466cd0c7bc8	Certificate	LIC-2026-5625.pdf	C:\\lgis\\uploads\\certificates\\LIC-2026-5625.pdf	application/pdf	2480	t	2026-01-24 05:30:29.787	\N	2026-01-24 15:30:29.790736	\N	approved
\.


--
-- Data for Name: dynamic_locations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.dynamic_locations (location_id, council_id, level, level_index, name, code, parent_id, latitude, longitude, bounds, is_active, created_at, updated_at) FROM stdin;
6ecc2348-e64e-48f5-aba2-f93967857740	3c4d4a9f-92a7-4dd2-82fb-ceff90c57094	Country	0	Papua New Guinea	PNG	\N	\N	\N	\N	true	2026-01-21 05:24:57.142207	2026-01-21 05:24:57.142207
ac56147a-3dae-4c5a-8302-9bd62ca0505a	3c4d4a9f-92a7-4dd2-82fb-ceff90c57094	Province	1	National Capital District	NCD	6ecc2348-e64e-48f5-aba2-f93967857740	\N	\N	\N	true	2026-01-21 05:24:57.146694	2026-01-21 05:24:57.146694
8da8d7d9-ec2a-4b9c-bf37-d4d0cda27e4a	3c4d4a9f-92a7-4dd2-82fb-ceff90c57094	District	2	Port Moresby North-East	PMNE	ac56147a-3dae-4c5a-8302-9bd62ca0505a	\N	\N	\N	true	2026-01-21 05:24:57.150173	2026-01-21 05:24:57.150173
ecc6445c-2ea3-4214-9c7f-fd4cb082da83	3c4d4a9f-92a7-4dd2-82fb-ceff90c57094	Ward	3	Port Moresby North-East Ward 1	\N	8da8d7d9-ec2a-4b9c-bf37-d4d0cda27e4a	\N	\N	\N	true	2026-01-21 05:24:57.153033	2026-01-21 05:24:57.153033
ededefcd-e888-4b8f-ba90-3d2a74de3760	3c4d4a9f-92a7-4dd2-82fb-ceff90c57094	Ward	3	Port Moresby North-East Ward 2	\N	8da8d7d9-ec2a-4b9c-bf37-d4d0cda27e4a	\N	\N	\N	true	2026-01-21 05:24:57.156736	2026-01-21 05:24:57.156736
a78afb17-927a-4be5-9f76-64f68e364056	3c4d4a9f-92a7-4dd2-82fb-ceff90c57094	District	2	Port Moresby South	PMS	ac56147a-3dae-4c5a-8302-9bd62ca0505a	\N	\N	\N	true	2026-01-21 05:24:57.160546	2026-01-21 05:24:57.160546
2abae66c-860b-429b-ac64-05af9a4ee004	3c4d4a9f-92a7-4dd2-82fb-ceff90c57094	Ward	3	Port Moresby South Ward 1	\N	a78afb17-927a-4be5-9f76-64f68e364056	\N	\N	\N	true	2026-01-21 05:24:57.173532	2026-01-21 05:24:57.173532
1f75bb68-13b6-4f44-b48c-a2302799e3d7	3c4d4a9f-92a7-4dd2-82fb-ceff90c57094	Ward	3	Port Moresby South Ward 2	\N	a78afb17-927a-4be5-9f76-64f68e364056	\N	\N	\N	true	2026-01-21 05:24:57.182287	2026-01-21 05:24:57.182287
da796aaf-b300-4265-ae15-4659819485df	3c4d4a9f-92a7-4dd2-82fb-ceff90c57094	District	2	Port Moresby North-West	PMNW	ac56147a-3dae-4c5a-8302-9bd62ca0505a	\N	\N	\N	true	2026-01-21 05:24:57.189098	2026-01-21 05:24:57.189098
71007742-1581-454c-9af9-522915658a2a	3c4d4a9f-92a7-4dd2-82fb-ceff90c57094	Ward	3	Port Moresby North-West Ward 1	\N	da796aaf-b300-4265-ae15-4659819485df	\N	\N	\N	true	2026-01-21 05:24:57.195742	2026-01-21 05:24:57.195742
9957aad2-7673-4cd4-8847-e87d3ec36eb2	3c4d4a9f-92a7-4dd2-82fb-ceff90c57094	Ward	3	Port Moresby North-West Ward 2	\N	da796aaf-b300-4265-ae15-4659819485df	\N	\N	\N	true	2026-01-21 05:24:57.201139	2026-01-21 05:24:57.201139
\.


--
-- Data for Name: enforcement_cases; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.enforcement_cases (case_id, council_id, request_id, case_no, type, status, offender_type, offender_id, description, created_at) FROM stdin;
\.


--
-- Data for Name: fee_schedules; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.fee_schedules (fee_id, council_id, service_id, name, basis, amount, currency, valid_from, valid_to) FROM stdin;
\.


--
-- Data for Name: inspection_evidence; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.inspection_evidence (evidence_id, council_id, inspection_id, media_type, url, hash, created_at) FROM stdin;
\.


--
-- Data for Name: inspection_findings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.inspection_findings (finding_id, council_id, inspection_id, code, severity, description, corrective_action, due_date) FROM stdin;
\.


--
-- Data for Name: inspections; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.inspections (inspection_id, council_id, request_id, inspector_user_id, scheduled_at, performed_at, result, remarks, latitude, longitude, created_at) FROM stdin;
6fa4f521-3594-499b-8d73-12faacd9ffd3	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	5b2364db-ca28-4f8b-a64b-a960c7131e8f	\N	2026-01-26 00:00:00	\N	\N	\N	\N	\N	2026-01-24 01:06:51.882333
587fda3c-33b1-4a60-8d1d-ebfb3ea9912c	3c4d4a9f-92a7-4dd2-82fb-ceff90c57094	\N	\N	2026-01-23 15:12:40.143	\N	\N	\N	\N	\N	2026-01-24 01:12:40.794778
bd181d76-3ccd-4b67-98a2-b059ef8b8b60	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	163cf2e6-8653-4d88-8daa-67c8c7bf20fd	\N	2026-01-28 00:00:00	\N	\N	\N	\N	\N	2026-01-24 15:08:39.997644
\.


--
-- Data for Name: integration_configs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.integration_configs (config_id, council_id, name, type, status, last_sync_at, description, details, created_at) FROM stdin;
\.


--
-- Data for Name: invoice_lines; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.invoice_lines (line_id, council_id, invoice_id, description, quantity, unit_price, line_total) FROM stdin;
\.


--
-- Data for Name: invoices; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.invoices (invoice_id, council_id, account_id, invoice_no, total_amount, currency, status, issued_at, due_at, created_at) FROM stdin;
\.


--
-- Data for Name: licence_renewals; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.licence_renewals (renewal_id, council_id, licence_id, request_id, previous_expiry_date, new_expiry_date, renewed_at) FROM stdin;
\.


--
-- Data for Name: licences; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.licences (licence_id, council_id, request_id, licence_no, issue_date, expiry_date, status, created_at, licence_payload_hash, pdf_hash, signed_pdf_hash, signature_metadata, version) FROM stdin;
7fcf24fb-df19-41fd-bbeb-f8cf6ea952aa	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	163cf2e6-8653-4d88-8daa-67c8c7bf20fd	LIC-2026-4768	2026-01-24	2027-01-24	active	2026-01-24 15:21:42.375186	655ca35eab22d6bed6bc4f0e950b2100dd45ee97213d6d8f92be8c52ccdfde18	5a9905722c196ef00831f39aa82f8d77465cb33cc480d09cce274ca832f22fb6	4715edfd0690729c0f2b8e99f98171dc1fced51c13d16ca5d08684828863197a	{"issuedAt": "2026-01-24T05:21:42.371Z", "algorithm": "RSASSA-PKCS1-v1_5-SHA256", "signature": "1a08cfa5f58db511a937c2348b26ae627a1d48fa642fcb4adbc9c16f881dda45b6efb175e1c22a0288f7fb1b822b509eca7d3567ef50f3f81c01eceedcbbc2c0af37f0a807242befbec728f884e5921cf015742cd53524530dcc6480a82662bc9a8583274a9547f4c152590882eee78104bb8f26104c93476cbb7e30e8564f35d9d1bd9e4547fd739403687343acb859e72164e5691bd54252339b2075014004bf9bd84d348a484f6cb7325ce4ab81349544c976db959d91ba4063bc1c332867598de7d7be151ac7773ed1cec579be6cd2c0bc9bd2874b39fb0456b3becc03916d84f85ce88cffd797bb9d73c46b0150ade344ed4f47672b6b8894f56bfed6e2"}	1
648c61a6-28d9-44ba-a1cb-51506f5e5684	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	163cf2e6-8653-4d88-8daa-67c8c7bf20fd	LIC-2026-7936	2026-01-24	2027-01-24	active	2026-01-24 15:21:56.713535	01b15fc0e1914eab98570c79612fd6d70455d2b0eaf306747c5abec94b73acae	daa334670064a0fada182ccb7ef55c700cebb84049063b3b28c3d1ca9d0219f1	73f80849c93961bb2cf79521db2a51406df58fcb0d5b7539b95620d74d16e616	{"issuedAt": "2026-01-24T05:21:56.707Z", "algorithm": "RSASSA-PKCS1-v1_5-SHA256", "signature": "2ee69bae1d139fed068d35c9cbced3c8d9e744809f6e61ae2db6e8e2d9b631d1b8f29dabbf03dd8dc9ff1bbaf2d0ee5f66ba2cd0f3c4408b86ff3f29e868e9d380e32596a9052e0d768affe467aff7214e35355d6b95ed1f8fe109acaf579fadd1bade457eda5259272d176ed00fe862a0a44cd1df275b684afb83544f072d80e3ad7af10b704ca99c420ee84cfa2973d0414b5d87fac712387781735820b387e1de77999c7ba4f950117f209abdeee2dd609173eaf4c6af2561991d7c67bf8972cd344410838cee2146b8c10aa99d7dc7fac6c2e9a958fa4bfda951d121269e4ccce8456d9caf5083e08092d147eadd2e5319a65a4220686f008653a6539649"}	1
3b9867b2-0d39-4680-b5b9-76cb140aef93	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	163cf2e6-8653-4d88-8daa-67c8c7bf20fd	LIC-2026-7019	2026-01-24	2027-01-24	active	2026-01-24 15:23:24.81413	43bc63cb7205e47fa5d05217e0c7312056b99e4e1cd76d2644513bd712b4d04b	c1814f67ff9878c90395effa2fa42649628a85878d8936e8b0e40dfd3f29fb6b	1bf5b819f3966c679dab9e8243ff84bd0598e540005e5451f0b05da2c2a279bd	{"issuedAt": "2026-01-24T05:23:24.811Z", "algorithm": "RSASSA-PKCS1-v1_5-SHA256", "signature": "57dd1fe2a06307fc3a4a77112c7b4cd137ce78b5e430f078a4fdafbdda6a4413ef7bcd3e36c847622cac3054bc0bd3b61e3bec3cee54735eee0886549433d0b85415cd77d8fcc9bb539fddff39ff05ebaa7d7eb0ae4f38d5c87cf5f5f0380cc95f6c122d60f07c92eced40dbeb87d383d756006a2e750d992ed9b3a6b2c18d515ea9ba37abae46face834a8f8e0fd8f31dfc6ce0b8f456aa61deb9832539c3d1d7c0834f7188cd25ca5e2b699ee89635e6a8af17d19d573dc9e7ad44ad1af38120ededf957f003484f07ad1d7ebffd97b7bcc0581f78d268a818ce61a373697aa7de43a2fb10c9098e9cc613f3614ef5e7f648b49ed1faf3b8422f8c57623f74"}	1
4cd9a458-51e1-43ee-9e78-db7e275c6b47	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	163cf2e6-8653-4d88-8daa-67c8c7bf20fd	LIC-2026-2544	2026-01-24	2027-01-24	active	2026-01-24 15:27:24.444015	3460d59b9917fdc5010a9afe9ef619eb3302943b32f582e10ab9e814625a2db5	f97d1387193489ff6b7e2d6417df0770b0efed2ebb8bf3845ccbdf892a69d373	ff9e670ec209119b3c32599abcfef72c864b241d471237949a1efacb12e90330	{"issuedAt": "2026-01-24T05:27:24.435Z", "algorithm": "RSASSA-PKCS1-v1_5-SHA256", "signature": "0c627d85c4c51eb1da1b3ec3272eba199e72106b94ccf0d057aaf23afa9b5bc65255e25b01ec4fec90e32558349942c1c5bf4e6f850cbbf43d82e3aa3397f604187510ae3a2d584cdc4cdaf6f582827b6c98b78f9370325dc1f9caa6c82574014bf98c42cb20f5cb019498198f8696e79c1449c50d495522e27bf8fe0b7418fd9c56a4e5bfd8a4fd707688a9dc8d122d4cd10a30382c392d987c172d0989e58efb1cd4d33d44cd1d9aaf558d20cf4bc21d248316c319c2607b8f6e6d3c0181d817e1393b86f0306b6b83307f8023dae1d0dc330692d2b0bc54c7617a6cfc7bb6c47acef33034784d0ece5e156e7ffef5f75a97376716b8c7ca204292900a995b"}	1
8ede2303-572d-4a18-b098-9466cd0c7bc8	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	163cf2e6-8653-4d88-8daa-67c8c7bf20fd	LIC-2026-5625	2026-01-24	2027-01-24	active	2026-01-24 15:30:29.779729	7ea08557e2eaaea1ae29b3a8360c07d3efcd75fe07ed7fcd6ffca861b2fb7a5f	1444c46ae9fbc4a0e314b41d1c22df9acdd52f6d52cc2f4ee69fd6fca1249f6c	eb75a8b8f0508b4d711f8aeffafe1549bda6bd7ec7e0130b5af5cd3ff32010c6	{"issuedAt": "2026-01-24T05:30:29.772Z", "algorithm": "RSASSA-PKCS1-v1_5-SHA256", "signature": "9fb24ce6298d10c20d0109520ee611807131b924ce9cdc1e3c70dd8e73c8ac222241faa1994a6cf69bc0922b2d13d3c81e4bc7c42be2fbc168f17f041300a6df3d1d32a5d6baad660868a5069f8da0656685cf0f6101a2dc2a4aef6fa7beae9ee46dd4000356683e8acdd41da5a2c01f040ff8943f7332b2be336482eef5de12eb711b278616906cab123c70292e394508b738af2777db8577a8ad5bac435ab0bd0d7edc2a28cc48d38c11a7027a1be873f02bddb0551dc9695643fd6a388b36c7d9c149530a7b5dfd8af2999b6eadec258cb371731614753c862590319977b4164ea98278d8ea588d5924c679facabfa50fb260e307cf31907c9b2f7af00339"}	1
83941242-2d7f-40fc-a506-20ab44d07db4	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	dummy-request	TEST-1769233094931	2026-01-24	2026-01-24	active	2026-01-24 15:38:15.160542	HASH_PAYLOAD	HASH_PDF	HASH_SIGNED	{"algo": "test"}	1
\.


--
-- Data for Name: license_type_fees; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.license_type_fees (id, license_type_id, amount, currency, effective_date, active, created_at) FROM stdin;
fc2a726a-5fba-4e84-a428-2c8061308724	test-license-id	150.50	PGK	2026-01-24 13:33:10.686957	t	2026-01-24 13:33:10.686957
8440668f-7a28-4034-a467-88aac2f8d1c9	test-license-id-1769225784694	250.00	PGK	2026-01-24 13:36:24.757028	t	2026-01-24 13:36:24.757028
71193640-1681-47a8-80c7-9509e5ad2875	test-license-id-1769225806324	250.00	PGK	2026-01-24 13:36:46.340553	t	2026-01-24 13:36:46.340553
241425e1-bd0f-4121-9ff1-b176966ace7c	f948d0d4-f28b-4163-b3c6-f907a6c5d840	500.00	PGK	2026-01-24 13:38:35.391809	t	2026-01-24 13:38:35.391809
a02ed935-cc63-49e8-a1a0-46262fb4a87a	3039e203-0714-4d5c-86dd-9acd1e99081f	350.00	PGK	2026-01-24 13:38:46.004111	t	2026-01-24 13:38:46.004111
0e176744-2f58-4b12-91d8-2f88afcf568c	8b20d5fd-3890-453a-88f1-5f39a3ba8356	1000.00	PGK	2026-01-24 13:38:57.371322	t	2026-01-24 13:38:57.371322
\.


--
-- Data for Name: license_types; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.license_types (id, license_name, license_category, application_form, description, created_at) FROM stdin;
3039e203-0714-4d5c-86dd-9acd1e99081f	ELECTRONIC SHOP	TRADE	FORM.1	License to trade as an electronic shop	2026-01-20 09:41:17.280509
f948d0d4-f28b-4163-b3c6-f907a6c5d840	GENERAL BUSINESS	TRADE	FORM.1	General business trade license	2026-01-20 09:41:17.293065
692b0796-76f8-43eb-acfa-4d9472c59535	PLACE OF ENTERTAINMENT	ENTERTAINMENT	FORM.1	License to keep a place of entertainment	2026-01-20 09:41:17.29653
824aeb14-49d0-4e19-a5a5-dcd81f6a414d	PHARMACY	HEALTH	FORM.1	License to trade as pharmacy	2026-01-20 09:41:17.299231
97a10043-0a7a-4530-9a3b-f8a5684e6559	SECOND HAND USED CLOTHING	TRADE	FORM.5	Second hand dealers license for used clothing	2026-01-20 09:41:17.301857
3630246a-9c75-45c0-b429-eca768e8ba03	FUEL DISTRIBUTION/INDUSTRIAL GAS	FUEL	FORM.1	License to trade as fuel distribution/industrial gas	2026-01-20 09:41:17.304804
ed80198f-9d2d-49be-82f1-8d13f3b91e03	MECHANICAL WORKSHOP	INDUSTRIAL	FORM.1	License to trade as mechanical workshop	2026-01-20 09:41:17.307296
8b20d5fd-3890-453a-88f1-5f39a3ba8356	MANUFACTURER	INDUSTRIAL	FORM.1	License to trade as manufacturer	2026-01-20 09:41:17.309241
6c8ca3d6-01c9-42d0-abbe-69fc1d3645aa	FUEL STATION	FUEL	FORM.1	License to trade as fuel station	2026-01-20 09:41:17.312762
9f564cc0-65c8-4277-9d3a-5585fb57dc3b	TAVERN	LIQUOR	FORM 1	Liquor license - Tavern	2026-01-20 09:41:17.315444
759ee9bf-5fcc-4300-a1f9-bea1158a08a2	LIMITED HOTEL	LIQUOR	FORM 1	Liquor license - Limited Hotel	2026-01-20 09:41:17.317647
582f971b-f5c1-481d-be88-13c68df2628d	PACKET (LIQUOR)	LIQUOR	FORM.5	Renewal of liquor license - Packet (sea vessels)	2026-01-20 09:41:17.320322
1a6d6c6a-382e-48e5-aac0-c63a4152ddd0	PUBLICAN	LIQUOR	FORM 1	Liquor license - Publican	2026-01-20 09:41:17.322382
feb731e5-e68a-4b8d-8551-cb75cab71492	RESTAURANT	LIQUOR	FORM 7	Liquor license - Restaurant	2026-01-20 09:41:17.324595
76f2acf3-25b0-4de6-a246-72e11f40b139	STORE KEEPERS	LIQUOR	FORM.3	Liquor license - Store Keepers	2026-01-20 09:41:17.327272
899bd00f-96d3-43b9-8025-a65815f191fc	BOOTH	LIQUOR	FORM.4	Liquor license - Booth	2026-01-20 09:41:17.32993
0442a370-8413-4a3e-8c20-81d372fb1899	BOTTLE-SHOP	LIQUOR	FORM 12	Liquor license - Bottle-Shop	2026-01-20 09:41:17.331982
38eec32b-ea1f-4a60-8244-a635552b9685	CANTEEN	LIQUOR	FORM 12	Liquor license - Canteen	2026-01-20 09:41:17.333872
07a39f8e-2ef3-40de-bce2-572bd1e08d45	CLUB	LIQUOR	FORM 6	Liquor license - Club	2026-01-20 09:41:17.335593
926eb276-15e4-4dbd-b397-0520ba13f387	MOTOR VEHICLE DEALER	TRADE	FORM.1	License to trade as motor vehicle dealer	2026-01-20 09:41:17.33753
ebcef708-32b1-4bc8-a090-c3dff544cfcd	BARBER SHOP	SERVICES	FORM.1	Barber shop license	2026-01-20 09:41:17.339607
\.


--
-- Data for Name: location_levels; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.location_levels (id, council_id, name, level, description, created_at) FROM stdin;
961a7c5f-b919-48c0-a197-aaf610fc877b	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	Section	3	Land Section	2026-01-15 04:53:42.188304
5c926b8f-2d83-4ebd-89ed-0fd5cd0a5d53	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	Lot	4	Land Lot	2026-01-15 04:53:42.206812
\.


--
-- Data for Name: locations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.locations (id, council_id, level_id, code, parent_id, boundary, centroid, status, created_at) FROM stdin;
7f25aabd-54f5-46bc-96cd-7d46a7eb68ce	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	961a7c5f-b919-48c0-a197-aaf610fc877b	01	\N	\N	\N	active	2026-01-15 04:53:42.216253
60c9f9d8-4a6c-430f-97bb-ea72f04f499f	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	961a7c5f-b919-48c0-a197-aaf610fc877b	02	\N	\N	\N	active	2026-01-15 04:53:42.224118
c717798d-8b61-4cea-b8f3-ffdef37c3806	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	961a7c5f-b919-48c0-a197-aaf610fc877b	03	\N	\N	\N	active	2026-01-15 04:53:42.229455
89d4bbc6-2bf1-4a90-9a05-379d98da1f62	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	961a7c5f-b919-48c0-a197-aaf610fc877b	04	\N	\N	\N	active	2026-01-15 04:53:42.23388
6cffcf64-f5f2-4770-89d0-7369462eea81	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	961a7c5f-b919-48c0-a197-aaf610fc877b	05	\N	\N	\N	active	2026-01-15 04:53:42.238666
5d4f2d7e-8799-45d4-9507-cf96c48a4819	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	961a7c5f-b919-48c0-a197-aaf610fc877b	06	\N	\N	\N	active	2026-01-15 04:53:42.243932
8f1b470d-7622-40b3-bf4f-a5fa20b0c4ae	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	961a7c5f-b919-48c0-a197-aaf610fc877b	07	\N	\N	\N	active	2026-01-15 04:53:42.249316
5aac14f9-2c14-40e1-9fc6-0c605c7cd259	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	961a7c5f-b919-48c0-a197-aaf610fc877b	08	\N	\N	\N	active	2026-01-15 04:53:42.253817
cf47c7e6-5bfe-4b1d-85cb-70ddd82d54dc	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	961a7c5f-b919-48c0-a197-aaf610fc877b	09	\N	\N	\N	active	2026-01-15 04:53:42.258246
da98b2a2-f7ba-4451-aeee-b34c9b937d8d	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	961a7c5f-b919-48c0-a197-aaf610fc877b	10	\N	\N	\N	active	2026-01-15 04:53:42.262925
67c82745-c0d1-47bb-addb-0507fd04521e	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	961a7c5f-b919-48c0-a197-aaf610fc877b	11	\N	\N	\N	active	2026-01-15 04:53:42.266858
1fa3b645-1150-44c1-9bd8-3f1308b976c2	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	961a7c5f-b919-48c0-a197-aaf610fc877b	12	\N	\N	\N	active	2026-01-15 04:53:42.270644
1b8712d7-697f-4253-ac6b-7561b5930929	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	961a7c5f-b919-48c0-a197-aaf610fc877b	13	\N	\N	\N	active	2026-01-15 04:53:42.275561
3ad6d428-773c-4368-8a4e-91f437c2b2a8	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	961a7c5f-b919-48c0-a197-aaf610fc877b	14	\N	\N	\N	active	2026-01-15 04:53:42.280047
c696adbf-11e6-460d-a96b-e483e14052b6	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	961a7c5f-b919-48c0-a197-aaf610fc877b	15	\N	\N	\N	active	2026-01-15 04:53:42.285944
0d5f1b8f-e6e3-429c-824a-86b477d1b640	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	961a7c5f-b919-48c0-a197-aaf610fc877b	16	\N	\N	\N	active	2026-01-15 04:53:42.289862
26f53ec2-ae28-456c-ae87-3532e676d7eb	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	961a7c5f-b919-48c0-a197-aaf610fc877b	17	\N	\N	\N	active	2026-01-15 04:53:42.29505
8a6eb322-e976-493d-b3c4-d57eea479070	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	961a7c5f-b919-48c0-a197-aaf610fc877b	18	\N	\N	\N	active	2026-01-15 04:53:42.29971
10842b21-cb44-43f3-a20b-537ab4c294b9	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	961a7c5f-b919-48c0-a197-aaf610fc877b	19	\N	\N	\N	active	2026-01-15 04:53:42.3043
acb69940-2700-4847-bea0-a55c774d615d	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	961a7c5f-b919-48c0-a197-aaf610fc877b	20	\N	\N	\N	active	2026-01-15 04:53:42.309253
eeeea359-d4c5-455f-ace7-2a4ddedd368b	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	961a7c5f-b919-48c0-a197-aaf610fc877b	21	\N	\N	\N	active	2026-01-15 04:53:42.313463
14bae985-63bd-4d0e-bae9-613b931aad43	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	961a7c5f-b919-48c0-a197-aaf610fc877b	22	\N	\N	\N	active	2026-01-15 04:53:42.317604
71b4adbf-6405-4c7a-adb3-81ec4f839cd3	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	961a7c5f-b919-48c0-a197-aaf610fc877b	23	\N	\N	\N	active	2026-01-15 04:53:42.3236
f6700465-1c3c-44dd-9a55-364ec1ab18dc	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	961a7c5f-b919-48c0-a197-aaf610fc877b	24	\N	\N	\N	active	2026-01-15 04:53:42.328732
961dcae8-3a64-48c9-aa2b-17a308762d18	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	961a7c5f-b919-48c0-a197-aaf610fc877b	25	\N	\N	\N	active	2026-01-15 04:53:42.334383
9b28cf2e-63d0-4660-8584-0a456fc74574	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	961a7c5f-b919-48c0-a197-aaf610fc877b	26	\N	\N	\N	active	2026-01-15 04:53:42.341904
1e9ab8cb-f213-47a3-8f79-18c767487de1	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	961a7c5f-b919-48c0-a197-aaf610fc877b	27	\N	\N	\N	active	2026-01-15 04:53:42.347223
bf1c504e-938b-4659-9ba0-6e88969fd9f5	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	961a7c5f-b919-48c0-a197-aaf610fc877b	28	\N	\N	\N	active	2026-01-15 04:53:42.351605
4eabf1a5-ab6f-484e-b3fe-6caf84190a1e	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	961a7c5f-b919-48c0-a197-aaf610fc877b	29	\N	\N	\N	active	2026-01-15 04:53:42.356679
5ef1419b-0cb8-402f-a85b-92cc201c461f	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	961a7c5f-b919-48c0-a197-aaf610fc877b	30	\N	\N	\N	active	2026-01-15 04:53:42.362465
8722bb56-f822-4858-befb-9eea9bc737e1	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	961a7c5f-b919-48c0-a197-aaf610fc877b	31	\N	\N	\N	active	2026-01-15 04:53:42.368422
bd57a897-5e1e-42fe-b23a-8fbde445e4a9	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	961a7c5f-b919-48c0-a197-aaf610fc877b	32	\N	\N	\N	active	2026-01-15 04:53:42.37528
1dd452c3-7b0c-4c9b-995d-ce01f667a6d7	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	961a7c5f-b919-48c0-a197-aaf610fc877b	33	\N	\N	\N	active	2026-01-15 04:53:42.380113
d1b9a88e-d475-414c-8f74-b416901a1255	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	961a7c5f-b919-48c0-a197-aaf610fc877b	34	\N	\N	\N	active	2026-01-15 04:53:42.385149
e8fd362e-cb04-41fd-a09c-79b5f1ff32a2	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	961a7c5f-b919-48c0-a197-aaf610fc877b	35	\N	\N	\N	active	2026-01-15 04:53:42.389801
92e9741f-f79a-46ba-8096-250d9ee4e43e	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	961a7c5f-b919-48c0-a197-aaf610fc877b	36	\N	\N	\N	active	2026-01-15 04:53:42.395771
a61b150b-25c4-4ce3-ad08-674fd104a80f	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	961a7c5f-b919-48c0-a197-aaf610fc877b	37	\N	\N	\N	active	2026-01-15 04:53:42.40068
f10b345d-0a1c-4cb2-aac1-dd1ab681a2d9	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	961a7c5f-b919-48c0-a197-aaf610fc877b	38	\N	\N	\N	active	2026-01-15 04:53:42.405546
d830d825-708f-4c24-a925-ed96ee2c4508	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	961a7c5f-b919-48c0-a197-aaf610fc877b	39	\N	\N	\N	active	2026-01-15 04:53:42.411179
297960a1-e5e7-4d8c-8076-835195760455	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	961a7c5f-b919-48c0-a197-aaf610fc877b	40	\N	\N	\N	active	2026-01-15 04:53:42.416928
ffc7378c-4dd5-4571-82e0-23ba5ce070d2	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	961a7c5f-b919-48c0-a197-aaf610fc877b	41	\N	\N	\N	active	2026-01-15 04:53:42.422117
2a439734-8d1b-46f2-8386-b06340175a29	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	961a7c5f-b919-48c0-a197-aaf610fc877b	42	\N	\N	\N	active	2026-01-15 04:53:42.42737
34b6548c-b0d7-4b79-9549-35db2d7c6844	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	961a7c5f-b919-48c0-a197-aaf610fc877b	43	\N	\N	\N	active	2026-01-15 04:53:42.432553
a40a31a0-ccd6-4967-b715-df15d8cd7002	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	961a7c5f-b919-48c0-a197-aaf610fc877b	44	\N	\N	\N	active	2026-01-15 04:53:42.438851
42174193-7038-4f6a-92b8-d8b07b33659c	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	961a7c5f-b919-48c0-a197-aaf610fc877b	45	\N	\N	\N	active	2026-01-15 04:53:42.445529
b50796d3-6cd5-4349-9376-41588e12b38e	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	961a7c5f-b919-48c0-a197-aaf610fc877b	46	\N	\N	\N	active	2026-01-15 04:53:42.451093
d761498a-9041-44f4-b327-1415b6d2219a	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	961a7c5f-b919-48c0-a197-aaf610fc877b	47	\N	\N	\N	active	2026-01-15 04:53:42.456869
911272fc-60ce-4971-bc2e-d8e9492f8d28	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	961a7c5f-b919-48c0-a197-aaf610fc877b	48	\N	\N	\N	active	2026-01-15 04:53:42.462833
8360e8e7-5641-4fbd-8e52-84984b835969	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	961a7c5f-b919-48c0-a197-aaf610fc877b	49	\N	\N	\N	active	2026-01-15 04:53:42.473724
e95d4b71-03b9-4f3c-950b-bacf01edc2f7	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	961a7c5f-b919-48c0-a197-aaf610fc877b	50	\N	\N	\N	active	2026-01-15 04:53:42.478535
367be9a3-ad0a-4fa6-8b0e-5d920797f2f1	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	961a7c5f-b919-48c0-a197-aaf610fc877b	51	\N	\N	\N	active	2026-01-15 04:53:42.483495
1baf7b6b-6cec-48ef-a466-c96001590101	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	961a7c5f-b919-48c0-a197-aaf610fc877b	52	\N	\N	\N	active	2026-01-15 04:53:42.48653
34737fd8-6231-4644-83eb-5107919174cc	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	961a7c5f-b919-48c0-a197-aaf610fc877b	53	\N	\N	\N	active	2026-01-15 04:53:42.489834
c9cb92d6-4147-4638-82d6-058ee15bbbca	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	961a7c5f-b919-48c0-a197-aaf610fc877b	54	\N	\N	\N	active	2026-01-15 04:53:42.494202
edd526ff-7486-400d-a2d6-09e9ef97da50	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	961a7c5f-b919-48c0-a197-aaf610fc877b	55	\N	\N	\N	active	2026-01-15 04:53:42.499869
a3f57774-5b76-4e1d-9d6c-33db0a1eda48	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	961a7c5f-b919-48c0-a197-aaf610fc877b	56	\N	\N	\N	active	2026-01-15 04:53:42.504415
34458335-f640-4283-8f2a-a0dbdd946f25	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	961a7c5f-b919-48c0-a197-aaf610fc877b	57	\N	\N	\N	active	2026-01-15 04:53:42.510279
171fcd07-d47a-47ff-a1a6-7323fdca77df	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	961a7c5f-b919-48c0-a197-aaf610fc877b	58	\N	\N	\N	active	2026-01-15 04:53:42.515238
0ebf4a30-8ae2-44f9-8aae-0729e8fa1ab9	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	961a7c5f-b919-48c0-a197-aaf610fc877b	59	\N	\N	\N	active	2026-01-15 04:53:42.520561
cbebe287-788b-4300-aea4-1453abcbbd6f	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	961a7c5f-b919-48c0-a197-aaf610fc877b	60	\N	\N	\N	active	2026-01-15 04:53:42.526769
3067d532-1852-4489-82fb-1bb02e0af581	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	961a7c5f-b919-48c0-a197-aaf610fc877b	61	\N	\N	\N	active	2026-01-15 04:53:42.532318
7d991d2c-7170-4bf7-aa25-eec1c0affbff	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	961a7c5f-b919-48c0-a197-aaf610fc877b	62	\N	\N	\N	active	2026-01-15 04:53:42.537759
79858452-b339-4ab4-8447-38581a5130b3	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	961a7c5f-b919-48c0-a197-aaf610fc877b	63	\N	\N	\N	active	2026-01-15 04:53:42.543576
2897f5fe-fe55-46e1-b166-664fd77b0266	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	961a7c5f-b919-48c0-a197-aaf610fc877b	64	\N	\N	\N	active	2026-01-15 04:53:42.549496
e34fc071-32e7-42bc-92a6-cb51cee9b8d3	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	961a7c5f-b919-48c0-a197-aaf610fc877b	65	\N	\N	\N	active	2026-01-15 04:53:42.557024
ea5774dd-82ce-496e-b756-1a638ea93ad0	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	961a7c5f-b919-48c0-a197-aaf610fc877b	66	\N	\N	\N	active	2026-01-15 04:53:42.563537
09b5caf7-44b2-4857-9691-bfa019aada21	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	961a7c5f-b919-48c0-a197-aaf610fc877b	67	\N	\N	\N	active	2026-01-15 04:53:42.570524
c7c4b304-a0e6-4c69-b853-35678edc9c55	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	961a7c5f-b919-48c0-a197-aaf610fc877b	68	\N	\N	\N	active	2026-01-15 04:53:42.577731
2c96fded-2a65-4b02-bf73-aebd634d3e8a	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	961a7c5f-b919-48c0-a197-aaf610fc877b	69	\N	\N	\N	active	2026-01-15 04:53:42.585479
dc4faca3-0a0f-472c-be1e-b35aee669b6a	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	961a7c5f-b919-48c0-a197-aaf610fc877b	70	\N	\N	\N	active	2026-01-15 04:53:42.593515
f7cce728-af87-43bb-8175-161ff81d48b7	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	961a7c5f-b919-48c0-a197-aaf610fc877b	71	\N	\N	\N	active	2026-01-15 04:53:42.599587
e54a27cf-b9f0-4a57-8e7f-1ad33f011e67	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	961a7c5f-b919-48c0-a197-aaf610fc877b	72	\N	\N	\N	active	2026-01-15 04:53:42.605736
7ca8e755-4428-4d72-93f0-5cb2d16dd116	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	961a7c5f-b919-48c0-a197-aaf610fc877b	73	\N	\N	\N	active	2026-01-15 04:53:42.612395
62d94f36-1566-4481-96ad-2a18b488670b	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	961a7c5f-b919-48c0-a197-aaf610fc877b	74	\N	\N	\N	active	2026-01-15 04:53:42.61775
f76debce-3077-4dbd-ac7e-0cdb263269fb	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	961a7c5f-b919-48c0-a197-aaf610fc877b	75	\N	\N	\N	active	2026-01-15 04:53:42.623701
2c00d274-6ada-4bfa-bfa6-4823e801e218	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	961a7c5f-b919-48c0-a197-aaf610fc877b	76	\N	\N	\N	active	2026-01-15 04:53:42.63145
386a888e-f07e-4852-8c7b-f02c12b27561	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	961a7c5f-b919-48c0-a197-aaf610fc877b	77	\N	\N	\N	active	2026-01-15 04:53:42.637016
c985ab1c-7a66-45e9-bf32-2c939792c1e0	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	961a7c5f-b919-48c0-a197-aaf610fc877b	78	\N	\N	\N	active	2026-01-15 04:53:42.643323
9ffcb02a-27c1-4d84-9694-0970e9f06320	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	961a7c5f-b919-48c0-a197-aaf610fc877b	79	\N	\N	\N	active	2026-01-15 04:53:42.648699
68ad744a-aae2-4277-b984-9934e4dd255d	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	961a7c5f-b919-48c0-a197-aaf610fc877b	80	\N	\N	\N	active	2026-01-15 04:53:42.653424
4ac39d00-c188-4f68-9e64-6087de455d21	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	961a7c5f-b919-48c0-a197-aaf610fc877b	81	\N	\N	\N	active	2026-01-15 04:53:42.658427
a0f74482-d964-4294-b75e-cbfe9d10c2fa	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	961a7c5f-b919-48c0-a197-aaf610fc877b	82	\N	\N	\N	active	2026-01-15 04:53:42.663408
38d44e67-9b9a-4f51-bc61-dddb27afe50b	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	961a7c5f-b919-48c0-a197-aaf610fc877b	83	\N	\N	\N	active	2026-01-15 04:53:42.668929
150d8aa2-a07b-4a63-a8e5-383381a5a416	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	961a7c5f-b919-48c0-a197-aaf610fc877b	84	\N	\N	\N	active	2026-01-15 04:53:42.673047
de499e4b-2b3c-45be-85fa-da05c59c350e	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	961a7c5f-b919-48c0-a197-aaf610fc877b	85	\N	\N	\N	active	2026-01-15 04:53:42.678476
3fce0b79-7903-422d-ad28-8f250b05e461	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	961a7c5f-b919-48c0-a197-aaf610fc877b	86	\N	\N	\N	active	2026-01-15 04:53:42.683816
32af9a2c-d76f-4e68-8ad9-0d9f71f36329	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	961a7c5f-b919-48c0-a197-aaf610fc877b	87	\N	\N	\N	active	2026-01-15 04:53:42.689295
fd22d81b-820e-4d8d-821b-8066f0df5ea5	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	961a7c5f-b919-48c0-a197-aaf610fc877b	88	\N	\N	\N	active	2026-01-15 04:53:42.694599
98006105-f51f-4c6b-8814-696dedec8b78	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	961a7c5f-b919-48c0-a197-aaf610fc877b	89	\N	\N	\N	active	2026-01-15 04:53:42.699857
d6ba42d2-5ee1-4f73-a485-61570b3bfb60	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	961a7c5f-b919-48c0-a197-aaf610fc877b	90	\N	\N	\N	active	2026-01-15 04:53:42.70377
19f4c269-30c4-45f8-b826-b0c64db18f7b	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	961a7c5f-b919-48c0-a197-aaf610fc877b	91	\N	\N	\N	active	2026-01-15 04:53:42.71156
2e815aa0-6233-4d9f-8722-ab0e417b336d	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	961a7c5f-b919-48c0-a197-aaf610fc877b	92	\N	\N	\N	active	2026-01-15 04:53:42.717319
b3dd6a75-84ef-4148-9a02-193f2e0dfc27	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	961a7c5f-b919-48c0-a197-aaf610fc877b	93	\N	\N	\N	active	2026-01-15 04:53:42.723807
e0fc8405-7f6c-4ee8-bf1a-bcfe4f7b396b	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	961a7c5f-b919-48c0-a197-aaf610fc877b	94	\N	\N	\N	active	2026-01-15 04:53:42.730306
1f253b50-91c1-4cae-98f3-6dc81c2a5feb	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	961a7c5f-b919-48c0-a197-aaf610fc877b	95	\N	\N	\N	active	2026-01-15 04:53:42.735876
6f732175-1afd-4fde-9867-729a18ef456e	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	961a7c5f-b919-48c0-a197-aaf610fc877b	96	\N	\N	\N	active	2026-01-15 04:53:42.742946
edc3754a-00fe-491a-9bd3-a02ac1de1a1a	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	961a7c5f-b919-48c0-a197-aaf610fc877b	97	\N	\N	\N	active	2026-01-15 04:53:42.748671
d278c522-fa5a-4285-822a-2693d334522e	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	961a7c5f-b919-48c0-a197-aaf610fc877b	98	\N	\N	\N	active	2026-01-15 04:53:42.752716
ae792928-84c8-4cd3-a70f-69e0fec4a3c5	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	961a7c5f-b919-48c0-a197-aaf610fc877b	99	\N	\N	\N	active	2026-01-15 04:53:42.757611
6853d025-e619-445a-9cff-32904541e0ac	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	961a7c5f-b919-48c0-a197-aaf610fc877b	100	\N	\N	\N	active	2026-01-15 04:53:42.762626
41af39ae-2dea-4ba1-b154-ad6cdcf48120	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	5c926b8f-2d83-4ebd-89ed-0fd5cd0a5d53	01	\N	\N	\N	active	2026-01-15 04:53:42.768363
028e5b88-d78b-4703-80bf-d6930feaaee9	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	5c926b8f-2d83-4ebd-89ed-0fd5cd0a5d53	02	\N	\N	\N	active	2026-01-15 04:53:42.772915
0b5facb5-8095-4e44-b7c7-10dbc8b5c8be	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	5c926b8f-2d83-4ebd-89ed-0fd5cd0a5d53	03	\N	\N	\N	active	2026-01-15 04:53:42.77829
55b83c42-593c-4a75-94f0-8ea1eef09318	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	5c926b8f-2d83-4ebd-89ed-0fd5cd0a5d53	04	\N	\N	\N	active	2026-01-15 04:53:42.784162
c1f6c745-68b3-400a-be28-7c9c6e3a440d	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	5c926b8f-2d83-4ebd-89ed-0fd5cd0a5d53	05	\N	\N	\N	active	2026-01-15 04:53:42.79166
667b2732-3f3c-44d0-8a46-1ef56111cc3c	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	5c926b8f-2d83-4ebd-89ed-0fd5cd0a5d53	06	\N	\N	\N	active	2026-01-15 04:53:42.797713
7766d50e-c8df-4b70-b634-6a6746abfcb3	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	5c926b8f-2d83-4ebd-89ed-0fd5cd0a5d53	07	\N	\N	\N	active	2026-01-15 04:53:42.80464
942d154c-f4d2-48f6-900b-3d77567cd7df	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	5c926b8f-2d83-4ebd-89ed-0fd5cd0a5d53	08	\N	\N	\N	active	2026-01-15 04:53:42.812172
b2a79726-b8b9-447b-a893-4a609a93ce64	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	5c926b8f-2d83-4ebd-89ed-0fd5cd0a5d53	09	\N	\N	\N	active	2026-01-15 04:53:42.817948
83686154-9439-413f-b444-6a2f68dfe0b8	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	5c926b8f-2d83-4ebd-89ed-0fd5cd0a5d53	10	\N	\N	\N	active	2026-01-15 04:53:42.824153
60423ca7-76c2-4080-9bd1-4aa086ee7529	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	5c926b8f-2d83-4ebd-89ed-0fd5cd0a5d53	11	\N	\N	\N	active	2026-01-15 04:53:42.831476
e9c6a97f-dd0c-40fc-a84f-60d7f47aca84	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	5c926b8f-2d83-4ebd-89ed-0fd5cd0a5d53	12	\N	\N	\N	active	2026-01-15 04:53:42.837826
b47466ab-7fd7-41d3-9fdf-895544f37157	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	5c926b8f-2d83-4ebd-89ed-0fd5cd0a5d53	13	\N	\N	\N	active	2026-01-15 04:53:42.845033
f45f950d-9168-41cc-8fbe-0441a845d1b7	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	5c926b8f-2d83-4ebd-89ed-0fd5cd0a5d53	14	\N	\N	\N	active	2026-01-15 04:53:42.850666
cb5042bc-4b25-4f95-a771-fe7b679f0bf8	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	5c926b8f-2d83-4ebd-89ed-0fd5cd0a5d53	15	\N	\N	\N	active	2026-01-15 04:53:42.857996
a182c6de-1d96-4e58-afb9-4ae826fb5f2a	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	5c926b8f-2d83-4ebd-89ed-0fd5cd0a5d53	16	\N	\N	\N	active	2026-01-15 04:53:42.865569
2ce0f976-8660-4b4f-98b1-3277d09cde57	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	5c926b8f-2d83-4ebd-89ed-0fd5cd0a5d53	17	\N	\N	\N	active	2026-01-15 04:53:42.875052
daa28bba-1b4d-45bf-a936-25cfd3ca8876	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	5c926b8f-2d83-4ebd-89ed-0fd5cd0a5d53	18	\N	\N	\N	active	2026-01-15 04:53:42.881561
308f6733-31d6-4559-a94d-d7aab212fea4	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	5c926b8f-2d83-4ebd-89ed-0fd5cd0a5d53	19	\N	\N	\N	active	2026-01-15 04:53:42.888352
7c132639-cc34-419f-9b2e-99724fc7ba4a	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	5c926b8f-2d83-4ebd-89ed-0fd5cd0a5d53	20	\N	\N	\N	active	2026-01-15 04:53:42.895368
0656f0b0-53ae-4776-9e8c-7178e6b5bdb0	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	5c926b8f-2d83-4ebd-89ed-0fd5cd0a5d53	21	\N	\N	\N	active	2026-01-15 04:53:42.902817
604201b8-772f-42df-b491-a3b028a08f8a	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	5c926b8f-2d83-4ebd-89ed-0fd5cd0a5d53	22	\N	\N	\N	active	2026-01-15 04:53:42.908374
4b2d50b9-bb9f-4e28-9e03-58fbeb1245cd	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	5c926b8f-2d83-4ebd-89ed-0fd5cd0a5d53	23	\N	\N	\N	active	2026-01-15 04:53:42.914084
182813b3-f0d1-4544-96a2-885f42d88554	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	5c926b8f-2d83-4ebd-89ed-0fd5cd0a5d53	24	\N	\N	\N	active	2026-01-15 04:53:42.920104
91b2fcff-d25d-42bf-a701-6a7b21df5793	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	5c926b8f-2d83-4ebd-89ed-0fd5cd0a5d53	25	\N	\N	\N	active	2026-01-15 04:53:42.926471
583d7a12-7649-44dd-ba0d-215691219a19	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	5c926b8f-2d83-4ebd-89ed-0fd5cd0a5d53	26	\N	\N	\N	active	2026-01-15 04:53:42.931942
89945aec-7899-4367-b989-3ed1c3f00fa7	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	5c926b8f-2d83-4ebd-89ed-0fd5cd0a5d53	27	\N	\N	\N	active	2026-01-15 04:53:42.935986
e883d229-4048-4240-8a3c-f733c6cb46da	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	5c926b8f-2d83-4ebd-89ed-0fd5cd0a5d53	28	\N	\N	\N	active	2026-01-15 04:53:42.942646
e3d1d294-e8ba-4dbb-a0ee-d032da5571c9	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	5c926b8f-2d83-4ebd-89ed-0fd5cd0a5d53	29	\N	\N	\N	active	2026-01-15 04:53:42.949701
219e266c-1a3b-4b1a-8142-f7b55df952f2	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	5c926b8f-2d83-4ebd-89ed-0fd5cd0a5d53	30	\N	\N	\N	active	2026-01-15 04:53:42.953507
26ad46c6-c42a-48de-b82e-14ff574cce8c	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	5c926b8f-2d83-4ebd-89ed-0fd5cd0a5d53	31	\N	\N	\N	active	2026-01-15 04:53:42.95795
561ac631-64cf-4679-805d-bbf027d5bd21	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	5c926b8f-2d83-4ebd-89ed-0fd5cd0a5d53	32	\N	\N	\N	active	2026-01-15 04:53:42.963972
3769ee82-f608-465f-8e16-e5d79d4793e1	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	5c926b8f-2d83-4ebd-89ed-0fd5cd0a5d53	33	\N	\N	\N	active	2026-01-15 04:53:42.969647
b25c8854-7ecb-454f-bad8-4e0172a06e25	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	5c926b8f-2d83-4ebd-89ed-0fd5cd0a5d53	34	\N	\N	\N	active	2026-01-15 04:53:42.977267
53419dab-3ea3-4929-9914-487eeb66dae3	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	5c926b8f-2d83-4ebd-89ed-0fd5cd0a5d53	35	\N	\N	\N	active	2026-01-15 04:53:42.983256
3fefd3b2-9431-4a88-aaa9-8da7a4931c4a	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	5c926b8f-2d83-4ebd-89ed-0fd5cd0a5d53	36	\N	\N	\N	active	2026-01-15 04:53:42.989031
8f3e9753-48c3-42a0-a5cb-c16d9b53bef5	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	5c926b8f-2d83-4ebd-89ed-0fd5cd0a5d53	37	\N	\N	\N	active	2026-01-15 04:53:42.994438
f457c1e7-1053-49a5-8ba4-6be997b71c68	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	5c926b8f-2d83-4ebd-89ed-0fd5cd0a5d53	38	\N	\N	\N	active	2026-01-15 04:53:42.999119
7cff640d-5c0a-4896-bc58-3775e9e85a0b	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	5c926b8f-2d83-4ebd-89ed-0fd5cd0a5d53	39	\N	\N	\N	active	2026-01-15 04:53:43.002481
0e753369-2ed9-4c4d-afef-4f1a04965137	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	5c926b8f-2d83-4ebd-89ed-0fd5cd0a5d53	40	\N	\N	\N	active	2026-01-15 04:53:43.008137
c4633e23-e22d-4b23-bb88-1fbba48f14aa	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	5c926b8f-2d83-4ebd-89ed-0fd5cd0a5d53	41	\N	\N	\N	active	2026-01-15 04:53:43.015486
d8a0b7c0-aafc-4b02-86a8-0637aa664d6a	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	5c926b8f-2d83-4ebd-89ed-0fd5cd0a5d53	42	\N	\N	\N	active	2026-01-15 04:53:43.019948
ae30da64-3652-46ef-b675-993834a1aa1f	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	5c926b8f-2d83-4ebd-89ed-0fd5cd0a5d53	43	\N	\N	\N	active	2026-01-15 04:53:43.026461
28b2d248-e43e-494e-a950-189bb33015d6	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	5c926b8f-2d83-4ebd-89ed-0fd5cd0a5d53	44	\N	\N	\N	active	2026-01-15 04:53:43.031816
aed5d16e-8a12-4e86-9d55-2c9cee209376	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	5c926b8f-2d83-4ebd-89ed-0fd5cd0a5d53	45	\N	\N	\N	active	2026-01-15 04:53:43.036483
cb1c8875-8a24-4362-b04e-421a79bb7eb3	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	5c926b8f-2d83-4ebd-89ed-0fd5cd0a5d53	46	\N	\N	\N	active	2026-01-15 04:53:43.042827
f6305c3c-9cec-4ed8-a5bf-fff89d1ea9bc	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	5c926b8f-2d83-4ebd-89ed-0fd5cd0a5d53	47	\N	\N	\N	active	2026-01-15 04:53:43.050185
42b42229-258b-4c30-bfd8-a1244587926c	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	5c926b8f-2d83-4ebd-89ed-0fd5cd0a5d53	48	\N	\N	\N	active	2026-01-15 04:53:43.056023
f070b971-5161-4707-a46b-f98203b72f5c	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	5c926b8f-2d83-4ebd-89ed-0fd5cd0a5d53	49	\N	\N	\N	active	2026-01-15 04:53:43.062877
9a23817a-e9de-4f82-bd63-b8d873d81d1f	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	5c926b8f-2d83-4ebd-89ed-0fd5cd0a5d53	50	\N	\N	\N	active	2026-01-15 04:53:43.070604
4aff63be-b493-41f2-8df8-ea66a94a5351	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	5c926b8f-2d83-4ebd-89ed-0fd5cd0a5d53	51	\N	\N	\N	active	2026-01-15 04:53:43.078054
da0cbc3d-ce14-4b81-9cc9-ea52153178d3	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	5c926b8f-2d83-4ebd-89ed-0fd5cd0a5d53	52	\N	\N	\N	active	2026-01-15 04:53:43.083778
da25d793-1d60-493f-a443-f7617d54ece4	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	5c926b8f-2d83-4ebd-89ed-0fd5cd0a5d53	53	\N	\N	\N	active	2026-01-15 04:53:43.091618
5e722e7b-c165-4fd2-9992-490755fd2429	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	5c926b8f-2d83-4ebd-89ed-0fd5cd0a5d53	54	\N	\N	\N	active	2026-01-15 04:53:43.099584
6956cd24-00be-428e-ba6a-696197624e13	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	5c926b8f-2d83-4ebd-89ed-0fd5cd0a5d53	55	\N	\N	\N	active	2026-01-15 04:53:43.108475
c0c0d607-6c36-43ae-ac83-9f85f4700f7c	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	5c926b8f-2d83-4ebd-89ed-0fd5cd0a5d53	56	\N	\N	\N	active	2026-01-15 04:53:43.115503
26f6ba0e-2f03-46e5-a36c-5139c89e70a0	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	5c926b8f-2d83-4ebd-89ed-0fd5cd0a5d53	57	\N	\N	\N	active	2026-01-15 04:53:43.121499
a0e38455-27fd-4d29-949d-9bd4d8c46644	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	5c926b8f-2d83-4ebd-89ed-0fd5cd0a5d53	58	\N	\N	\N	active	2026-01-15 04:53:43.130423
e205e7cf-1e8c-4562-9c3f-c4b20d9492f1	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	5c926b8f-2d83-4ebd-89ed-0fd5cd0a5d53	59	\N	\N	\N	active	2026-01-15 04:53:43.138025
e4a7b934-2deb-44d1-a586-8bb70bb0b1e5	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	5c926b8f-2d83-4ebd-89ed-0fd5cd0a5d53	60	\N	\N	\N	active	2026-01-15 04:53:43.144684
83752861-75f3-4c7a-8344-830780aff1b0	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	5c926b8f-2d83-4ebd-89ed-0fd5cd0a5d53	61	\N	\N	\N	active	2026-01-15 04:53:43.15025
bd51fce5-60db-47c3-8443-7cf60cd8befb	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	5c926b8f-2d83-4ebd-89ed-0fd5cd0a5d53	62	\N	\N	\N	active	2026-01-15 04:53:43.156301
4d2a7f71-a9ab-4cdf-a34a-c0e6529d3bdc	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	5c926b8f-2d83-4ebd-89ed-0fd5cd0a5d53	63	\N	\N	\N	active	2026-01-15 04:53:43.163486
fbabef8b-fb7c-4d87-832e-f1193a03f035	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	5c926b8f-2d83-4ebd-89ed-0fd5cd0a5d53	64	\N	\N	\N	active	2026-01-15 04:53:43.170377
ef4ee9ba-6ade-41d6-acf7-2a0f59000317	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	5c926b8f-2d83-4ebd-89ed-0fd5cd0a5d53	65	\N	\N	\N	active	2026-01-15 04:53:43.178136
3d4f0d70-9374-4f44-a8fc-ce1633d594f7	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	5c926b8f-2d83-4ebd-89ed-0fd5cd0a5d53	66	\N	\N	\N	active	2026-01-15 04:53:43.183228
f6608420-63a7-4999-a3d8-e5c6460cd8ff	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	5c926b8f-2d83-4ebd-89ed-0fd5cd0a5d53	67	\N	\N	\N	active	2026-01-15 04:53:43.189176
23985a06-6863-43d2-8d74-482acbc48bb1	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	5c926b8f-2d83-4ebd-89ed-0fd5cd0a5d53	68	\N	\N	\N	active	2026-01-15 04:53:43.195562
bb00f771-b3ba-42d6-b989-a4e3fd299366	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	5c926b8f-2d83-4ebd-89ed-0fd5cd0a5d53	69	\N	\N	\N	active	2026-01-15 04:53:43.202791
1066e166-2df0-45f7-ac77-5c3c623c48d2	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	5c926b8f-2d83-4ebd-89ed-0fd5cd0a5d53	70	\N	\N	\N	active	2026-01-15 04:53:43.207606
36a11c91-bfcb-4f2e-b582-654494be10cf	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	5c926b8f-2d83-4ebd-89ed-0fd5cd0a5d53	71	\N	\N	\N	active	2026-01-15 04:53:43.214228
823504aa-2ed2-4c67-9520-33acb6790cb8	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	5c926b8f-2d83-4ebd-89ed-0fd5cd0a5d53	72	\N	\N	\N	active	2026-01-15 04:53:43.218541
1f62117e-e2ae-429b-a1f7-59348d208ebf	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	5c926b8f-2d83-4ebd-89ed-0fd5cd0a5d53	73	\N	\N	\N	active	2026-01-15 04:53:43.223625
0e17e102-29e8-49b8-99f8-7b9ac4bb8806	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	5c926b8f-2d83-4ebd-89ed-0fd5cd0a5d53	74	\N	\N	\N	active	2026-01-15 04:53:43.229364
e89e2ca1-99dc-442b-bb27-1bc935404e91	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	5c926b8f-2d83-4ebd-89ed-0fd5cd0a5d53	75	\N	\N	\N	active	2026-01-15 04:53:43.234486
69cef218-32c5-4e5a-bc63-2789e8f3696b	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	5c926b8f-2d83-4ebd-89ed-0fd5cd0a5d53	76	\N	\N	\N	active	2026-01-15 04:53:43.241399
a8cf090a-2e54-4217-ba50-47ffde5e5672	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	5c926b8f-2d83-4ebd-89ed-0fd5cd0a5d53	77	\N	\N	\N	active	2026-01-15 04:53:43.249943
a819c7a7-312d-4f6c-a403-b87556ce9f64	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	5c926b8f-2d83-4ebd-89ed-0fd5cd0a5d53	78	\N	\N	\N	active	2026-01-15 04:53:43.256093
a21c6985-01fd-43a3-a446-face9dc8c540	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	5c926b8f-2d83-4ebd-89ed-0fd5cd0a5d53	79	\N	\N	\N	active	2026-01-15 04:53:43.263064
8704dbe6-ca17-478a-ad25-edea5bc8f5c7	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	5c926b8f-2d83-4ebd-89ed-0fd5cd0a5d53	80	\N	\N	\N	active	2026-01-15 04:53:43.268802
e5ad336e-5a76-48bb-a0ff-fcfd13f79383	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	5c926b8f-2d83-4ebd-89ed-0fd5cd0a5d53	81	\N	\N	\N	active	2026-01-15 04:53:43.27374
c301b069-2243-4ea7-95a5-dbc6c5bdbb0a	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	5c926b8f-2d83-4ebd-89ed-0fd5cd0a5d53	82	\N	\N	\N	active	2026-01-15 04:53:43.278963
84591c80-2154-4766-a8b9-2bff4f345227	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	5c926b8f-2d83-4ebd-89ed-0fd5cd0a5d53	83	\N	\N	\N	active	2026-01-15 04:53:43.283139
8956ce4c-7832-41c6-8c4a-d88edb2fc018	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	5c926b8f-2d83-4ebd-89ed-0fd5cd0a5d53	84	\N	\N	\N	active	2026-01-15 04:53:43.287256
aeb8f78d-2e49-4b21-9ab9-619db6485b00	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	5c926b8f-2d83-4ebd-89ed-0fd5cd0a5d53	85	\N	\N	\N	active	2026-01-15 04:53:43.293202
fcc3811a-4dbc-4cd8-a1a6-774f07d289e2	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	5c926b8f-2d83-4ebd-89ed-0fd5cd0a5d53	86	\N	\N	\N	active	2026-01-15 04:53:43.298309
22dbf849-70fd-4cb3-9c96-a812b270b19f	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	5c926b8f-2d83-4ebd-89ed-0fd5cd0a5d53	87	\N	\N	\N	active	2026-01-15 04:53:43.302881
cee24db4-b732-4aa5-b95c-4a323485df23	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	5c926b8f-2d83-4ebd-89ed-0fd5cd0a5d53	88	\N	\N	\N	active	2026-01-15 04:53:43.30751
c0b7aa5d-cef8-4dc5-8a1f-6765c6147c23	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	5c926b8f-2d83-4ebd-89ed-0fd5cd0a5d53	89	\N	\N	\N	active	2026-01-15 04:53:43.312865
75ac6029-b227-4087-b16c-c80293befc93	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	5c926b8f-2d83-4ebd-89ed-0fd5cd0a5d53	90	\N	\N	\N	active	2026-01-15 04:53:43.317998
afb3ba4b-d8e8-42b3-9aab-6648f2e1768e	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	5c926b8f-2d83-4ebd-89ed-0fd5cd0a5d53	91	\N	\N	\N	active	2026-01-15 04:53:43.322396
1a8cc8a3-418e-4310-9b37-616da3b05a69	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	5c926b8f-2d83-4ebd-89ed-0fd5cd0a5d53	92	\N	\N	\N	active	2026-01-15 04:53:43.328021
02df2bf1-e76f-424b-b63a-a494fd11c1d9	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	5c926b8f-2d83-4ebd-89ed-0fd5cd0a5d53	93	\N	\N	\N	active	2026-01-15 04:53:43.331825
9d98c7ab-b70e-4485-beaf-5d97f87cbdbd	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	5c926b8f-2d83-4ebd-89ed-0fd5cd0a5d53	94	\N	\N	\N	active	2026-01-15 04:53:43.33506
8c7c9dbe-0778-4807-b665-69a30f22e945	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	5c926b8f-2d83-4ebd-89ed-0fd5cd0a5d53	95	\N	\N	\N	active	2026-01-15 04:53:43.338306
be24ae48-c65f-4192-88ab-a5e311063696	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	5c926b8f-2d83-4ebd-89ed-0fd5cd0a5d53	96	\N	\N	\N	active	2026-01-15 04:53:43.341893
5aadf5f4-addb-4257-a535-b72d5bfb5a07	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	5c926b8f-2d83-4ebd-89ed-0fd5cd0a5d53	97	\N	\N	\N	active	2026-01-15 04:53:43.347414
67d76885-fb0c-4d4d-96de-1bac83ef67cb	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	5c926b8f-2d83-4ebd-89ed-0fd5cd0a5d53	98	\N	\N	\N	active	2026-01-15 04:53:43.350892
cabcceb4-a4b8-4479-8e1d-b73bbb51af50	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	5c926b8f-2d83-4ebd-89ed-0fd5cd0a5d53	99	\N	\N	\N	active	2026-01-15 04:53:43.355429
0a27ef41-b688-46e9-8f95-5ef95badaf13	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	5c926b8f-2d83-4ebd-89ed-0fd5cd0a5d53	100	\N	\N	\N	active	2026-01-15 04:53:43.36145
\.


--
-- Data for Name: markets; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.markets (market_id, council_id, name, location, capacity, operating_hours, status, created_at) FROM stdin;
aae7fb01-be08-416b-bfc9-c7a4cbea9c22	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	Gordons Market	Gordons, Port Moresby	500	06:00-18:00	active	2026-01-14 06:40:16.284739
f306ff25-5b59-4361-94b0-b3039bfb809e	f2739382-95a8-4197-ace0-bd1bcc5c1a11	Gordons Market	Gordons, Port Moresby	500	06:00-18:00	active	2026-01-19 04:04:14.565542
c1b8988e-b419-4447-adc0-e46c72e3c55d	90c57094-13e2-42f1-be1f-1a1b50595f70	Gordons Market	Gordons, Port Moresby	500	06:00-18:00	active	2026-01-19 13:30:22.665215
\.


--
-- Data for Name: notices; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.notices (notice_id, council_id, case_id, notice_no, notice_type, issued_date, compliance_due, details, status, created_at) FROM stdin;
\.


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.notifications (notification_id, council_id, user_id, type, title, message, reference_type, reference_id, read, created_at) FROM stdin;
8a0709eb-f350-4880-a74b-5a83d15a2b6b	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	3f8febd7-1aae-45b1-a512-2013c5d697f2	info	Application Processing	Your application cce4af46-d401-445f-a59e-d9371f0d9265 has been processing.	service_request	cce4af46-d401-445f-a59e-d9371f0d9265	f	2026-01-17 13:22:21.197933
e30b4c3f-6292-4eb2-9f24-08202a965cc7	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	3f8febd7-1aae-45b1-a512-2013c5d697f2	success	Application Approved	Your application cce4af46-d401-445f-a59e-d9371f0d9265 has been approved.	service_request	cce4af46-d401-445f-a59e-d9371f0d9265	f	2026-01-17 23:14:12.754386
fa8ebe72-1844-4e87-be6a-510e91fb0ac2	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	1c0bf792-8d5b-466a-acc5-83bbcf22e979	info	Application Processing	Your application LIC-2026-7194 has been processing.	service_request	48967986-6b8b-430f-960f-056a7620b906	f	2026-01-17 23:58:52.104926
de796319-edfd-4b0c-84c5-b265b7ef176a	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	1c0bf792-8d5b-466a-acc5-83bbcf22e979	info	Application Processing	Your application LIC-2026-2928 has been processing.	service_request	2263b419-d125-4e00-ad7e-18b365b3af8e	f	2026-01-18 01:18:47.459508
6eb5d75d-829c-4966-af55-dbbcebea1cfd	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	1c0bf792-8d5b-466a-acc5-83bbcf22e979	error	Application Rejected	Your application LIC-2026-2928 has been rejected.	service_request	2263b419-d125-4e00-ad7e-18b365b3af8e	f	2026-01-18 01:19:25.37292
63c7689c-6525-4a64-bfdd-8d4b672a2ed3	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	d3329bb0-5fa5-42ab-99a8-af5dc0398fe1	info	Application Processing	Your application LIC-2026-8594 has been processing.	service_request	c206729f-0afa-4157-88d6-9c90ff876107	f	2026-01-18 16:07:09.084152
415d7fc2-5765-4f54-8b98-a35efe2a5a80	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	d3329bb0-5fa5-42ab-99a8-af5dc0398fe1	info	Application Inspection	Your application LIC-2026-8594 has been inspection.	service_request	c206729f-0afa-4157-88d6-9c90ff876107	f	2026-01-18 16:08:45.947021
c8e4adf5-2e08-4242-94ed-e28821ffaf88	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	d3329bb0-5fa5-42ab-99a8-af5dc0398fe1	success	Application Approved	Your application LIC-2026-8594 has been approved.	service_request	c206729f-0afa-4157-88d6-9c90ff876107	f	2026-01-18 16:09:41.989
f7ff4e6b-58f0-4b88-bc53-e4e2861b8e73	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	f40ff078-c74a-4688-9aea-d3f01d23dedd	info	Application Processing	Your application LIC-2026-1461 has been processing.	service_request	163cf2e6-8653-4d88-8daa-67c8c7bf20fd	f	2026-01-18 16:51:16.616579
24c14c70-d22f-4477-865f-772ecf10d1ee	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	f40ff078-c74a-4688-9aea-d3f01d23dedd	info	Application Inspection	Your application LIC-2026-1461 has been inspection.	service_request	163cf2e6-8653-4d88-8daa-67c8c7bf20fd	f	2026-01-18 16:52:54.091355
e56c1f98-8f10-4ebe-a8b0-13fab0fbb269	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	f40ff078-c74a-4688-9aea-d3f01d23dedd	success	Application Approved	Your application LIC-2026-1461 has been approved.	service_request	163cf2e6-8653-4d88-8daa-67c8c7bf20fd	f	2026-01-18 16:53:06.996628
30f57b18-c7de-41ed-848f-110c07dba118	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	1c0bf792-8d5b-466a-acc5-83bbcf22e979	error	Application Rejected	Your application LIC-2026-7194 has been rejected.	service_request	48967986-6b8b-430f-960f-056a7620b906	f	2026-01-18 22:12:00.293912
43a60744-34cd-408a-935b-d3e3b8fab4d8	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	1c0bf792-8d5b-466a-acc5-83bbcf22e979	error	Application Rejected	Your application LIC-2026-7194 has been rejected.	service_request	48967986-6b8b-430f-960f-056a7620b906	f	2026-01-18 22:16:18.921585
8f9464c0-410b-417a-8bc8-171674da1df1	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	1c0bf792-8d5b-466a-acc5-83bbcf22e979	info	Application Processing	Your application LIC-2026-6572 has been processing.	service_request	8a6e1251-4755-44f4-8d67-503250f7e063	f	2026-01-18 22:25:20.045208
c88790e4-6251-42f2-8de6-c49c95133726	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	1c0bf792-8d5b-466a-acc5-83bbcf22e979	info	Application Processing	Your application LIC-2026-4193 has been processing.	service_request	5b2364db-ca28-4f8b-a64b-a960c7131e8f	f	2026-01-18 22:49:59.380239
32808ffb-feeb-4acc-a4c1-da49e1de1afe	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	1c0bf792-8d5b-466a-acc5-83bbcf22e979	info	Application Processing	Your application LIC-2026-4193 has been processing.	service_request	5b2364db-ca28-4f8b-a64b-a960c7131e8f	f	2026-01-18 22:57:39.288655
cc6786bf-87ab-4a0e-8866-cde439c8d0e1	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	1c0bf792-8d5b-466a-acc5-83bbcf22e979	info	Application Processing	Your application LIC-2026-6641 has been processing.	service_request	d8622ca9-9b28-4548-a9be-fcf451fa25ab	f	2026-01-18 22:58:19.222991
b9c222ef-eff2-4f4b-ad3a-3b3202411f1f	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	1c0bf792-8d5b-466a-acc5-83bbcf22e979	info	Application Processing	Your application LIC-2026-8709 has been processing.	service_request	6de2cc90-d67b-413f-a4a0-df644e74d00b	f	2026-01-18 23:06:45.970844
ae01137f-032a-4cf2-a481-af5b5b52a299	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	bcc966f0-cf72-4b73-85ee-f1d1b8f196e4	info	Application Processing	Your application LIC-2026-1372 has been processing.	service_request	cd0419e9-5560-4105-ac03-f933a22063b9	f	2026-01-19 03:50:47.138557
8ea9691a-3fc8-4aea-96dc-d3a4b61487fd	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	1c0bf792-8d5b-466a-acc5-83bbcf22e979	error	Application Rejected	Your application LIC-2026-6572 has been rejected.	service_request	8a6e1251-4755-44f4-8d67-503250f7e063	f	2026-01-23 23:18:17.747173
7dd5f612-6312-4700-8562-d9fcde953219	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	1c0bf792-8d5b-466a-acc5-83bbcf22e979	info	Application Inspection	Your application LIC-2026-4193 has been inspection.	service_request	5b2364db-ca28-4f8b-a64b-a960c7131e8f	f	2026-01-24 01:06:52.011846
cc000f4f-3242-44b2-87d0-580dc76e4871	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	1c0bf792-8d5b-466a-acc5-83bbcf22e979	success	Application Approved	Your application LIC-2026-4193 has been approved.	service_request	5b2364db-ca28-4f8b-a64b-a960c7131e8f	f	2026-01-24 01:08:43.558556
144c1daf-e6b8-42aa-a2c5-72ea64144110	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	f40ff078-c74a-4688-9aea-d3f01d23dedd	info	Application Inspection	Your application LIC-2026-1461 has been inspection.	service_request	163cf2e6-8653-4d88-8daa-67c8c7bf20fd	f	2026-01-24 15:08:40.157534
d3abae47-b2bd-4bdd-a498-b1d82ed8d52e	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	f40ff078-c74a-4688-9aea-d3f01d23dedd	success	Application Approved	Your application LIC-2026-1461 has been approved.	service_request	163cf2e6-8653-4d88-8daa-67c8c7bf20fd	f	2026-01-24 15:09:14.702726
\.


--
-- Data for Name: otp_verifications; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.otp_verifications (id, identifier, code, type, expires_at, verified, created_at) FROM stdin;
\.


--
-- Data for Name: payment_allocations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.payment_allocations (allocation_id, council_id, payment_id, invoice_id, allocated_amount) FROM stdin;
\.


--
-- Data for Name: payments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.payments (payment_id, council_id, account_id, payment_ref, amount, currency, method, provider, status, external_reference, payment_details, paid_at, created_at) FROM stdin;
80e1872e-de17-4eca-a180-0d0052a30125	council-123	acc-123	REF-123	100.00	PGK	cash	\N	completed	\N	\N	2026-01-18 11:38:02.991	2026-01-18 21:38:03.124805
c2d33e03-cc41-485b-948a-6f1b085da840	council-123	acc-123	REF-123	100.00	PGK	cash	\N	completed	\N	\N	2026-01-18 11:39:41.926	2026-01-18 21:39:42.06455
10c0b9df-84e5-4ce3-9147-dac4b4b11c3c	council-123	acc-123	REF-123	100.00	PGK	cash	\N	completed	\N	\N	2026-01-18 11:41:58.704	2026-01-18 21:41:58.81929
f2cdb45e-3837-412d-92ef-2b34b8ca29a5	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	citizen-account-id	163cf2e6-8653-4d88-8daa-67c8c7bf20fd	500.00	PGK	cash	\N	completed	REF-7746200	{}	2026-01-18 11:44:41.067	2026-01-18 21:44:41.174445
cda478f3-2108-4222-97ce-34dbf7e34168	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	citizen-account-id	f89a1660-6f49-4b41-9b8e-72bf103f82fb	500.00	PGK	cash	\N	completed	NCDC-662733	{}	2026-01-22 08:15:53.928	2026-01-22 18:15:59.030342
a44e1af2-09a6-41de-9a9c-4cff070f92d2	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	citizen-account-id	f89a1660-6f49-4b41-9b8e-72bf103f82fb	500.00	PGK	cash	\N	completed	NCDC-662733	{}	2026-01-22 08:16:20.162	2026-01-22 18:16:20.958195
137b38fe-501e-4fd5-8935-5a76094b8841	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	citizen-account-id	f89a1660-6f49-4b41-9b8e-72bf103f82fb	500.00	PGK	cash	\N	completed	NCDC-6637248	{}	2026-01-22 08:28:23.388	2026-01-22 18:28:25.762523
60e40ec2-bb48-4365-8b72-5b16e79d7289	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	citizen-account-id	f89a1660-6f49-4b41-9b8e-72bf103f82fb	560.00	PGK	cash	\N	completed	rgbbbb	{}	2026-01-22 08:29:22.076	2026-01-22 18:29:22.422208
303ee43d-21eb-40ff-9b07-dc14b26ee91c	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	citizen-account-id	f89a1660-6f49-4b41-9b8e-72bf103f82fb	560.00	PGK	cash	\N	completed	rgbbbb	{}	2026-01-22 08:29:46.888	2026-01-22 18:29:47.480987
db67a9d6-fe63-4ba0-9c31-0192c830419e	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	citizen-account-id	f89a1660-6f49-4b41-9b8e-72bf103f82fb	150.00	PGK	cash	\N	completed	\N	\N	2026-01-22 11:35:59.515	2026-01-22 21:35:59.539109
\.


--
-- Data for Name: permissions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.permissions (permission_code, description) FROM stdin;
citizen:read	View citizen records
citizen:write	Create/update citizen records
business:read	View business records
business:write	Create/update business records
service:read	View service catalogue
service:write	Manage service catalogue
request:read	View service requests
request:write	Process service requests
request:approve	Approve service requests
inspection:read	View inspections
inspection:write	Conduct inspections
invoice:read	View invoices
invoice:write	Create/manage invoices
payment:read	View payments
payment:write	Record payments
licence:read	View licences
licence:write	Issue licences
enforcement:read	View enforcement cases
enforcement:write	Manage enforcement cases
audit:read	View audit logs
user:read	View users
user:write	Manage users
role:read	View roles
role:write	Manage roles
citizen:delete	Delete citizen records
citizen:export	Export citizen data
citizen:pii	Access personally identifiable information
business:delete	Delete business records
business:verify	Verify business registrations
business:export	Export business data
property:read	View property records
property:write	Create/update property records
property:delete	Delete property records
property:assess	Create/update rate assessments
request:reject	Reject requests
request:delete	Delete requests
licence:renew	Renew licences
licence:revoke	Revoke licences
licence:suspend	Suspend licences
inspection:schedule	Schedule inspections
inspection:complete	Complete inspections
payment:refund	Process refunds
payment:delete	Delete/void payments
payment:export	Export payment records
invoice:delete	Delete/void invoices
invoice:waive	Waive fees/charges
fee:read	View fee schedules
fee:write	Manage fee schedules
enforcement:assign	Assign cases to officers
enforcement:close	Close cases
complaint:read	View complaints
complaint:write	Create/update complaints
complaint:assign	Assign complaints
notice:read	View notices
notice:write	Issue notices
notice:approve	Approve notices
service:activate	Activate/deactivate services
workflow:read	View workflows
workflow:write	Manage workflows
user:delete	Delete users
user:activate	Activate/deactivate users
role:assign	Assign roles to users
permission:read	View permissions
permission:assign	Assign permissions to roles
audit:export	Export audit logs
config:read	View configuration
config:write	Modify configuration
breakglass:use	Use break-glass emergency access
breakglass:review	Review break-glass access logs
breakglass:approve	Approve break-glass requests
report:read	View reports
report:create	Create custom reports
report:export	Export reports
dashboard:read	View dashboards
analytics:read	Access analytics
gis:read	View GIS maps and layers
gis:write	Edit GIS data
gis:export	Export GIS data
\.


--
-- Data for Name: properties; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.properties (property_id, council_id, parcel_id, section, lot, allotment, suburb, district, land_type, title_number, owner_name, owner_type, land_area, zoning, rateable_value, coordinates, status, created_at) FROM stdin;
7cfe30ce-cf33-4391-9438-e34b706025c2	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	POM-SEC32-LOT5	32	5	\N	Gordons	Port Moresby	state_lease	VOL-45-FOL-789	Papindo Trading Limited	business	1,200 sqm	Commercial	450000.00	-9.478,147.155	active	2026-01-14 06:40:16.27938
8dddfb07-8e25-4952-a5f4-02d232b1e802	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	POM-SEC14-LOT22	14	22	\N	Waigani	Port Moresby	state_lease	VOL-14-FOL-222	City Pharmacy PNG	business	800 sqm	Commercial	380000.00	-9.445,147.175	active	2026-01-14 06:40:16.27938
4f23e3f0-7d8f-4eaf-8b9d-17ff727f1c59	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	POM-SEC45-LOT12	45	12	\N	Boroko	Port Moresby	state_lease	VOL-45-FOL-012	Michael Kila	individual	600 sqm	Residential	250000.00	-9.462,147.165	active	2026-01-14 06:40:16.27938
dee868ee-3457-4f45-8020-7c4656aea8da	90c57094-13e2-42f1-be1f-1a1b50595f70	POM-SEC32-LOT5	32	5	\N	Gordons	Port Moresby	state_lease	VOL-45-FOL-789	Papindo Trading Limited	business	1,200 sqm	Commercial	450000.00	-9.478,147.155	active	2026-01-19 13:30:22.658661
964cc1b4-0749-4751-ad5f-93c8f18df186	90c57094-13e2-42f1-be1f-1a1b50595f70	POM-SEC14-LOT22	14	22	\N	Waigani	Port Moresby	state_lease	VOL-14-FOL-222	City Pharmacy PNG	business	800 sqm	Commercial	380000.00	-9.445,147.175	active	2026-01-19 13:30:22.658661
c965e55d-d385-4eb7-b6c2-1bd5d08fefbb	90c57094-13e2-42f1-be1f-1a1b50595f70	POM-SEC45-LOT12	45	12	\N	Boroko	Port Moresby	state_lease	VOL-45-FOL-012	Michael Kila	individual	600 sqm	Residential	250000.00	-9.462,147.165	active	2026-01-19 13:30:22.658661
f0a45e54-a2cc-40a5-8683-16be70a816e6	3c4d4a9f-92a7-4dd2-82fb-ceff90c57094	POM-SEC32-LOT5	32	5	\N	Gordons	Port Moresby	state_lease	VOL-45-FOL-789	Papindo Trading Limited	business	1,200 sqm	Commercial	450000.00	-9.478,147.155	active	2026-01-19 04:04:14.557857
126b53b9-74f2-4e41-81f4-bfd8f128b10a	3c4d4a9f-92a7-4dd2-82fb-ceff90c57094	POM-SEC14-LOT22	14	22	\N	Waigani	Port Moresby	state_lease	VOL-14-FOL-222	City Pharmacy PNG	business	800 sqm	Commercial	380000.00	-9.445,147.175	active	2026-01-19 04:04:14.557857
e2fc2d75-e309-415f-a604-a0c07562b3c8	3c4d4a9f-92a7-4dd2-82fb-ceff90c57094	POM-SEC45-LOT12	45	12	\N	Boroko	Port Moresby	state_lease	VOL-45-FOL-012	Michael Kila	individual	600 sqm	Residential	250000.00	-9.462,147.165	active	2026-01-19 04:04:14.557857
\.


--
-- Data for Name: purchase_order_lines; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.purchase_order_lines (line_id, order_id, description, quantity, unit_price, line_total) FROM stdin;
\.


--
-- Data for Name: purchase_orders; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.purchase_orders (order_id, council_id, vendor_id, requestor_id, order_date, expected_date, status, total_amount, currency, description, created_at) FROM stdin;
\.


--
-- Data for Name: rate_assessments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.rate_assessments (assessment_id, council_id, property_id, assessment_year, rateable_value, rate_amount, status, created_at) FROM stdin;
\.


--
-- Data for Name: role_permissions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.role_permissions (role_id, permission_code) FROM stdin;
c5276f39-ddbe-4517-8a59-e91d1c841494	citizen:read
c5276f39-ddbe-4517-8a59-e91d1c841494	citizen:write
c5276f39-ddbe-4517-8a59-e91d1c841494	business:read
c5276f39-ddbe-4517-8a59-e91d1c841494	business:write
c5276f39-ddbe-4517-8a59-e91d1c841494	service:read
c5276f39-ddbe-4517-8a59-e91d1c841494	service:write
c5276f39-ddbe-4517-8a59-e91d1c841494	request:read
c5276f39-ddbe-4517-8a59-e91d1c841494	request:write
c5276f39-ddbe-4517-8a59-e91d1c841494	request:approve
c5276f39-ddbe-4517-8a59-e91d1c841494	inspection:read
c5276f39-ddbe-4517-8a59-e91d1c841494	inspection:write
c5276f39-ddbe-4517-8a59-e91d1c841494	invoice:read
c5276f39-ddbe-4517-8a59-e91d1c841494	invoice:write
c5276f39-ddbe-4517-8a59-e91d1c841494	payment:read
c5276f39-ddbe-4517-8a59-e91d1c841494	payment:write
c5276f39-ddbe-4517-8a59-e91d1c841494	licence:read
c5276f39-ddbe-4517-8a59-e91d1c841494	licence:write
c5276f39-ddbe-4517-8a59-e91d1c841494	enforcement:read
c5276f39-ddbe-4517-8a59-e91d1c841494	enforcement:write
c5276f39-ddbe-4517-8a59-e91d1c841494	audit:read
c5276f39-ddbe-4517-8a59-e91d1c841494	user:read
c5276f39-ddbe-4517-8a59-e91d1c841494	user:write
c5276f39-ddbe-4517-8a59-e91d1c841494	role:read
c5276f39-ddbe-4517-8a59-e91d1c841494	role:write
bff2fab3-7615-46cf-adb8-d45130497241	citizen:read
bff2fab3-7615-46cf-adb8-d45130497241	citizen:write
bff2fab3-7615-46cf-adb8-d45130497241	business:read
bff2fab3-7615-46cf-adb8-d45130497241	business:write
bff2fab3-7615-46cf-adb8-d45130497241	service:read
bff2fab3-7615-46cf-adb8-d45130497241	service:write
bff2fab3-7615-46cf-adb8-d45130497241	request:read
bff2fab3-7615-46cf-adb8-d45130497241	request:write
bff2fab3-7615-46cf-adb8-d45130497241	request:approve
bff2fab3-7615-46cf-adb8-d45130497241	inspection:read
bff2fab3-7615-46cf-adb8-d45130497241	inspection:write
bff2fab3-7615-46cf-adb8-d45130497241	invoice:read
bff2fab3-7615-46cf-adb8-d45130497241	invoice:write
bff2fab3-7615-46cf-adb8-d45130497241	payment:read
bff2fab3-7615-46cf-adb8-d45130497241	payment:write
bff2fab3-7615-46cf-adb8-d45130497241	licence:read
bff2fab3-7615-46cf-adb8-d45130497241	licence:write
bff2fab3-7615-46cf-adb8-d45130497241	enforcement:read
bff2fab3-7615-46cf-adb8-d45130497241	enforcement:write
bff2fab3-7615-46cf-adb8-d45130497241	audit:read
bff2fab3-7615-46cf-adb8-d45130497241	user:read
bff2fab3-7615-46cf-adb8-d45130497241	user:write
bff2fab3-7615-46cf-adb8-d45130497241	role:read
bff2fab3-7615-46cf-adb8-d45130497241	role:write
c6d113de-dcb6-49aa-97c0-f1015ab30909	citizen:read
c6d113de-dcb6-49aa-97c0-f1015ab30909	citizen:write
c6d113de-dcb6-49aa-97c0-f1015ab30909	business:read
c6d113de-dcb6-49aa-97c0-f1015ab30909	business:write
c6d113de-dcb6-49aa-97c0-f1015ab30909	service:read
c6d113de-dcb6-49aa-97c0-f1015ab30909	service:write
c6d113de-dcb6-49aa-97c0-f1015ab30909	request:read
c6d113de-dcb6-49aa-97c0-f1015ab30909	request:write
c6d113de-dcb6-49aa-97c0-f1015ab30909	request:approve
c6d113de-dcb6-49aa-97c0-f1015ab30909	inspection:read
c6d113de-dcb6-49aa-97c0-f1015ab30909	inspection:write
c6d113de-dcb6-49aa-97c0-f1015ab30909	invoice:read
c6d113de-dcb6-49aa-97c0-f1015ab30909	invoice:write
c6d113de-dcb6-49aa-97c0-f1015ab30909	payment:read
c6d113de-dcb6-49aa-97c0-f1015ab30909	payment:write
c6d113de-dcb6-49aa-97c0-f1015ab30909	licence:read
c6d113de-dcb6-49aa-97c0-f1015ab30909	licence:write
c6d113de-dcb6-49aa-97c0-f1015ab30909	enforcement:read
c6d113de-dcb6-49aa-97c0-f1015ab30909	enforcement:write
c6d113de-dcb6-49aa-97c0-f1015ab30909	audit:read
c6d113de-dcb6-49aa-97c0-f1015ab30909	user:read
c6d113de-dcb6-49aa-97c0-f1015ab30909	user:write
c6d113de-dcb6-49aa-97c0-f1015ab30909	role:read
c6d113de-dcb6-49aa-97c0-f1015ab30909	role:write
\.


--
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.roles (role_id, council_id, name, scope) FROM stdin;
c5276f39-ddbe-4517-8a59-e91d1c841494	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	Administrator	council
3b76918d-b4c9-4dc7-9e8d-5657c44b7ea4	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	Manager	unit
316751dd-c84d-43fc-8810-af4e7c1adcf4	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	Licensing Officer	unit
11f352dd-303e-4528-b108-80f9fd15e373	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	Inspector	ward
c6d113de-dcb6-49aa-97c0-f1015ab30909	90c57094-13e2-42f1-be1f-1a1b50595f70	Administrator	council
37faddc4-f6e1-4e50-8eb5-3086a711f25e	90c57094-13e2-42f1-be1f-1a1b50595f70	Manager	unit
2ed4f922-893d-4ce1-92a1-f1e7611b3809	90c57094-13e2-42f1-be1f-1a1b50595f70	Licensing Officer	unit
b337e932-013e-4e36-aa41-68646ddbb6ff	90c57094-13e2-42f1-be1f-1a1b50595f70	Inspector	ward
bff2fab3-7615-46cf-adb8-d45130497241	3c4d4a9f-92a7-4dd2-82fb-ceff90c57094	Administrator	council
bcfed680-ab75-499b-bbb1-09f9c74764f7	3c4d4a9f-92a7-4dd2-82fb-ceff90c57094	Manager	unit
64ec116a-ba28-40d5-b9b8-967b5af7df46	3c4d4a9f-92a7-4dd2-82fb-ceff90c57094	Licensing Officer	unit
3b7c4175-7ccf-483b-956f-cb5a5286a3f2	3c4d4a9f-92a7-4dd2-82fb-ceff90c57094	Inspector	ward
\.


--
-- Data for Name: service_requests; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.service_requests (request_id, council_id, service_id, requester_type, requester_id, status, channel, form_data, submitted_at, created_at, processing_data, request_ref, reviewed_at, inspected_at, approved_at) FROM stdin;
f89a1660-6f49-4b41-9b8e-72bf103f82fb	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	a50465f6-c249-4fa2-a399-483bc005dbd1	business	9503c736-dfe0-4973-9cf8-129383661614	completed	portal	{"foo": "bar", "test": "data"}	2026-01-17 01:58:29.764	2026-01-17 11:58:29.767375	\N	\N	2026-01-17 01:58:29.764	2026-01-17 01:58:29.764	2026-01-17 01:58:29.764
cce4af46-d401-445f-a59e-d9371f0d9265	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	a50465f6-c249-4fa2-a399-483bc005dbd1	business	3f8febd7-1aae-45b1-a512-2013c5d697f2	approved	portal	{"managerName": "Toa Pamare", "tradingName": "Hamney Enterprises", "applicantName": "Lawrence Mukombo", "radioLicenseNo": "", "premisesAddress": {"lot": "65", "suburb": "Town", "section": "24"}, "businessActivity": "Electronics and related items"}	2026-01-17 02:03:07.694	2026-01-17 12:03:07.697308	\N	\N	2026-01-17 02:03:07.694	2026-01-17 02:03:07.694	2026-01-17 02:03:07.694
d8622ca9-9b28-4548-a9be-fcf451fa25ab	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	a50465f6-c249-4fa2-a399-483bc005dbd1	business	1c0bf792-8d5b-466a-acc5-83bbcf22e979	completed	portal	{"floorSpace": "28", "applicantName": "Lawrence Mukombo", "customerGender": "both", "hotWaterSupply": "From water heater", "numberOfChairs": 5, "wavingMachines": 1, "numberOfBarbers": 3, "premisesAddress": {"lot": "31", "detail": "", "suburb": "Paga Hill", "section": "83"}, "ladiesHairDryers": 2, "numberOfWashBasins": 2}	2026-01-17 08:25:32.476	2026-01-17 18:25:32.503648	{}	LIC-2026-6641	2026-01-17 08:25:32.476	2026-01-17 08:25:32.476	2026-01-17 08:25:32.476
8a6e1251-4755-44f4-8d67-503250f7e063	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	cea92864-045e-4734-9373-e420af8682ae	business	1c0bf792-8d5b-466a-acc5-83bbcf22e979	rejected	portal	{"knownAs": "Lamana GC", "clubName": "Lamana", "attachments": {"namesList": {}, "resolution": {}, "constitution": {}}, "tradingHours": {"to": "04:00", "from": "19:00"}, "applicantName": "Simon Wong", "officeUseOnly": {"licenseProcessing": {"date": "", "licenseNo": "", "meetingNo": "", "licenseFee": "", "dateOfPayment": "", "officialRecNo": "", "approvedRejected": "Approved"}, "applicationProcessing": {"adminFee": "", "dateOfPayment": "", "officialRecNo": ""}}, "numberOfMembers": 170, "premisesSituatedAt": "Waigani Close"}	2026-01-17 08:41:37.465	2026-01-17 18:41:37.478647	{"remarks": "The documents are not complete", "licenseType": "GENERAL BUSINESS", "licenseTypeId": "f948d0d4-f28b-4163-b3c6-f907a6c5d840"}	LIC-2026-6572	\N	\N	\N
48967986-6b8b-430f-960f-056a7620b906	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	a50465f6-c249-4fa2-a399-483bc005dbd1	business	1c0bf792-8d5b-466a-acc5-83bbcf22e979	rejected	portal	{"managerName": "John Kamora", "tradingName": "Hamney Enterprises", "applicantName": "Francis Sakala", "radioLicenseNo": "", "premisesAddress": {"lot": "37", "suburb": "Boroko", "section": "04"}, "businessActivity": "Supplying of Electronics equipment and related items"}	2026-01-17 03:40:41.844	2026-01-17 13:40:41.84991	{"remarks": "Upload all relevant documents"}	LIC-2026-7194	\N	\N	\N
6de2cc90-d67b-413f-a4a0-df644e74d00b	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	a50465f6-c249-4fa2-a399-483bc005dbd1	business	1c0bf792-8d5b-466a-acc5-83bbcf22e979	processing	portal	{}	2026-01-17 08:05:46.987	2026-01-17 18:05:46.992286	{}	LIC-2026-8709	\N	\N	\N
2263b419-d125-4e00-ad7e-18b365b3af8e	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	a50465f6-c249-4fa2-a399-483bc005dbd1	business	1c0bf792-8d5b-466a-acc5-83bbcf22e979	rejected	portal	{}	2026-01-17 07:51:44.848	2026-01-17 17:51:44.851307	\N	LIC-2026-2928	\N	\N	\N
a3308191-165c-4487-8036-25c2316b08d7	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	cea92864-045e-4734-9373-e420af8682ae	business	3f8febd7-1aae-45b1-a512-2013c5d697f2	submitted	portal	{"attachments": {"landTitle": {"fileName": "PACKET_Checklist_New_page_1.png", "fileSize": 250821, "uploaded": false}, "companyExtract": {"fileName": "publicantavern_limited_hotel_page_1.png", "fileSize": 277141, "uploaded": false}, "landTaxReceipt": {"fileName": "Limited_Hotel_Checklist_New_page_1.png", "fileSize": 365950, "uploaded": false}, "previousLicense": {"fileName": "GRADE 4 CBC SCIENCE LESSON PLAN CALL MR KABASO JOSEPH ON 0974382239.docx", "fileSize": 35630, "uploaded": false}, "businessNameRegistration": {"fileName": "Application_Checklist_New__For_Pharmacy_page_1.png", "fileSize": 297223, "uploaded": false}, "physicalPlanningApproval": {"fileName": "barbers_shop_licence_page_1.png", "fileSize": 249447, "uploaded": false}, "buildingAuthorityApproval": {"fileName": "second-hand-dealer.pdf", "fileSize": 135286, "uploaded": false}, "certificateOfIncorporation": {"fileName": "publicantavern_limited_hotel_page_1.png", "fileSize": 277141, "uploaded": false}, "foreignEnterpriseCertificate": {"fileName": "PACKET_Checklist_New_page_1.png", "fileSize": 250821, "uploaded": false}}, "managerName": "Lawrence Mukombo", "tradingName": "Hanmey Enterprises", "applicantName": "Hamney Enterprises", "applicationType": "new", "premisesAddress": {"lot": "", "block": "", "detail": "Independence Boulevard", "suburb": "Town", "section": "", "village": "Ramu"}, "businessActivity": "Fuels and Petroleum Products"}	2026-01-22 18:17:25.534	2026-01-23 04:17:25.551858	\N	LIC-2026-5598	\N	\N	\N
cd0419e9-5560-4105-ac03-f933a22063b9	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	a50465f6-c249-4fa2-a399-483bc005dbd1	business	bcc966f0-cf72-4b73-85ee-f1d1b8f196e4	processing	portal	{"attachments": {"landTitle": {"fileName": "barbers-shop-licence.pdf", "fileSize": 139508, "uploaded": false}, "companyExtract": {"fileName": "Booth_Checklist_New_page_1.png", "fileSize": 284344, "uploaded": false}, "landTaxReceipt": {"fileName": "Application Checklist (Trade) - New-General Business.pdf", "fileSize": 90220, "uploaded": false}, "previousLicense": {"fileName": "Application_Checklist_New__For_Food_Establshments_page_1.png", "fileSize": 311201, "uploaded": false}, "businessNameRegistration": {"fileName": "second-hand-dealer (1).pdf", "fileSize": 135286, "uploaded": false}, "physicalPlanningApproval": {"fileName": "application_checklist_new_-_for_electronics_shop.docx", "fileSize": 19231, "uploaded": false}, "buildingAuthorityApproval": {"fileName": "restaurant.pdf", "fileSize": 107023, "uploaded": false}, "certificateOfIncorporation": {"fileName": "publicantavern-limited-hotel.pdf", "fileSize": 301149, "uploaded": false}, "foreignEnterpriseCertificate": {"fileName": "Publican_Checklist_New_page_1.png", "fileSize": 348623, "uploaded": false}}, "managerName": "John Paru", "tradingName": "Swan Swift", "applicantName": "George Swan", "applicationType": "new", "premisesAddress": {"lot": "56", "detail": "Napa-Napa Rd", "suburb": "Baruni", "section": "15"}, "businessActivity": "General Mechandise"}	2026-01-17 21:20:55.076	2026-01-18 07:20:55.078545	{}	LIC-2026-1372	\N	\N	\N
c206729f-0afa-4157-88d6-9c90ff876107	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	a50465f6-c249-4fa2-a399-483bc005dbd1	business	d3329bb0-5fa5-42ab-99a8-af5dc0398fe1	processing	portal	{"attachments": {"landTitle": {"fileName": "Application_Checklist_New_For_Barber_Shop_License_page_1.png", "fileSize": 284894, "uploaded": false}, "companyExtract": {"fileName": "Application_Checklist_Trade___New_General_Business_page_1.png", "fileSize": 287832, "uploaded": false}, "landTaxReceipt": {"fileName": "application_checklist_new_-_for_electronics_shop.docx", "fileSize": 19231, "uploaded": false}, "previousLicense": {"fileName": "trade_license_application_form_page_1.png", "fileSize": 320005, "uploaded": false}, "physicalPlanningApproval": {"fileName": "dinner-special-permit-license1.pdf", "fileSize": 415798, "uploaded": false}, "buildingAuthorityApproval": {"fileName": "second-hand-dealer (1).pdf", "fileSize": 135286, "uploaded": false}, "certificateOfIncorporation": {"fileName": "liquor-club-license.pdf", "fileSize": 216364, "uploaded": false}, "foreignEnterpriseCertificate": {"fileName": "Application_Checklist_New_For_Barber_Shop_License_page_1.png", "fileSize": 284894, "uploaded": false}}, "managerName": "Patrick Martin", "tradingName": "Goat Enterprises", "applicantName": "Goat Enterprises Ltd", "applicationType": "new", "premisesAddress": {"lot": "98", "detail": "56 Gerehu Drive", "suburb": "Gerehu", "section": "76"}, "businessActivity": "General Mechandise"}	2026-01-18 06:06:15.764	2026-01-18 16:06:15.767121	{"licenseType": "GENERAL BUSINESS", "licenseTypeId": "f948d0d4-f28b-4163-b3c6-f907a6c5d840"}	LIC-2026-8594	\N	\N	\N
5b2364db-ca28-4f8b-a64b-a960c7131e8f	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	a50465f6-c249-4fa2-a399-483bc005dbd1	business	1c0bf792-8d5b-466a-acc5-83bbcf22e979	approved	portal	{"attachments": {"landTitle": {"fileName": "barbers-shop-licence.pdf", "fileSize": 139508, "uploaded": false}, "companyExtract": {"fileName": "trade-license-application-form.pdf", "fileSize": 129386, "uploaded": false}, "landTaxReceipt": {"fileName": "place_of_entertainment_page_1.jpg", "fileSize": 301838, "uploaded": false}, "previousLicense": {"fileName": "Restaurant_Checklist_NEW_page_1.png", "fileSize": 370524, "uploaded": false}, "businessNameRegistration": {"fileName": "publicantavern-limited-hotel.pdf", "fileSize": 301149, "uploaded": false}, "physicalPlanningApproval": {"fileName": "Canteen_Checklist_New_page_1.png", "fileSize": 356899, "uploaded": false}, "buildingAuthorityApproval": {"fileName": "Store_KeepersChecklist_New_page_1.png", "fileSize": 348075, "uploaded": false}, "certificateOfIncorporation": {"fileName": "trade-license-application-form.pdf", "fileSize": 129386, "uploaded": false}, "foreignEnterpriseCertificate": {"fileName": "Restaurant_Checklist_NEW_page_1.png", "fileSize": 370524, "uploaded": false}}, "managerName": "", "tradingName": "Me and You General Dealers", "applicantName": "Francis Sakala", "applicationType": "new", "premisesAddress": {"lot": "36", "detail": "3 Mile trading area", "suburb": "3 Mile", "section": "23"}, "businessActivity": "General groceries"}	2026-01-17 10:03:18.254	2026-01-17 20:03:18.259933	{}	LIC-2026-4193	2026-01-17 10:03:18.254	2026-01-26 00:00:00	2026-01-17 10:03:18.254
11e0f60a-7447-4faf-a00e-94e8b07b8751	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	cea92864-045e-4734-9373-e420af8682ae	business	c994ada8-ac06-4b71-9a23-b61c4f1364ce	submitted	web	{"attachments": {"certificateOfIncorporation": {"fileName": "second_hand_dealer_1_page_1.png", "fileSize": 233041, "uploaded": false}}, "managerName": "", "tradingName": "City Pharmacy Waigani", "applicantName": "City Pharmacy PNG", "licenseTypeId": "38eec32b-ea1f-4a60-8244-a635552b9685", "applicationType": "new", "premisesAddress": {"lot": "", "block": "", "detail": "Section 14, Lot 22, Waigani", "suburb": "Waigani", "section": "", "village": ""}, "businessActivity": "Canteen services"}	2026-01-23 20:18:53.959	2026-01-24 06:18:53.963479	\N	LIC-2026-5693	\N	\N	\N
ad037f22-82cd-45e0-9378-4e2d845b37c1	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	cea92864-045e-4734-9373-e420af8682ae	business	c994ada8-ac06-4b71-9a23-b61c4f1364ce	submitted	web	{"attachments": {"certificateOfIncorporation": {"fileName": "liquor_club_license_page_1.png", "fileSize": 278207, "uploaded": false}}, "managerName": "", "tradingName": "City Pharmacy Waigani", "applicantName": "City Pharmacy PNG", "licenseTypeId": "8b20d5fd-3890-453a-88f1-5f39a3ba8356", "applicationType": "new", "premisesAddress": {"lot": "", "block": "", "detail": "Section 14, Lot 22, Waigani", "suburb": "Waigani", "section": "", "village": ""}, "businessActivity": "wergteehdty"}	2026-01-23 21:01:27.806	2026-01-24 07:01:27.811861	\N	LIC-2026-5483	\N	\N	\N
163cf2e6-8653-4d88-8daa-67c8c7bf20fd	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	a50465f6-c249-4fa2-a399-483bc005dbd1	business	f40ff078-c74a-4688-9aea-d3f01d23dedd	completed	portal	{"attachments": {"landTitle": {"fileName": "dinner_special_permit_license1_page_1.png", "fileSize": 223180, "uploaded": false}, "companyExtract": {"fileName": "BOTTLE_SHOP_Checklist_New_page_1.png", "fileSize": 323569, "uploaded": false}, "landTaxReceipt": {"fileName": "Application_Checklist_Trade___New_General_Business_page_1.png", "fileSize": 287832, "uploaded": false}, "previousLicense": {"fileName": "Application_Checklist_New__For_Second_Hand_Used_Clothing_page_1.png", "fileSize": 310736, "uploaded": false}, "businessNameRegistration": {"fileName": "Application_Checklist_New__For_Fuel_Station_page_1.png", "fileSize": 318141, "uploaded": false}, "physicalPlanningApproval": {"fileName": "manufacturer_page_1.jpg", "fileSize": 327246, "uploaded": false}, "buildingAuthorityApproval": {"fileName": "Store_KeepersChecklist_New_page_1.png", "fileSize": 348075, "uploaded": false}, "certificateOfIncorporation": {"fileName": "Canteen_Checklist_New_page_1.png", "fileSize": 356899, "uploaded": false}, "foreignEnterpriseCertificate": {"fileName": "Canteen_Checklist_New_page_1.png", "fileSize": 356899, "uploaded": false}}, "managerName": "Mr Paul Teroa", "tradingName": "NCDC", "applicantName": "NCDC", "applicationType": "new", "premisesAddress": {"lot": "76", "detail": "Plot 235546 Waigani", "suburb": "Waigani", "section": "98"}, "businessActivity": "bhfguhtrgrt"}	2026-01-18 06:50:49.413	2026-01-18 16:50:49.415459	{}	LIC-2026-1461	2026-01-24 05:08:40.134	2026-01-24 05:09:14.684	2026-01-24 05:09:14.684
\.


--
-- Data for Name: services; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.services (service_id, council_id, code, name, category, description, requires_inspection, requires_approval, active, created_at) FROM stdin;
add0fd87-59af-4466-a220-c1e9af227be1	3c4d4a9f-92a7-4dd2-82fb-ceff90c57094	LIC-TRADING	Trading Licence	licensing	General trading licence for businesses operating within the city	t	t	t	2026-01-19 04:04:14.540487
b6a987de-31c6-4013-a4cf-4d47e105a132	3c4d4a9f-92a7-4dd2-82fb-ceff90c57094	LIC-LIQUOR	Liquor Licence	licensing	Licence to sell or serve alcohol	t	t	t	2026-01-19 04:04:14.546119
71fe0b01-d2f8-4897-9dab-36b4fc396193	3c4d4a9f-92a7-4dd2-82fb-ceff90c57094	COMP-GENERAL	General Complaint	complaints	Lodge a general complaint	f	f	t	2026-01-19 04:04:14.546119
41dee462-2357-49c0-8ded-a87cf3eb69b5	3c4d4a9f-92a7-4dd2-82fb-ceff90c57094	LIC-SIGNAGE	Signage Permit	Business	Permit for advertising signage	f	t	t	2026-01-19 04:04:14.546119
cea92864-045e-4734-9373-e420af8682ae	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	LIC-TRADING	Trading Licence	licensing	General trading licence for businesses operating within the city	t	t	t	2026-01-23 04:11:52.394535
7da398b7-41b8-4d01-b662-d977a9c7a3f0	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	LIC-LIQUOR	Liquor Licence	licensing	Licence to sell or serve alcohol	t	t	t	2026-01-23 04:11:52.457548
adf0503a-b549-44b2-b2ad-6bc132f7e868	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	COMP-GENERAL	General Complaint	complaints	Lodge a general complaint	f	f	t	2026-01-23 04:11:52.467313
2450739e-72be-4186-a319-e2ff972357e2	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	LIC-SIGNAGE	Signage Permit	Business	Permit for advertising signage	f	t	t	2026-01-23 04:11:52.477957
\.


--
-- Data for Name: special_requirements; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.special_requirements (id, license_type_id, requirement_name, issuing_authority, description, created_at) FROM stdin;
7a5c1147-574b-4e62-8eda-43b67a2af901	3039e203-0714-4d5c-86dd-9acd1e99081f	Radio communication Apparatus License	National Information and Technology Authority (NICTA)	For businesses using radio communication equipment	2026-01-20 09:41:17.799684
79d8bab7-6f05-4a02-ad3c-6531a40337f3	824aeb14-49d0-4e19-a5a5-dcd81f6a414d	Pharmaceutical License	NDoH-Pharmacy Board	Required for pharmacy operations	2026-01-20 09:41:17.803401
52b56e52-741c-458a-b285-41f1abcf72fe	97a10043-0a7a-4530-9a3b-f8a5684e6559	Certificate of Fumigation	National Department of Health (NDoH)	Required for second-hand clothing	2026-01-20 09:41:17.804847
ef5351b4-7275-4a28-98d2-51328c13c603	3630246a-9c75-45c0-b429-eca768e8ba03	Inflammable & Dangerous Goods License/certificate	Labour Department	Required for fuel-related businesses	2026-01-20 09:41:17.806215
e863832c-f86a-4f97-8895-db9558dafeb3	6c8ca3d6-01c9-42d0-abbe-69fc1d3645aa	Inflammable & Dangerous Goods License/certificate	Labour Department	Required for fuel stations	2026-01-20 09:41:17.807535
01c68736-bb3c-49a1-804e-7fa0df5f6f0c	ed80198f-9d2d-49be-82f1-8d13f3b91e03	Factory/Manufacturer License	Labour Department	Required for manufacturing operations	2026-01-20 09:41:17.808851
8da476e8-2919-43e5-9ab3-e581cbbc043c	8b20d5fd-3890-453a-88f1-5f39a3ba8356	Factory/Manufacturer License	Labour Department	Required for manufacturing operations	2026-01-20 09:41:17.810103
ec88e712-d326-4e21-a9ec-8bfbac8d825a	8b20d5fd-3890-453a-88f1-5f39a3ba8356	Food Safety Management System (HACCP)	Applicant	Required for food-related businesses	2026-01-20 09:41:17.811822
23f5f3a8-7b1b-49b3-bae7-18d5565a1529	9f564cc0-65c8-4277-9d3a-5585fb57dc3b	Food Safety Management System (HACCP)	Applicant	Required for food-related businesses	2026-01-20 09:41:17.81398
9c29e01e-9fd0-47ff-b75a-f43eeeb7a1b3	759ee9bf-5fcc-4300-a1f9-bea1158a08a2	Food Safety Management System (HACCP)	Applicant	Required for food-related businesses	2026-01-20 09:41:17.816045
15dc90a3-9a65-4bb1-b766-a90ba6fc83f0	feb731e5-e68a-4b8d-8551-cb75cab71492	Food Safety Management System (HACCP)	Applicant	Required for food-related businesses	2026-01-20 09:41:17.817951
7ba22877-8f34-472d-8efb-4f7a263192b9	38eec32b-ea1f-4a60-8244-a635552b9685	Food Safety Management System (HACCP)	Applicant	Required for food-related businesses	2026-01-20 09:41:17.819738
1d6f3198-308a-49aa-8242-78d341349417	1a6d6c6a-382e-48e5-aac0-c63a4152ddd0	Food Safety Management System (HACCP)	Applicant	Required for food-related businesses	2026-01-20 09:41:17.821515
929c03fb-d46d-4d76-a32a-336ec7bf583f	926eb276-15e4-4dbd-b397-0520ba13f387	Motor Car Dealers License	Land Transport Board	Required for vehicle dealerships	2026-01-20 09:41:17.823518
970ea8d7-f1ec-4e66-8a85-e747215b0a4c	582f971b-f5c1-481d-be88-13c68df2628d	Certified Sea Going Vessel	National Maritime Safety Authority	Required for Packet liquor license	2026-01-20 09:41:17.825507
e92774d8-0a7b-4955-bf27-55ac83db9686	582f971b-f5c1-481d-be88-13c68df2628d	Certified Overseas Ship	National Maritime Safety Authority	Required for Packet liquor license	2026-01-20 09:41:17.827691
\.


--
-- Data for Name: stalls; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.stalls (stall_id, council_id, market_id, stall_no, category, size, daily_rate, monthly_rate, status, current_tenant_id, created_at) FROM stdin;
b57d54f5-08d8-4ae5-8a2e-54274ba04539	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	aae7fb01-be08-416b-bfc9-c7a4cbea9c22	GM-A001	produce	3x3m	20.00	400.00	available	\N	2026-01-14 06:40:16.289663
e345b9bf-f902-44d3-aed1-02cdb69343c0	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	aae7fb01-be08-416b-bfc9-c7a4cbea9c22	GM-A002	produce	3x3m	20.00	400.00	occupied	\N	2026-01-14 06:40:16.289663
85ea7ae3-7543-4c43-a877-6cf723ca06dc	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	aae7fb01-be08-416b-bfc9-c7a4cbea9c22	GM-B001	crafts	4x4m	30.00	600.00	available	\N	2026-01-14 06:40:16.289663
acbcca09-3505-49e0-91ae-62cda471d9b0	f2739382-95a8-4197-ace0-bd1bcc5c1a11	f306ff25-5b59-4361-94b0-b3039bfb809e	GM-A001	produce	3x3m	20.00	400.00	available	\N	2026-01-19 04:04:14.575818
e9fc2c20-0518-4450-a2e9-bdd7d3c71129	f2739382-95a8-4197-ace0-bd1bcc5c1a11	f306ff25-5b59-4361-94b0-b3039bfb809e	GM-A002	produce	3x3m	20.00	400.00	occupied	\N	2026-01-19 04:04:14.575818
b6fd4904-c0dd-44b2-87b3-3199dffe654a	f2739382-95a8-4197-ace0-bd1bcc5c1a11	f306ff25-5b59-4361-94b0-b3039bfb809e	GM-B001	crafts	4x4m	30.00	600.00	available	\N	2026-01-19 04:04:14.575818
f73904e6-7a17-4726-ba44-445a6f8ea86b	90c57094-13e2-42f1-be1f-1a1b50595f70	c1b8988e-b419-4447-adc0-e46c72e3c55d	GM-A001	produce	3x3m	20.00	400.00	available	\N	2026-01-19 13:30:22.670738
f904e576-bdb4-403d-98df-872792dba0bb	90c57094-13e2-42f1-be1f-1a1b50595f70	c1b8988e-b419-4447-adc0-e46c72e3c55d	GM-A002	produce	3x3m	20.00	400.00	occupied	\N	2026-01-19 13:30:22.670738
0179f181-9cb4-45aa-a304-66f6d9f68519	90c57094-13e2-42f1-be1f-1a1b50595f70	c1b8988e-b419-4447-adc0-e46c72e3c55d	GM-B001	crafts	4x4m	30.00	600.00	available	\N	2026-01-19 13:30:22.670738
\.


--
-- Data for Name: tenant_config; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tenant_config (config_id, council_id, council_name, short_name, logo_url, favicon_url, tagline, primary_color, secondary_color, accent_color, background_root_color, background_default_color, background_higher_color, foreground_default_color, foreground_dimmer_color, outline_color, primary_foreground, positive_color, warning_color, negative_color, sidebar_background, sidebar_foreground, header_background, header_foreground, card_background, border_radius, button_radius, card_radius, input_radius, font_family, location_levels, locale, timezone, date_format, time_format, first_day_of_week, currency, currency_symbol, currency_position, decimal_separator, thousands_separator, address, phone, email, website, emergency_contact, facebook, twitter, linkedin, enable_multi_language, supported_languages, enabled_modules, created_at, updated_at) FROM stdin;
ada1c146-3809-4627-adf6-084e680e4635	3c4d4a9f-92a7-4dd2-82fb-ceff90c57094	National Capital District Commission	NCDC	/logo.png	\N	City of Excellence	#07080a	#10b981	#f59e0b	#EBECED	#FCFCFC	#F0F1F2	#07080A	#3D4047	#C0C3C4	#ffcc00	#10b981	#f59e0b	#ef4444	#07080a	#ffffff	#ffffff	\N	\N	4	4	8	4	Inter	["Country", "Province", "District", "Ward", "Section", "Lot"]	en-PG	Pacific/Port_Moresby	DD/MM/YYYY	HH:mm	monday	PGK	K	before	.	,	Port Moresby, Papua New Guinea	+675 325 6400	info@ncdc.gov.pg	https://ncdc.gov.pg	\N	\N	\N	\N	false	["en"]	["registry", "licensing", "services", "payments", "portal"]	2026-01-21 05:24:57.112012	2026-01-21 05:24:57.112012
5b63abaa-abcd-4bce-a513-fe2020da892e	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	National Capital District Commission	NCDC	/uploads/7699fdd931b8c5cba0d0d2f47762e5fe	\N	\N	#202020	#f0f010	#f10000	#f8f9ae	#FCFCFC	#F0F1F2	#040c1b	#3D4047	#C0C3C4	52 100% 50%	#10b981	#f59e0b	#ef4444	#737463	\N	#FCFCFC	\N	\N	4	4	8	4	Ubuntu	["Country", "Province", "District", "Ward", "Section", "Lot"]	en-PG	Pacific/Port_Moresby	DD/MM/YYYY	HH:mm	monday	PGK	K	before	.	,	\N	\N	\N	\N	\N	\N	\N	\N	false	["en"]	["licensing", "payments", "fleet", "waste", "assets", "procurement", "audit", "registry", "services", "inspections", "complaints", "properties", "environment", "gis", "building", "planning", "enforcement", "portal", "notifications", "reports", "documents", "workflows", "api", "feedback", "mobile"]	2026-01-21 05:40:51.369443	2026-01-22 05:44:30.021
\.


--
-- Data for Name: user_roles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_roles (user_id, role_id, assigned_at) FROM stdin;
a43cc5b6-043b-44e7-9320-34a39a0acb11	c5276f39-ddbe-4517-8a59-e91d1c841494	2026-01-14 06:40:16.243315
204181a6-e727-4072-b9db-eda5483c403e	bff2fab3-7615-46cf-adb8-d45130497241	2026-01-19 04:04:14.516532
11d9a981-602d-4e20-9592-913bd8293dc6	64ec116a-ba28-40d5-b9b8-967b5af7df46	2026-01-19 04:04:14.516532
59f0d53e-db27-4a25-af00-71c5e1028b0c	c6d113de-dcb6-49aa-97c0-f1015ab30909	2026-01-19 13:30:22.60522
7df2489c-9e28-4ba9-95ff-be58a6814840	2ed4f922-893d-4ce1-92a1-f1e7611b3809	2026-01-19 13:30:22.60522
18d6e011-8810-40c1-b5c4-f06deea3c874	37faddc4-f6e1-4e50-8eb5-3086a711f25e	2026-01-19 13:30:22.60522
44af7d4e-747a-4c90-8e2b-9941e3296513	b337e932-013e-4e36-aa41-68646ddbb6ff	2026-01-19 13:30:22.60522
d3edb4c4-4df7-4417-8884-bfb512f8d740	c5276f39-ddbe-4517-8a59-e91d1c841494	2026-01-24 13:53:33.897138
d91b1b8e-5030-462d-b711-accf1efb674e	316751dd-c84d-43fc-8810-af4e7c1adcf4	2026-01-24 13:56:31.622309
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (user_id, council_id, unit_id, full_name, email, phone, password_hash, status, mfa_enabled, last_login_at, created_at, role, national_id) FROM stdin;
a43cc5b6-043b-44e7-9320-34a39a0acb11	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	5bf3cc45-b974-424f-9379-a2f4af9eaf2a	System Administrator	admin@ncdc.gov.pg	+675 325 6400	fda165c79eb751508b01a63c7626231263381c082fcfc9245c738686c5bece0969ff88415b6af3b1902fa53d72c39d37aa3e65d2bbd22bb01d586d2e9ab684d4.5b73983e29ad0e6137350aae6df851bc	active	f	\N	2026-01-14 06:40:16.236183	user	\N
59f0d53e-db27-4a25-af00-71c5e1028b0c	90c57094-13e2-42f1-be1f-1a1b50595f70	d1f90032-5cf0-443b-9445-e9ca7561eefb	System Administrator	admin@ncdc.gov.pg	+675 325 6400	3b7e9443a356c518546cbc88f87d5da98f00cda52603a2c4c593e89fdb388ba588ae9f8b2f67a07ea2c6123cebd795c93939d65a2604a3fcfac9375d94a99f88.d41ab3e99056b0b9696e7b5e54c036f1	active	f	\N	2026-01-19 13:30:22.142714	user	\N
7df2489c-9e28-4ba9-95ff-be58a6814840	90c57094-13e2-42f1-be1f-1a1b50595f70	d1f90032-5cf0-443b-9445-e9ca7561eefb	John Kila	jkila@ncdc.gov.pg	+675 7234 5678	80e148197ec5043930869e7a400379a1df2b810c0e005b39d5ffd08ae95bdb062695a4a2d9e2461d0ba38d8f0c97797e1de93afca5964707bd8d299cfb05d1e9.353c06bb1c723a08dbc7cd6d1299d0b3	active	f	\N	2026-01-19 13:30:22.302834	user	\N
18d6e011-8810-40c1-b5c4-f06deea3c874	90c57094-13e2-42f1-be1f-1a1b50595f70	d1f90032-5cf0-443b-9445-e9ca7561eefb	Mary Wilson	mwilson@ncdc.gov.pg	+675 7234 9012	51fdb5302a31d32ed8fb7d6e3e618efec77fc20a140fb9d664fa3a0870ef35e2f3a2d2be97726893e1c3adafc80e6a53391e1103665a8f5217976053e7e0a9d5.d345ee705059df1d578e95c4181c2aaf	active	t	\N	2026-01-19 13:30:22.452673	user	\N
44af7d4e-747a-4c90-8e2b-9941e3296513	90c57094-13e2-42f1-be1f-1a1b50595f70	d1f90032-5cf0-443b-9445-e9ca7561eefb	Peter Tau	ptau@ncdc.gov.pg	+675 7234 3456	3ab37b339854f45a1c1d210b1535e43cb115c4304cf044936bba654abff9c585832391e37f199a492dcf6702a9c3195022913bbf0f8f67808b65022a24dae16b.9eb69ed8e2eb10aeef0718d1e7218752	active	f	\N	2026-01-19 13:30:22.593148	user	\N
204181a6-e727-4072-b9db-eda5483c403e	3c4d4a9f-92a7-4dd2-82fb-ceff90c57094	f1aec29a-5eb2-4f05-81c4-a65a0365fd79	System Administrator	admin@ncdc.gov.pg	+675 325 6400	1e33f22c8087e1f4b2883d58e22bb4810d7b2c8ecacbf8d14300c53a73fbe0b7852ba93b6e9e62f189dbd08a4f682ea2de2846f01856da844032fe9657509c21.619bd614c2edb285d4a87e0fa2a7c420	active	f	\N	2026-01-19 04:04:14.385332	user	\N
11d9a981-602d-4e20-9592-913bd8293dc6	3c4d4a9f-92a7-4dd2-82fb-ceff90c57094	f1aec29a-5eb2-4f05-81c4-a65a0365fd79	John Kila	jkila@ncdc.gov.pg	+675 7234 5678	3e5ac003a5f790025547ad636be1f58f8bbe51ac3d2e81616b935e61c469eed8f9d7444f727cd383d2478d7481c4f13d182f234dd7db3006810c3ea4453ce6d4.5cf058654120ae3e0e7a4e0e7fe8aa49	active	f	\N	2026-01-19 04:04:14.513361	user	\N
d3edb4c4-4df7-4417-8884-bfb512f8d740	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	\N	Lawrence Mukombo	lawrencemukombo2@gmail.com	+67571693959	$2b$10$JokYq1Yqqvt7m9SeSzHzBeQPJD3WtMDTdWVksae2/wN/AvNoA1T9G	active	f	\N	2026-01-24 05:43:47.240555	user	219879/24/1
d91b1b8e-5030-462d-b711-accf1efb674e	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	5bf3cc45-b974-424f-9379-a2f4af9eaf2a	John Kila	jkila@ncdc.gov.pg	+675 7234 5678	a52bf390c411fed55c53fe51d80455c436c27c9379fde71735336f3a2ca84df758189195db2f88d2d6483088225c3b761e3c442879b1bd7f79823f1ef846ef7e.d7241c5fb8a63d5bf1f84031553c8f84	active	f	\N	2026-01-14 06:40:16.241067	user	553367/23/1
\.


--
-- Data for Name: workflow_definitions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.workflow_definitions (workflow_id, council_id, service_id, version, name, description, active, created_at) FROM stdin;
a8548419-3263-405f-82de-3e8d7c003330	3c4d4a9f-92a7-4dd2-82fb-ceff90c57094	seed-licensing	1.0	Business License Approval	Standard process for new business registrations.	t	2026-01-22 08:14:13.634163
57738e87-a0d7-4cd2-b99e-636397333871	3c4d4a9f-92a7-4dd2-82fb-ceff90c57094	seed-building	1.0	Building Permit Review	Technical review for construction permits.	t	2026-01-22 08:14:13.634163
97ff1a4b-135e-4ad0-b4fd-6b547c43a523	3c4d4a9f-92a7-4dd2-82fb-ceff90c57094	seed-complaint	1.0	Citizen Complaint Handling	Routing and resolution of public issues.	f	2026-01-22 08:14:13.634163
736c02cf-2952-42c8-91af-139980efd630	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	seed-licensing	1.0	Business License Approval	Standard process for new business registrations.	t	2026-01-22 08:30:37.567656
ef88df33-fe5c-4909-8d67-4ca890c4a070	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	seed-building	1.0	Building Permit Review	Technical review for construction permits.	t	2026-01-22 08:30:37.567656
359ffda8-4b5b-4fff-befb-cccd53659f54	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	seed-complaint	1.0	Citizen Complaint Handling	Routing and resolution of public issues.	f	2026-01-22 08:30:37.567656
dcef516e-3df1-4b74-9f2f-1b304d920408	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	cea92864-045e-4734-9373-e420af8682ae	1.0	\N	\N	t	2026-01-23 04:17:25.61333
\.


--
-- Data for Name: workflow_instances; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.workflow_instances (instance_id, council_id, request_id, workflow_id, state, current_step_id, started_at, ended_at) FROM stdin;
8d4f8697-f089-4a46-ad18-83347d0651be	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	f89a1660-6f49-4b41-9b8e-72bf103f82fb	12e50e86-56ce-4a4b-ab7f-2be2223ade4e	active	b55c6c6b-478e-43b0-990f-a130028fec0d	2026-01-17 01:58:29.797	\N
19bf37cf-04ef-481f-95e7-d32e5de17d4a	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	cce4af46-d401-445f-a59e-d9371f0d9265	12e50e86-56ce-4a4b-ab7f-2be2223ade4e	active	b55c6c6b-478e-43b0-990f-a130028fec0d	2026-01-17 02:03:07.927	\N
a5447f8e-fdeb-402e-9085-763bb9017a8b	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	48967986-6b8b-430f-960f-056a7620b906	12e50e86-56ce-4a4b-ab7f-2be2223ade4e	active	b55c6c6b-478e-43b0-990f-a130028fec0d	2026-01-17 03:40:41.866	\N
7dc2f3ae-8fa1-4c11-bc93-7ef99489f331	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	2263b419-d125-4e00-ad7e-18b365b3af8e	12e50e86-56ce-4a4b-ab7f-2be2223ade4e	active	b55c6c6b-478e-43b0-990f-a130028fec0d	2026-01-17 07:51:44.883	\N
54d65089-b007-4e91-910f-ad5bb63b2fd3	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	6de2cc90-d67b-413f-a4a0-df644e74d00b	12e50e86-56ce-4a4b-ab7f-2be2223ade4e	active	b55c6c6b-478e-43b0-990f-a130028fec0d	2026-01-17 08:05:47.004	\N
a3535eed-7136-45f1-a955-d46eb03d50cd	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	d8622ca9-9b28-4548-a9be-fcf451fa25ab	12e50e86-56ce-4a4b-ab7f-2be2223ade4e	active	b55c6c6b-478e-43b0-990f-a130028fec0d	2026-01-17 08:25:32.529	\N
32ebb7c2-1014-4c14-8e91-59f9872a0da8	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	8a6e1251-4755-44f4-8d67-503250f7e063	12e50e86-56ce-4a4b-ab7f-2be2223ade4e	active	b55c6c6b-478e-43b0-990f-a130028fec0d	2026-01-17 08:41:37.498	\N
4b61cc2b-b99a-45f8-a95d-43ff7acfba0e	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	5b2364db-ca28-4f8b-a64b-a960c7131e8f	12e50e86-56ce-4a4b-ab7f-2be2223ade4e	active	b55c6c6b-478e-43b0-990f-a130028fec0d	2026-01-17 10:03:18.283	\N
16a07470-7815-4502-9b25-6bbce5e5ca37	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	cd0419e9-5560-4105-ac03-f933a22063b9	12e50e86-56ce-4a4b-ab7f-2be2223ade4e	active	b55c6c6b-478e-43b0-990f-a130028fec0d	2026-01-17 21:20:55.1	\N
136df5ca-4f72-4df6-92af-32a83b83e816	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	c206729f-0afa-4157-88d6-9c90ff876107	12e50e86-56ce-4a4b-ab7f-2be2223ade4e	active	b55c6c6b-478e-43b0-990f-a130028fec0d	2026-01-18 06:06:15.796	\N
781cce78-891c-48ba-bfa9-db09e28c790c	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	163cf2e6-8653-4d88-8daa-67c8c7bf20fd	12e50e86-56ce-4a4b-ab7f-2be2223ade4e	active	b55c6c6b-478e-43b0-990f-a130028fec0d	2026-01-18 06:50:49.436	\N
b9df7e81-87f1-4411-bcd1-403614dfd500	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	a3308191-165c-4487-8036-25c2316b08d7	dcef516e-3df1-4b74-9f2f-1b304d920408	active	c43f3c3e-e772-472b-a25b-11998c96ece3	2026-01-22 18:17:25.656	\N
ff3e4d3f-9cd8-4c17-8794-38500b3b79ab	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	11e0f60a-7447-4faf-a00e-94e8b07b8751	dcef516e-3df1-4b74-9f2f-1b304d920408	active	c43f3c3e-e772-472b-a25b-11998c96ece3	2026-01-23 20:18:53.986	\N
9b838544-5c60-45b0-a44a-846a0675cb3d	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	ad037f22-82cd-45e0-9378-4e2d845b37c1	dcef516e-3df1-4b74-9f2f-1b304d920408	active	c43f3c3e-e772-472b-a25b-11998c96ece3	2026-01-23 21:01:27.838	\N
\.


--
-- Data for Name: workflow_steps; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.workflow_steps (step_id, council_id, workflow_id, name, order_no, assignee_role, sla_rule, created_at) FROM stdin;
c900ff05-f6b9-45ee-a2af-63d955d1400b	3c4d4a9f-92a7-4dd2-82fb-ceff90c57094	a8548419-3263-405f-82de-3e8d7c003330	Application	1	Officer	\N	2026-01-22 08:14:13.640495
6baa934e-75b0-4cf9-b93c-132bf45b7cad	3c4d4a9f-92a7-4dd2-82fb-ceff90c57094	a8548419-3263-405f-82de-3e8d7c003330	Document Check	2	Officer	\N	2026-01-22 08:14:13.640495
54ee42d8-d9cb-40ab-81df-963f0b2e9a9e	3c4d4a9f-92a7-4dd2-82fb-ceff90c57094	a8548419-3263-405f-82de-3e8d7c003330	Site Inspection	3	Inspector	\N	2026-01-22 08:14:13.640495
024094b3-b3fd-4b28-8d8a-5cbca0603e64	3c4d4a9f-92a7-4dd2-82fb-ceff90c57094	a8548419-3263-405f-82de-3e8d7c003330	Approval	4	Manager	\N	2026-01-22 08:14:13.640495
7c141b3f-d3a1-454c-8c40-b608d04b058d	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	736c02cf-2952-42c8-91af-139980efd630	Application	1	Officer	\N	2026-01-22 08:30:37.58306
64f33f9f-81ae-4e9a-99ab-dbaad49d6482	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	736c02cf-2952-42c8-91af-139980efd630	Document Check	2	Officer	\N	2026-01-22 08:30:37.58306
cfa5a0d6-ce4b-41dc-9995-05c63063be5e	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	736c02cf-2952-42c8-91af-139980efd630	Site Inspection	3	Inspector	\N	2026-01-22 08:30:37.58306
413f08c1-917b-4a12-b8f5-4f0997a46c33	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	736c02cf-2952-42c8-91af-139980efd630	Approval	4	Manager	\N	2026-01-22 08:30:37.58306
c43f3c3e-e772-472b-a25b-11998c96ece3	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	dcef516e-3df1-4b74-9f2f-1b304d920408	Submission Review	1	Officer	\N	2026-01-23 04:17:25.627598
59dbea22-a865-4a28-a13a-d75b1aa018d5	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	dcef516e-3df1-4b74-9f2f-1b304d920408	Inspection	2	Inspector	\N	2026-01-23 04:17:25.627598
84b95e3f-0d73-4a1d-b4f9-92cf594dc056	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	dcef516e-3df1-4b74-9f2f-1b304d920408	Approval	3	Manager	\N	2026-01-23 04:17:25.627598
e6452ff2-2b04-4456-b92a-d99581713a4b	3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3	dcef516e-3df1-4b74-9f2f-1b304d920408	Issuance	4	Admin	\N	2026-01-23 04:17:25.627598
\.


--
-- Name: __drizzle_migrations_id_seq; Type: SEQUENCE SET; Schema: drizzle; Owner: postgres
--

SELECT pg_catalog.setval('drizzle.__drizzle_migrations_id_seq', 1, false);


--
-- Name: __drizzle_migrations __drizzle_migrations_pkey; Type: CONSTRAINT; Schema: drizzle; Owner: postgres
--

ALTER TABLE ONLY drizzle.__drizzle_migrations
    ADD CONSTRAINT __drizzle_migrations_pkey PRIMARY KEY (id);


--
-- Name: accounts accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.accounts
    ADD CONSTRAINT accounts_pkey PRIMARY KEY (account_id);


--
-- Name: assets assets_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.assets
    ADD CONSTRAINT assets_pkey PRIMARY KEY (asset_id);


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (audit_id);


--
-- Name: business_verification_requests business_verification_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.business_verification_requests
    ADD CONSTRAINT business_verification_requests_pkey PRIMARY KEY (request_id);


--
-- Name: businesses businesses_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.businesses
    ADD CONSTRAINT businesses_pkey PRIMARY KEY (business_id);


--
-- Name: checklist_requirements checklist_requirements_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.checklist_requirements
    ADD CONSTRAINT checklist_requirements_pkey PRIMARY KEY (id);


--
-- Name: citizens citizens_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.citizens
    ADD CONSTRAINT citizens_pkey PRIMARY KEY (citizen_id);


--
-- Name: complaint_updates complaint_updates_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.complaint_updates
    ADD CONSTRAINT complaint_updates_pkey PRIMARY KEY (update_id);


--
-- Name: complaints complaints_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.complaints
    ADD CONSTRAINT complaints_pkey PRIMARY KEY (complaint_id);


--
-- Name: council_units council_units_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.council_units
    ADD CONSTRAINT council_units_pkey PRIMARY KEY (unit_id);


--
-- Name: councils councils_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.councils
    ADD CONSTRAINT councils_pkey PRIMARY KEY (council_id);


--
-- Name: documents documents_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_pkey PRIMARY KEY (document_id);


--
-- Name: dynamic_locations dynamic_locations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dynamic_locations
    ADD CONSTRAINT dynamic_locations_pkey PRIMARY KEY (location_id);


--
-- Name: enforcement_cases enforcement_cases_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.enforcement_cases
    ADD CONSTRAINT enforcement_cases_pkey PRIMARY KEY (case_id);


--
-- Name: fee_schedules fee_schedules_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fee_schedules
    ADD CONSTRAINT fee_schedules_pkey PRIMARY KEY (fee_id);


--
-- Name: inspection_evidence inspection_evidence_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inspection_evidence
    ADD CONSTRAINT inspection_evidence_pkey PRIMARY KEY (evidence_id);


--
-- Name: inspection_findings inspection_findings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inspection_findings
    ADD CONSTRAINT inspection_findings_pkey PRIMARY KEY (finding_id);


--
-- Name: inspections inspections_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inspections
    ADD CONSTRAINT inspections_pkey PRIMARY KEY (inspection_id);


--
-- Name: integration_configs integration_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.integration_configs
    ADD CONSTRAINT integration_configs_pkey PRIMARY KEY (config_id);


--
-- Name: invoice_lines invoice_lines_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.invoice_lines
    ADD CONSTRAINT invoice_lines_pkey PRIMARY KEY (line_id);


--
-- Name: invoices invoices_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_pkey PRIMARY KEY (invoice_id);


--
-- Name: licence_renewals licence_renewals_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.licence_renewals
    ADD CONSTRAINT licence_renewals_pkey PRIMARY KEY (renewal_id);


--
-- Name: licences licences_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.licences
    ADD CONSTRAINT licences_pkey PRIMARY KEY (licence_id);


--
-- Name: license_type_fees license_type_fees_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.license_type_fees
    ADD CONSTRAINT license_type_fees_pkey PRIMARY KEY (id);


--
-- Name: license_types license_types_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.license_types
    ADD CONSTRAINT license_types_pkey PRIMARY KEY (id);


--
-- Name: location_levels location_levels_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.location_levels
    ADD CONSTRAINT location_levels_pkey PRIMARY KEY (id);


--
-- Name: locations locations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.locations
    ADD CONSTRAINT locations_pkey PRIMARY KEY (id);


--
-- Name: markets markets_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.markets
    ADD CONSTRAINT markets_pkey PRIMARY KEY (market_id);


--
-- Name: notices notices_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notices
    ADD CONSTRAINT notices_pkey PRIMARY KEY (notice_id);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (notification_id);


--
-- Name: otp_verifications otp_verifications_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.otp_verifications
    ADD CONSTRAINT otp_verifications_pkey PRIMARY KEY (id);


--
-- Name: payment_allocations payment_allocations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payment_allocations
    ADD CONSTRAINT payment_allocations_pkey PRIMARY KEY (allocation_id);


--
-- Name: payments payments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_pkey PRIMARY KEY (payment_id);


--
-- Name: permissions permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.permissions
    ADD CONSTRAINT permissions_pkey PRIMARY KEY (permission_code);


--
-- Name: properties properties_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.properties
    ADD CONSTRAINT properties_pkey PRIMARY KEY (property_id);


--
-- Name: purchase_order_lines purchase_order_lines_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.purchase_order_lines
    ADD CONSTRAINT purchase_order_lines_pkey PRIMARY KEY (line_id);


--
-- Name: purchase_orders purchase_orders_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.purchase_orders
    ADD CONSTRAINT purchase_orders_pkey PRIMARY KEY (order_id);


--
-- Name: rate_assessments rate_assessments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rate_assessments
    ADD CONSTRAINT rate_assessments_pkey PRIMARY KEY (assessment_id);


--
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (role_id);


--
-- Name: service_requests service_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.service_requests
    ADD CONSTRAINT service_requests_pkey PRIMARY KEY (request_id);


--
-- Name: services services_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.services
    ADD CONSTRAINT services_pkey PRIMARY KEY (service_id);


--
-- Name: special_requirements special_requirements_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.special_requirements
    ADD CONSTRAINT special_requirements_pkey PRIMARY KEY (id);


--
-- Name: stalls stalls_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stalls
    ADD CONSTRAINT stalls_pkey PRIMARY KEY (stall_id);


--
-- Name: tenant_config tenant_config_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tenant_config
    ADD CONSTRAINT tenant_config_pkey PRIMARY KEY (config_id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (user_id);


--
-- Name: workflow_definitions workflow_definitions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.workflow_definitions
    ADD CONSTRAINT workflow_definitions_pkey PRIMARY KEY (workflow_id);


--
-- Name: workflow_instances workflow_instances_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.workflow_instances
    ADD CONSTRAINT workflow_instances_pkey PRIMARY KEY (instance_id);


--
-- Name: workflow_steps workflow_steps_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.workflow_steps
    ADD CONSTRAINT workflow_steps_pkey PRIMARY KEY (step_id);


--
-- Name: dynamic_locations dynamic_locations_council_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dynamic_locations
    ADD CONSTRAINT dynamic_locations_council_id_fkey FOREIGN KEY (council_id) REFERENCES public.councils(council_id) ON DELETE CASCADE;


--
-- Name: tenant_config tenant_config_council_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tenant_config
    ADD CONSTRAINT tenant_config_council_id_fkey FOREIGN KEY (council_id) REFERENCES public.councils(council_id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict Bvdw1T07KxV7BfJiw8ndizHCiML8xnxqRcYfJIfpG9q6aZwKr1L6kLEkO2LlIej

