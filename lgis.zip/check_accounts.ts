
import { db } from "./server/db";
import { sql } from "drizzle-orm";

async function checkCols() {
    try {
        const res = await db.execute(sql`
        SELECT column_name, data_type, character_maximum_length
        FROM information_schema.columns 
        WHERE table_name = 'accounts'
      `);
        console.log(`accounts_COLS: ${res.rows.map(r => `${r.column_name}(${r.data_type})`).join(",")}`);
    } catch (e: any) {
        console.log(`ERR: ${e.message}`);
    }
    process.exit();
}
checkCols();
