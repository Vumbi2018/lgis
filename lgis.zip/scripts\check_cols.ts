
import { db } from "../server/db";
import { sql } from "drizzle-orm";

async function checkCols() {
    const tables = ["permissions", "license_types", "license_type_fees", "accounts"];
    for (const t of tables) {
        try {
            const res = await db.execute(sql`
        SELECT column_name 
        FROM information_schema.columns 
        WHERE table_name = ${t}
      `);
            console.log(`${t}_COLS: ${res.rows.map(r => r.column_name).join(",")}`);
        } catch (e: any) {
            console.log(`${t}_ERR: ${e.message}`);
        }
    }
    process.exit();
}
checkCols();
