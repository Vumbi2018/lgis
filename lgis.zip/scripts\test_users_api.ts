async function main() {
    console.log("Testing User API locally...");
    try {
        const res = await fetch("http://localhost:5000/api/v1/users", {
            headers: { "x-council-id": "3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3" } // Using standard council ID from logs
        });
        console.log("GET status:", res.status);
        const data = await res.json();
        console.log("User count:", data.length);
        if (data.length > 0) {
            console.log("First user sample:", JSON.stringify(data[0], null, 2));
        }
    } catch (error: any) {
        console.error("Local fetch error:", error.message);
    }
}

main();
