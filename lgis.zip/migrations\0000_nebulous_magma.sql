CREATE TABLE "accounts" (
	"account_id" varchar PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"council_id" varchar NOT NULL,
	"holder_type" text NOT NULL,
	"holder_id" varchar NOT NULL,
	"account_no" text NOT NULL,
	"status" text DEFAULT 'active' NOT NULL,
	"created_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "assets" (
	"asset_id" varchar PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"council_id" varchar NOT NULL,
	"asset_no" text NOT NULL,
	"name" text NOT NULL,
	"type" text NOT NULL,
	"location" text,
	"condition" text,
	"value" text,
	"status" text DEFAULT 'active',
	"created_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "audit_logs" (
	"audit_id" varchar PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"council_id" varchar NOT NULL,
	"user_id" varchar,
	"action" text NOT NULL,
	"entity_type" text NOT NULL,
	"entity_id" varchar,
	"before_state" jsonb,
	"after_state" jsonb,
	"ip_address" text,
	"created_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "business_verification_requests" (
	"request_id" varchar PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"business_id" varchar NOT NULL,
	"council_id" varchar NOT NULL,
	"status" text DEFAULT 'pending' NOT NULL,
	"submitted_at" timestamp DEFAULT now() NOT NULL,
	"reviewed_at" timestamp,
	"reviewed_by" varchar,
	"comments" text
);
--> statement-breakpoint
CREATE TABLE "businesses" (
	"business_id" varchar PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"council_id" varchar NOT NULL,
	"registration_no" text,
	"tin" text,
	"legal_name" text NOT NULL,
	"trading_name" text,
	"business_type" text,
	"industry" text,
	"owner_name" text,
	"owner_user_id" varchar,
	"contact_phone" text,
	"contact_email" text,
	"physical_address" text,
	"latitude" real,
	"longitude" real,
	"section" text,
	"lot" text,
	"block" text,
	"suburb" text,
	"village" text,
	"district" text,
	"province" text,
	"status" text DEFAULT 'pending_verification',
	"is_foreign_enterprise" boolean DEFAULT false,
	"created_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "checklist_requirements" (
	"id" varchar PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"license_type_id" varchar NOT NULL,
	"item_number" integer NOT NULL,
	"document_name" text NOT NULL,
	"responsible_entity" text,
	"requirement_note" text,
	"created_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "citizens" (
	"citizen_id" varchar PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"council_id" varchar NOT NULL,
	"national_id" text,
	"local_citizen_no" text,
	"first_name" text NOT NULL,
	"last_name" text NOT NULL,
	"dob" date,
	"sex" text,
	"phone" text,
	"email" text,
	"address" text,
	"section" text,
	"lot" text,
	"block" text,
	"suburb" text,
	"village" text,
	"district" text,
	"province" text,
	"nationality" text,
	"created_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "complaint_updates" (
	"update_id" varchar PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"council_id" varchar NOT NULL,
	"complaint_id" varchar NOT NULL,
	"updated_by" varchar,
	"status" text,
	"comment" text,
	"created_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "complaints" (
	"complaint_id" varchar PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"council_id" varchar NOT NULL,
	"complainant_type" text,
	"complainant_id" varchar,
	"category" text,
	"status" text DEFAULT 'new' NOT NULL,
	"description" text,
	"latitude" numeric(10, 7),
	"longitude" numeric(10, 7),
	"location" text,
	"created_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "council_units" (
	"unit_id" varchar PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"council_id" varchar NOT NULL,
	"name" text NOT NULL,
	"type" text NOT NULL,
	"parent_unit_id" varchar
);
--> statement-breakpoint
CREATE TABLE "councils" (
	"council_id" varchar PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"name" text NOT NULL,
	"level" text NOT NULL,
	"country_code" char(2) DEFAULT 'PG' NOT NULL,
	"currency_code" char(3) DEFAULT 'PGK' NOT NULL,
	"timezone" text DEFAULT 'Pacific/Port_Moresby' NOT NULL,
	"status" text DEFAULT 'active' NOT NULL,
	"logo_url" text,
	"theme_color" text DEFAULT '#EAB308',
	"font_family" text DEFAULT 'Inter',
	"email" text,
	"phone" text,
	"website" text,
	"address" text,
	"date_format" text DEFAULT 'dd/MM/yyyy',
	"time_format" text DEFAULT 'HH:mm',
	"created_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "documents" (
	"document_id" varchar PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"council_id" varchar NOT NULL,
	"owner_type" text NOT NULL,
	"owner_id" varchar NOT NULL,
	"type" text NOT NULL,
	"file_name" text NOT NULL,
	"file_path" text NOT NULL,
	"mime_type" text NOT NULL,
	"file_size" integer NOT NULL,
	"verified" boolean DEFAULT false,
	"verified_at" timestamp,
	"verified_by" varchar,
	"created_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "enforcement_cases" (
	"case_id" varchar PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"council_id" varchar NOT NULL,
	"request_id" varchar,
	"case_no" text NOT NULL,
	"type" text,
	"status" text DEFAULT 'open',
	"offender_type" text,
	"offender_id" varchar,
	"description" text,
	"created_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "fee_schedules" (
	"fee_id" varchar PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"council_id" varchar NOT NULL,
	"service_id" varchar NOT NULL,
	"name" text NOT NULL,
	"basis" text NOT NULL,
	"amount" numeric(12, 2) NOT NULL,
	"currency" char(3) DEFAULT 'PGK' NOT NULL,
	"valid_from" date NOT NULL,
	"valid_to" date
);
--> statement-breakpoint
CREATE TABLE "inspection_evidence" (
	"evidence_id" varchar PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"council_id" varchar NOT NULL,
	"inspection_id" varchar NOT NULL,
	"media_type" text,
	"url" text,
	"hash" text,
	"created_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "inspection_findings" (
	"finding_id" varchar PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"council_id" varchar NOT NULL,
	"inspection_id" varchar NOT NULL,
	"code" text,
	"severity" text,
	"description" text,
	"corrective_action" text,
	"due_date" date
);
--> statement-breakpoint
CREATE TABLE "inspections" (
	"inspection_id" varchar PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"council_id" varchar NOT NULL,
	"request_id" varchar,
	"inspector_user_id" varchar,
	"scheduled_at" timestamp,
	"performed_at" timestamp,
	"result" text,
	"remarks" text,
	"latitude" numeric(10, 7),
	"longitude" numeric(10, 7),
	"created_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "invoice_lines" (
	"line_id" varchar PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"council_id" varchar NOT NULL,
	"invoice_id" varchar NOT NULL,
	"description" text,
	"quantity" integer DEFAULT 1,
	"unit_price" numeric(12, 2),
	"line_total" numeric(12, 2)
);
--> statement-breakpoint
CREATE TABLE "invoices" (
	"invoice_id" varchar PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"council_id" varchar NOT NULL,
	"account_id" varchar NOT NULL,
	"invoice_no" text NOT NULL,
	"total_amount" numeric(12, 2) NOT NULL,
	"currency" char(3) DEFAULT 'PGK' NOT NULL,
	"status" text DEFAULT 'draft' NOT NULL,
	"issued_at" timestamp,
	"due_at" timestamp,
	"created_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "licence_renewals" (
	"renewal_id" varchar PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"council_id" varchar NOT NULL,
	"licence_id" varchar NOT NULL,
	"request_id" varchar,
	"previous_expiry_date" date,
	"new_expiry_date" date,
	"renewed_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "licences" (
	"licence_id" varchar PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"council_id" varchar NOT NULL,
	"request_id" varchar NOT NULL,
	"licence_no" text NOT NULL,
	"issue_date" date,
	"expiry_date" date,
	"status" text DEFAULT 'active' NOT NULL,
	"created_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "license_types" (
	"id" varchar PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"license_name" text NOT NULL,
	"license_category" text NOT NULL,
	"application_form" text,
	"description" text,
	"created_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "location_levels" (
	"id" varchar PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"council_id" varchar NOT NULL,
	"name" text NOT NULL,
	"level" integer NOT NULL,
	"description" text,
	"created_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "locations" (
	"id" varchar PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"council_id" varchar NOT NULL,
	"level_id" varchar NOT NULL,
	"code" text NOT NULL,
	"parent_id" varchar,
	"boundary" jsonb,
	"centroid" text,
	"status" text DEFAULT 'active',
	"created_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "markets" (
	"market_id" varchar PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"council_id" varchar NOT NULL,
	"name" text NOT NULL,
	"location" text,
	"capacity" integer,
	"operating_hours" text,
	"status" text DEFAULT 'active',
	"created_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "notices" (
	"notice_id" varchar PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"council_id" varchar NOT NULL,
	"case_id" varchar NOT NULL,
	"notice_no" text NOT NULL,
	"notice_type" text,
	"issued_date" date,
	"compliance_due" date,
	"details" text,
	"status" text DEFAULT 'issued',
	"created_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "notifications" (
	"notification_id" varchar PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"council_id" varchar NOT NULL,
	"user_id" varchar NOT NULL,
	"type" text NOT NULL,
	"title" text NOT NULL,
	"message" text NOT NULL,
	"reference_type" text,
	"reference_id" varchar,
	"read" boolean DEFAULT false,
	"created_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "otp_verifications" (
	"id" varchar PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"identifier" text NOT NULL,
	"code" text NOT NULL,
	"type" text NOT NULL,
	"expires_at" timestamp NOT NULL,
	"verified" boolean DEFAULT false,
	"created_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "payment_allocations" (
	"allocation_id" varchar PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"council_id" varchar NOT NULL,
	"payment_id" varchar NOT NULL,
	"invoice_id" varchar NOT NULL,
	"allocated_amount" numeric(12, 2) NOT NULL
);
--> statement-breakpoint
CREATE TABLE "payments" (
	"payment_id" varchar PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"council_id" varchar NOT NULL,
	"account_id" varchar NOT NULL,
	"payment_ref" text NOT NULL,
	"amount" numeric(12, 2) NOT NULL,
	"currency" char(3) DEFAULT 'PGK' NOT NULL,
	"method" text NOT NULL,
	"provider" text,
	"status" text DEFAULT 'pending' NOT NULL,
	"paid_at" timestamp,
	"created_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "permissions" (
	"permission_code" text PRIMARY KEY NOT NULL,
	"description" text NOT NULL
);
--> statement-breakpoint
CREATE TABLE "properties" (
	"property_id" varchar PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"council_id" varchar NOT NULL,
	"parcel_id" text,
	"section" text,
	"lot" text,
	"allotment" text,
	"suburb" text,
	"district" text,
	"land_type" text,
	"title_number" text,
	"owner_name" text,
	"owner_type" text,
	"land_area" text,
	"zoning" text,
	"rateable_value" numeric(12, 2),
	"coordinates" text,
	"status" text DEFAULT 'active',
	"created_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "rate_assessments" (
	"assessment_id" varchar PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"council_id" varchar NOT NULL,
	"property_id" varchar NOT NULL,
	"assessment_year" integer NOT NULL,
	"rateable_value" numeric(12, 2),
	"rate_amount" numeric(12, 2),
	"status" text DEFAULT 'pending',
	"created_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "role_permissions" (
	"role_id" varchar NOT NULL,
	"permission_code" text NOT NULL
);
--> statement-breakpoint
CREATE TABLE "roles" (
	"role_id" varchar PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"council_id" varchar NOT NULL,
	"name" text NOT NULL,
	"scope" text DEFAULT 'council' NOT NULL
);
--> statement-breakpoint
CREATE TABLE "service_requests" (
	"request_id" varchar PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"council_id" varchar NOT NULL,
	"service_id" varchar NOT NULL,
	"requester_type" text NOT NULL,
	"requester_id" varchar NOT NULL,
	"status" text DEFAULT 'draft' NOT NULL,
	"channel" text DEFAULT 'web' NOT NULL,
	"form_data" jsonb,
	"processing_data" jsonb,
	"request_ref" text,
	"submitted_at" timestamp,
	"created_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "services" (
	"service_id" varchar PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"council_id" varchar NOT NULL,
	"code" text NOT NULL,
	"name" text NOT NULL,
	"category" text NOT NULL,
	"description" text,
	"requires_inspection" boolean DEFAULT false,
	"requires_approval" boolean DEFAULT true,
	"active" boolean DEFAULT true,
	"created_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "special_requirements" (
	"id" varchar PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"license_type_id" varchar NOT NULL,
	"requirement_name" text NOT NULL,
	"issuing_authority" text,
	"description" text,
	"created_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "stalls" (
	"stall_id" varchar PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"council_id" varchar NOT NULL,
	"market_id" varchar NOT NULL,
	"stall_no" text NOT NULL,
	"category" text,
	"size" text,
	"daily_rate" numeric(10, 2),
	"monthly_rate" numeric(10, 2),
	"status" text DEFAULT 'available',
	"current_tenant_id" varchar,
	"created_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "user_roles" (
	"user_id" varchar NOT NULL,
	"role_id" varchar NOT NULL,
	"assigned_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "users" (
	"user_id" varchar PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"council_id" varchar NOT NULL,
	"unit_id" varchar,
	"full_name" text NOT NULL,
	"email" text NOT NULL,
	"phone" text,
	"password_hash" text NOT NULL,
	"status" text DEFAULT 'active' NOT NULL,
	"mfa_enabled" boolean DEFAULT false,
	"last_login_at" timestamp,
	"created_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "workflow_definitions" (
	"workflow_id" varchar PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"council_id" varchar NOT NULL,
	"service_id" varchar NOT NULL,
	"version" text DEFAULT '1.0' NOT NULL,
	"active" boolean DEFAULT true,
	"created_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "workflow_instances" (
	"instance_id" varchar PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"council_id" varchar NOT NULL,
	"request_id" varchar NOT NULL,
	"workflow_id" varchar NOT NULL,
	"state" text DEFAULT 'pending' NOT NULL,
	"current_step_id" varchar,
	"started_at" timestamp DEFAULT now(),
	"ended_at" timestamp
);
--> statement-breakpoint
CREATE TABLE "workflow_steps" (
	"step_id" varchar PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"council_id" varchar NOT NULL,
	"workflow_id" varchar NOT NULL,
	"name" text NOT NULL,
	"order_no" integer NOT NULL,
	"assignee_role" text,
	"sla_rule" text
);
