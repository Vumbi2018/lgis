import { db } from "./db";
import { sql } from "drizzle-orm";

/**
 * Migration script to create tenant_config and dynamic_locations tables
 */
async function migrateToTenantConfig() {
    console.log("🔄 Starting tenant configuration migration...");

    try {
        // Create tenant_config table
        await db.execute(sql`
      CREATE TABLE IF NOT EXISTS tenant_config (
        config_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        council_id UUID NOT NULL REFERENCES councils(council_id) ON DELETE CASCADE,
        
        -- Branding
        council_name TEXT,
        short_name TEXT,
        logo_url TEXT,
        favicon_url TEXT,
        tagline TEXT,
        
        -- Theme
        primary_color TEXT DEFAULT '#1e40af',
        secondary_color TEXT DEFAULT '#7c3aed',
        accent_color TEXT DEFAULT '#f59e0b',
        font_family TEXT DEFAULT 'Inter',
        
        -- Location Hierarchy
        location_levels JSONB DEFAULT '["Country", "Province", "District", "Ward"]'::jsonb,
        
        -- Localization
        locale TEXT DEFAULT 'en-PG',
        timezone TEXT DEFAULT 'Pacific/Port_Moresby',
        date_format TEXT DEFAULT 'DD/MM/YYYY',
        time_format TEXT DEFAULT 'HH:mm',
        first_day_of_week TEXT DEFAULT 'monday',
        
        -- Currency
        currency TEXT DEFAULT 'PGK',
        currency_symbol TEXT DEFAULT 'K',
        currency_position TEXT DEFAULT 'before',
        decimal_separator TEXT DEFAULT '.',
        thousands_separator TEXT DEFAULT ',',
        
        -- Contact
        address TEXT,
        phone TEXT,
        email TEXT,
        website TEXT,
        emergency_contact TEXT,
        
        -- Social
        facebook TEXT,
        twitter TEXT,
        linkedin TEXT,
        
        -- System
        enable_multi_language TEXT DEFAULT 'false',
        supported_languages JSONB DEFAULT '["en"]'::jsonb,
        
        -- Metadata
        created_at TIMESTAMP DEFAULT NOW() NOT NULL,
        updated_at TIMESTAMP DEFAULT NOW() NOT NULL
      );
    `);

        console.log("✅ Created tenant_config table");

        // Create dynamic_locations table
        await db.execute(sql`
      CREATE TABLE IF NOT EXISTS dynamic_locations (
        location_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        council_id UUID NOT NULL REFERENCES councils(council_id) ON DELETE CASCADE,
        
        -- Hierarchy
        level TEXT NOT NULL,
        level_index TEXT NOT NULL,
        name TEXT NOT NULL,
        code TEXT,
        
        -- Parent relationship
        parent_id UUID REFERENCES dynamic_locations(location_id),
        
        -- Geographic
        latitude TEXT,
        longitude TEXT,
        bounds JSONB,
        
        -- Metadata
        is_active TEXT DEFAULT 'true',
        created_at TIMESTAMP DEFAULT NOW() NOT NULL,
        updated_at TIMESTAMP DEFAULT NOW() NOT NULL
      );
    `);

        console.log("✅ Created dynamic_locations table");

        // Create indexes for performance
        await db.execute(sql`
      CREATE INDEX IF NOT EXISTS idx_tenant_config_council 
      ON tenant_config(council_id);
    `);

        await db.execute(sql`
      CREATE INDEX IF NOT EXISTS idx_dynamic_locations_council 
      ON dynamic_locations(council_id);
    `);

        await db.execute(sql`
      CREATE INDEX IF NOT EXISTS idx_dynamic_locations_parent 
      ON dynamic_locations(parent_id);
    `);

        await db.execute(sql`
      CREATE INDEX IF NOT EXISTS idx_dynamic_locations_level 
      ON dynamic_locations(level, council_id);
    `);

        console.log("✅ Created indexes");

        console.log("🎉 Migration completed successfully!");

    } catch (error) {
        console.error("❌ Migration failed:", error);
        throw error;
    }
}

// Run if called directly
if (require.main === module) {
    migrateToTenantConfig()
        .then(() => {
            console.log("✨ Database migration complete!");
            process.exit(0);
        })
        .catch((error) => {
            console.error("💥 Migration failed:", error);
            process.exit(1);
        });
}

export { migrateToTenantConfig };
