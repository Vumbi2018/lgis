
import { db } from "./server/db";
import { licences } from "@shared/schema";
import { eq } from "drizzle-orm";
import fs from 'fs';
import path from 'path';
import { createHash } from 'crypto';

async function verify() {
    const licenceNo = "LIC-2026-2917";
    console.log(`Checking licence: ${licenceNo}`);

    // 1. Get from DB
    const [licence] = await db.select().from(licences).where(eq(licences.licenceNo, licenceNo));

    if (!licence) {
        console.log("Licence NOT FOUND in DB");
        process.exit(1);
    }
    console.log(`DB pdfHash: ${licence.pdfHash}`);

    // 2. Read File and Hash
    const filePath = path.join(process.cwd(), "uploads", "certificates", `${licenceNo}.pdf`);
    if (!fs.existsSync(filePath)) {
        console.log(`File NOT FOUND at: ${filePath}`);
        process.exit(1);
    }

    const buffer = fs.readFileSync(filePath);
    const fileHash = createHash('sha256').update(buffer).digest('hex');
    console.log(`File Hash:  ${fileHash}`);

    if (licence.pdfHash === fileHash) {
        console.log("MATCH! Integrity Verified.");
    } else {
        console.log("MISMATCH! Integrity Failed.");
    }
    process.exit();
}

verify();
