
import { db } from "../server/db";
import { sql } from "drizzle-orm";

async function checkDb() {
    try {
        const tables = await db.execute(sql`
      SELECT table_name 
      FROM information_schema.tables 
      WHERE table_schema = 'public'
    `);
        console.log("TABLE_START");
        tables.rows.forEach(r => console.log(`TABLE: ${r.table_name}`));
        console.log("TABLE_END");

        const checkTable = async (name: string) => {
            try {
                const columns = await db.execute(sql`
          SELECT column_name, data_type 
          FROM information_schema.columns 
          WHERE table_name = ${name}
        `);
                console.log(`COL_START: ${name}`);
                columns.rows.forEach(r => console.log(`COL: ${r.column_name} (${r.data_type})`));
                console.log(`COL_END: ${name}`);
            } catch (err: any) {
                console.log(`ERR: Table ${name} - ${err.message}`);
            }
        };

        await checkTable("permissions");
        await checkTable("license_types");
        await checkTable("license_type_fees");
        await checkTable("inspection_evidence");
        await checkTable("accounts");

    } catch (error) {
        console.error("DB check failed:", error);
    } finally {
        process.exit();
    }
}

checkDb();
