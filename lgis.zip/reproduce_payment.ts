
async function main() {
    try {
        const response = await fetch("http://localhost:5000/api/v1/payments", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
            },
            body: JSON.stringify({
                councilId: "council-123",
                accountId: "acc-123",
                amount: "100.00",
                method: "cash",
                paymentRef: "REF-123", // required
                currency: "PGK"
            }),
        });

        console.log("Status:", response.status);
        const text = await response.text();
        console.log("Response:", text);
    } catch (err) {
        console.error("Fetch error:", err);
    }
}

main();
