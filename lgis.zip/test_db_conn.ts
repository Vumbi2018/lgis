
import pg from 'pg';
const { Pool } = pg;
import dotenv from 'dotenv';
dotenv.config();

const connectionString = process.env.DATABASE_URL;
console.log('Testing connection to:', connectionString ? connectionString.replace(/:[^:]*@/, ':****@') : 'undefined');

const pool = new Pool({ connectionString });

async function test() {
    try {
        const client = await pool.connect();
        console.log('Successfully connected to the database');
        const res = await client.query('SELECT current_database(), now()');
        console.log('Result:', res.rows[0]);
        client.release();
    } catch (err) {
        console.error('Connection error:', err);
    } finally {
        await pool.end();
    }
}

test();
