import { db } from "../server/db";
import { users } from "@shared/schema";
import { eq } from "drizzle-orm";
import { hashPassword } from "../server/auth";

async function fixHashes() {
    console.log("🛠️ Updating existing password hashes to Scrypt...");

    const adminEmail = "admin@ncdc.gov.pg";
    const officerEmail = "jkila@ncdc.gov.pg";

    try {
        const adminHash = await hashPassword("admin123");
        const officerHash = await hashPassword("officer123");

        await db.update(users)
            .set({ passwordHash: adminHash })
            .where(eq(users.email, adminEmail));

        console.log(`✅ Updated hash for ${adminEmail}`);

        await db.update(users)
            .set({ passwordHash: officerHash })
            .where(eq(users.email, officerEmail));

        console.log(`✅ Updated hash for ${officerEmail}`);

        console.log("🎉 Hash update completed successfully!");
    } catch (error) {
        console.error("❌ Hash update failed:", error);
        process.exit(1);
    }
    process.exit(0);
}

fixHashes();
