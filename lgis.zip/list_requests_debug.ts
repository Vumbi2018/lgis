import { db } from "./server/db";
import { serviceRequests } from "./shared/schema";

async function run() {
    const res = await db.select().from(serviceRequests);
    console.log(`TOTAL REQUESTS: ${res.length}`);
    const counts: Record<string, number> = {};
    for (const r of res) {
        counts[r.councilId] = (counts[r.councilId] || 0) + 1;
    }
    console.log("COUNTS BY COUNCIL:", JSON.stringify(counts, null, 2));

    // Details
    console.log("DETAILS:", JSON.stringify(res.map(r => ({
        id: r.requestId,
        councilId: r.councilId,
        businessId: r.businessId,
        status: r.status,
        ref: r.requestRef,
        createdAt: r.createdAt
    })), null, 2));
    process.exit(0);
}

run().catch(err => {
    console.error(err);
    process.exit(1);
});
