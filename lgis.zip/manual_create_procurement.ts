
import { db } from "./server/db";
import { sql } from "drizzle-orm";

async function migrate() {
    try {
        console.log("Creating purchase_orders table...");
        await db.execute(sql`
      CREATE TABLE IF NOT EXISTS purchase_orders (
        order_id varchar PRIMARY KEY DEFAULT gen_random_uuid(),
        council_id varchar NOT NULL,
        vendor_id varchar NOT NULL,
        requestor_id varchar,
        order_date date DEFAULT NOW(),
        expected_date date,
        status text DEFAULT 'draft',
        total_amount decimal(12, 2) DEFAULT 0,
        currency char(3) DEFAULT 'PGK',
        description text,
        created_at timestamp DEFAULT NOW() NOT NULL
      );
    `);

        console.log("Creating purchase_order_lines table...");
        await db.execute(sql`
      CREATE TABLE IF NOT EXISTS purchase_order_lines (
        line_id varchar PRIMARY KEY DEFAULT gen_random_uuid(),
        order_id varchar NOT NULL,
        description text NOT NULL,
        quantity integer NOT NULL DEFAULT 1,
        unit_price decimal(12, 2) NOT NULL,
        line_total decimal(12, 2) NOT NULL
      );
    `);
        console.log("Migration successful.");
    } catch (e: any) {
        console.log(`ERR: ${e.message}`);
    }
    process.exit();
}
migrate();
