import { db } from "./server/db";
import {
    serviceRequests,
    payments,
    licences,
} from "./shared/schema";
import { inArray } from "drizzle-orm";

async function run() {
    const oldCouncilIds = [
        "3c4d4a9f-92a7-4dd2-82fb-ceff90c57094",
        "90c57094-13e2-42f1-be1f-1a1b50595f70",
        "f2739382-95a8-4197-ace0-bd1bcc5c1a11",
        "ncdc-001"
    ];

    const activeCouncilId = "3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3";

    console.log(`Migrating data from legacy councils [${oldCouncilIds.join(', ')}] to [${activeCouncilId}]...`);

    // 1. Service Requests
    const migratedRequests = await db.update(serviceRequests)
        .set({ councilId: activeCouncilId })
        .where(inArray(serviceRequests.councilId, oldCouncilIds))
        .returning();
    console.log(`Updated ${migratedRequests.length} service requests.`);

    // 2. Payments
    const migratedPayments = await db.update(payments)
        .set({ councilId: activeCouncilId })
        .where(inArray(payments.councilId, oldCouncilIds))
        .returning();
    console.log(`Updated ${migratedPayments.length} payments.`);

    // 3. Licences
    const migratedLicences = await db.update(licences)
        .set({ councilId: activeCouncilId })
        .where(inArray(licences.councilId, oldCouncilIds))
        .returning();
    console.log(`Updated ${migratedLicences.length} licences.`);

    console.log("Migration complete.");
    process.exit(0);
}

run().catch(err => {
    console.error(err);
    process.exit(1);
});
