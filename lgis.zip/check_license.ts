
import { db } from "./server/db";
import { licences, serviceRequests } from "./shared/schema";
import { eq } from "drizzle-orm";

async function checkLicense() {
    const requestId = "d8622ca9-9b28-4548-a9be-fcf451fa25ab";

    console.log(`Checking Request: ${requestId}`);
    const [request] = await db.select().from(serviceRequests).where(eq(serviceRequests.requestId, requestId));
    console.log("Request Status:", request?.status);

    console.log(`Checking License for Request: ${requestId}`);
    const licence = await db.select().from(licences).where(eq(licences.requestId, requestId));
    console.log("Licenses found:", licence.length);
    if (licence.length > 0) {
        console.log("License details:", JSON.stringify(licence[0], null, 2));
    }
}

checkLicense().catch(console.error);
