import { db } from "./server/db";
import { users } from "./shared/schema";
import { count } from "drizzle-orm";

async function checkUsers() {
    try {
        const result = await db.select({ value: count() }).from(users);
        console.log(`User count: ${result[0].value}`);

        const allUsers = await db.select().from(users);
        console.log("Users in DB:");
        allUsers.forEach(u => {
            console.log(`- ${u.email} (ID: ${u.userId})`);
        });
    } catch (error) {
        console.error("Error checking users:", error);
    } finally {
        process.exit(0);
    }
}

checkUsers();
