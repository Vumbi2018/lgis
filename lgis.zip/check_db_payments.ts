
import { db } from "./server/db";
import { payments, serviceRequests } from "./shared/schema";
import { eq, desc } from "drizzle-orm";

async function checkPayments() {
    console.log("Checking recent payments...");
    const recentPayments = await db.select().from(payments).orderBy(desc(payments.createdAt)).limit(5);
    console.log("Recent Payments:", JSON.stringify(recentPayments, null, 2));

    const recentRequests = await db.select().from(serviceRequests).orderBy(desc(serviceRequests.createdAt)).limit(5);
    console.log("Recent Requests:", JSON.stringify(recentRequests.map(r => ({ id: r.requestId, ref: r.requestRef, status: r.status })), null, 2));
}

checkPayments().catch(console.error);
