
import { db } from "../server/db";
import { serviceRequests, services, licenseTypes } from "../shared/schema";
import { eq, sql, like } from "drizzle-orm";

async function main() {
    try {
        console.log("Searching for request with General Merchandise...");

        // This is tricky with JSONB, we'll just fetch recent requests and check properties
        const requests = await db.query.serviceRequests.findMany({
            limit: 20,
            orderBy: (requests, { desc }) => [desc(requests.createdAt)],
            with: {
                service: {
                    with: {
                        licenseType: true
                    }
                }
            }
        });

        for (const req of requests) {
            const data = req.processingData as any;
            // Check broadly for "General"
            console.log(`Request ${req.requestId} - Service: ${req.service?.name}, Activity: ${data?.businessActivity}`);

            if (data?.businessActivity && (data.businessActivity.includes("General") || data.businessActivity.includes("Merchandise"))) {
                console.log("MATCH FOUND!");
                console.log("Service Name:", req.service?.name);
                console.log("License Type Name:", req.service?.licenseType?.name);
                console.log("License Type ID:", req.service?.licenseType?.id);
            }
        }

    } catch (e) {
        console.error("Error:", e);
    }
    process.exit(0);
}
main();
