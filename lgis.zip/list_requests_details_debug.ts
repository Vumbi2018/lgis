import { db } from "./server/db";
import { businesses, serviceRequests } from "./shared/schema";
import * as fs from "fs";

async function run() {
    const bizList = await db.select().from(businesses);
    const reqList = await db.select().from(serviceRequests);

    const bizMap: Record<string, any> = {};
    for (const b of bizList) {
        bizMap[b.businessId] = b;
    }

    let output = "BUSINESS ANALYSIS:\n";
    for (const b of bizList) {
        output += `BIZ: ${b.businessId} | OWNER: ${b.ownerUserId} | COUNCIL: ${b.councilId} | NAME: ${b.legalName}\n`;
    }

    output += "\nREQUEST ANALYSIS:\n";
    for (const r of reqList) {
        const biz = bizMap[r.requesterId];
        output += `REQ: ${r.requestId} | COUNCIL: ${r.councilId} | BIZ: ${r.requesterId} | OWNER: ${biz?.ownerUserId} | STATUS: ${r.status} | REF: ${r.requestRef}\n`;
    }

    fs.writeFileSync("business_owner_analysis.txt", output);
    console.log("Written to business_owner_analysis.txt");
    process.exit(0);
}

run().catch(err => {
    console.error(err);
    process.exit(1);
});
