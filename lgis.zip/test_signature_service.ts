
import { DigitalSignatureService } from "./server/digital_signature_service";

async function test() {
    const payload = {
        licenceNo: "TEST",
        councilId: "TEST",
        requestId: "TEST",
        issueDate: "2024-01-01",
        expiryDate: "2025-01-01",
        tradingName: "TEST",
        applicantName: "TEST",
        premisesAddress: "TEST",
        serviceName: "TEST"
    };

    const { json, hash } = DigitalSignatureService.canonicalizeLicence(payload);
    console.log("Canonical Hash:", hash);

    const buffer = Buffer.from("TEST PDF CONTENT");
    const fileHash = DigitalSignatureService.calculateFileHash(buffer);
    console.log("File Hash:", fileHash);

    if (hash && fileHash) {
        console.log("SUCCESS: Service is working.");
    } else {
        console.log("FAILURE: Service returned empty values.");
    }
}
test();
