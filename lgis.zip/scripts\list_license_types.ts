
import { db } from "../server/db";
import { licenseTypes } from "../shared/schema";
import * as fs from 'fs';

async function main() {
    try {
        const allTypes = await db.select().from(licenseTypes);
        fs.writeFileSync('license_types_list.json', JSON.stringify(allTypes, null, 2));
        console.log("Wrote list to license_types_list.json");

        const allServices = await db.query.services.findMany({
            with: {
                licenseType: true
            }
        });
        fs.writeFileSync('services_list.json', JSON.stringify(allServices, null, 2));
        console.log("Wrote list to services_list.json");
    } catch (e) {
        console.error("Error:", e);
    }
    process.exit(0);
}
main();
