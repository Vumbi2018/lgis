import { db } from "./server/db";
import { services } from "./shared/schema";
import { eq } from "drizzle-orm";

async function fix() {
    const sourceId = "3c4d4a9f-92a7-4dd2-82fb-ceff90c57094";
    const targetId = "3c4d4a9f-92a7-4dd2-82fb-ceff0d9880e3";

    console.log(`Copying services from ${sourceId} to ${targetId}...`);

    const sourceServices = await db.select().from(services).where(eq(services.councilId, sourceId));
    console.log(`Found ${sourceServices.length} services to copy.`);

    for (const s of sourceServices) {
        const { serviceId, createdAt, ...data } = s;
        await db.insert(services).values({
            ...data,
            councilId: targetId
        });
        console.log(`Copied service: ${s.name}`);
    }

    console.log("Fix completed.");
    process.exit(0);
}

fix().catch(err => {
    console.error(err);
    process.exit(1);
});
