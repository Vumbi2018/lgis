
import { db } from "../server/db";
import { sql } from "drizzle-orm";

async function checkDb() {
    try {
        const checkTable = async (name: string) => {
            const res = await db.execute(sql`
        SELECT COUNT(*) 
        FROM information_schema.tables 
        WHERE table_name = ${name}
      `);
            const exists = res.rows[0].count > 0;
            console.log(`CHECK_TABLE: ${name} = ${exists ? 'EXISTS' : 'MISSING'}`);

            if (exists) {
                const cols = await db.execute(sql`
          SELECT column_name 
          FROM information_schema.columns 
          WHERE table_name = ${name}
        `);
                console.log(`COLUMNS_${name}: ${cols.rows.map(r => r.column_name).join(', ')}`);
            }
        };

        await checkTable("permissions");
        await checkTable("license_types");
        await checkTable("license_type_fees");
        await checkTable("accounts");
        await checkTable("inspection_evidence");

    } catch (error: any) {
        console.error("DB check failed:", error.message);
    } finally {
        process.exit();
    }
}

checkDb();
