
import { db } from "./server/db";
import { sql } from "drizzle-orm";

async function migrate() {
    try {
        console.log("Adding columns to licences...");
        await db.execute(sql`
      ALTER TABLE licences 
      ADD COLUMN IF NOT EXISTS licence_payload_hash text,
      ADD COLUMN IF NOT EXISTS pdf_hash text,
      ADD COLUMN IF NOT EXISTS signed_pdf_hash text,
      ADD COLUMN IF NOT EXISTS signature_metadata jsonb,
      ADD COLUMN IF NOT EXISTS version integer DEFAULT 1;
    `);
        console.log("Migration successful.");
    } catch (e: any) {
        console.log(`ERR: ${e.message}`);
    }
    process.exit();
}
migrate();
