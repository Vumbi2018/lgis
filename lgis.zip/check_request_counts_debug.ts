import { db } from "./server/db";
import { serviceRequests } from "./shared/schema";
import { eq, sql } from "drizzle-orm";

async function check() {
    const counts = await db.select({
        councilId: serviceRequests.councilId,
        count: sql<number>`count(*)`
    }).from(serviceRequests).groupBy(serviceRequests.councilId);

    console.log("REQUEST COUNTS PER COUNCIL:", JSON.stringify(counts, null, 2));
    process.exit(0);
}

check().catch(err => {
    console.error(err);
    process.exit(1);
});
